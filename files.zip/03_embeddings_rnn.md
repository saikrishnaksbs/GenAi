# File 3 of 20: Words as Numbers, Networks as Sequences
## Embeddings → Recurrent Neural Networks (RNNs)

> **Continuity note**: Files 1-2 built networks that take a *fixed-size* input (like a vector of 3 numbers) and produce an output. But language is neither fixed-size nor numeric — a sentence can be 3 words or 300 words, and words are not numbers. This file solves both problems: first, how to turn words into meaningful numeric vectors (**embeddings**), and second, how to build a network that can process a *sequence* of any length (**RNNs**) — the first architecture in this series capable of handling language at all.

---

# Table of Contents

1. [Step 9: Embeddings](#step-9-embeddings)
2. [Step 10: RNN (Recurrent Neural Networks)](#step-10-rnn-recurrent-neural-networks)
3. [Summary Cheat Sheet](#summary-cheat-sheet)
4. [Self-Test Questions](#self-test-questions)

---

# Step 9: Embeddings

### Main Question: *How do we represent words as vectors?*

## 9.1 The Everyday Analogy

Imagine you're organizing a massive library, and you want to place books on shelves such that **similar books end up physically near each other**. A cookbook about Italian pasta should sit near a cookbook about Italian risotto, not next to a physics textbook. A physics textbook should sit near a chemistry textbook, not next to a romance novel.

Now imagine you had a magical 2D map of your library floor, and you could place every single book at some $(x,y)$ coordinate on that map, such that **distance on the map = similarity in content.** Books about cooking cluster in one region, books about science cluster in another region, and within the cooking region, Italian cookbooks cluster closer together than, say, Italian cookbooks and Thai cookbooks (though both are still "cooking," so still closer to each other than to physics).

**This is exactly what a word embedding is** — except instead of a 2D map, we typically use a space with hundreds of dimensions (commonly 100-4096+ dimensions in real systems), and instead of books, we're placing *words* (or, as you already know from your tokenization studies, more precisely *tokens*) at coordinates such that similar-meaning words end up near each other in this high-dimensional space.

## 9.2 The Tech Analogy

Think of embeddings like a **hash function that preserves meaning**, or like coordinates in a video game world. In a video game, every object has an $(x,y,z)$ position — and objects placed close together in that 3D space are "close" to each other in the game world (you can walk between them quickly, they might interact, etc.). An embedding does the same thing but for *meaning* instead of physical space: every word gets a position in a high-dimensional "meaning space," and words placed close together in that space share similar meanings, usages, or contexts.

Or, if you've used a recommendation system: Spotify or Netflix effectively places every song or movie into a high-dimensional space based on user behavior, such that similar songs/movies end up near each other — this is precisely an embedding, just for songs/movies instead of words.

## 9.3 Why Do We Need This At All? The Problem With Naive Word Representations

### 9.3.1 The Naive Approach: One-Hot Encoding

Before embeddings, the most obvious way to represent a word numerically is **one-hot encoding**: if your vocabulary has $V$ total unique words, represent word number $i$ as a vector of length $V$, with a 1 in position $i$ and 0 everywhere else.

**Example**: suppose our tiny vocabulary is ["cat", "dog", "king", "queen"], so $V=4$.

$$\text{cat} = \begin{bmatrix}1\\0\\0\\0\end{bmatrix}, \quad \text{dog}=\begin{bmatrix}0\\1\\0\\0\end{bmatrix}, \quad \text{king}=\begin{bmatrix}0\\0\\1\\0\end{bmatrix}, \quad \text{queen}=\begin{bmatrix}0\\0\\0\\1\end{bmatrix}$$

### 9.3.2 Problem 1 — No Notion of Similarity

Let's compute the similarity between "cat" and "dog" versus "cat" and "king," using a very standard similarity measure: the **dot product** (recall File 1, Section 1.3.3).

$$\text{cat}\cdot\text{dog} = (1)(0)+(0)(1)+(0)(0)+(0)(0) = 0$$

$$\text{cat}\cdot\text{king} = (1)(0)+(0)(0)+(0)(1)+(0)(0) = 0$$

**Both dot products are exactly zero.** According to one-hot encoding, "cat" and "dog" are just as similar (i.e., not at all) as "cat" and "king" — even though we, as humans, know cat and dog (both common pets, both animals) are intuitively far more similar than cat and king (an animal vs. a royal title). One-hot encoding treats every word as **completely, maximally different** from every other word, with zero shared structure. This is a huge loss of useful information.

### 9.3.3 Problem 2 — Impractically Large Dimensionality

Real vocabularies for language models are typically 50,000 to 200,000+ tokens (you've already studied BPE tokenization, so you know this number well). A one-hot vector for such a vocabulary would be a vector of length 50,000+, with a single 1 and 49,999+ zeros. This is:

- **Extremely memory-wasteful**: storing and computing with such enormous, mostly-zero vectors for every single word in every sentence is computationally very expensive.
- **Extremely sparse**: "sparse" means mostly zeros; sparse representations make it hard for a network's weighted-sum computations (recall $z = \mathbf{w}\cdot\mathbf{x}+b$ from File 1) to learn efficiently, since almost every input dimension is zero for almost every example.

### 9.3.4 The Embedding Solution

Instead of a sparse 50,000-dimensional one-hot vector, we represent each word with a **dense** (mostly non-zero), much lower-dimensional vector — commonly 100 to 4096 dimensions depending on the model size. Critically, **these vectors are learned from data** during training, such that words used in similar contexts end up with similar vectors.

$$\text{cat} \to \begin{bmatrix}0.21\\-0.45\\0.83\\\vdots\\0.12\end{bmatrix}_{d=300}, \qquad \text{dog}\to\begin{bmatrix}0.19\\-0.41\\0.79\\\vdots\\0.15\end{bmatrix}_{d=300}$$

Notice "cat" and "dog"'s vectors, though not identical, are numerically *close* to each other (similar values in each dimension) — reflecting their semantic similarity, in a way one-hot encoding could never capture.

## 9.4 The Full Mathematics — How Embeddings Actually Work Mechanically

### 9.4.1 The Embedding Matrix

An embedding layer is, mechanically, extremely simple: it's just a big **lookup table**, represented as a matrix $E$ of shape $V \times d$, where $V$ is the vocabulary size and $d$ is the chosen embedding dimension (a hyperparameter you choose, like 300, 768, 4096, etc.).

$$E = \begin{bmatrix} \text{---embedding for word 1---} \\ \text{---embedding for word 2---} \\ \vdots \\ \text{---embedding for word } V\text{---} \end{bmatrix}_{V \times d}$$

Each **row** of $E$ is the $d$-dimensional embedding vector for one specific word in the vocabulary.

### 9.4.2 The Lookup Operation

Given a word's index $i$ (its position in the vocabulary — e.g., if "cat" is word #47 in our vocabulary, $i=47$), retrieving its embedding is literally just reading off row $i$ of the matrix $E$:

$$\mathbf{e}_{\text{cat}} = E[47, :]$$

(The notation $E[47,:]$ means "row 47, all columns" — standard matrix-slicing notation.)

### 9.4.3 An Equivalent, More "Neural Network-y" View — Multiplying by a One-Hot Vector

Here's a beautiful connection back to what we already know: this same lookup operation can be expressed as multiplying the one-hot vector for word $i$ by the embedding matrix $E^T$ (transposed):

$$\mathbf{e}_i = E^T \mathbf{x}_{\text{one-hot}}$$

**Why does this work?** Recall matrix-vector multiplication from File 1, Section 3.4.2: multiplying a matrix by a one-hot vector (a vector with a single 1 and the rest zeros) simply **selects out the one column (or row, depending on orientation) corresponding to that 1's position**, and zeros out the contribution of every other column, since every other entry gets multiplied by 0.

This connection matters conceptually: **it shows that an embedding layer is not some entirely separate, exotic mechanism — it's simply a special-case, highly-optimized version of the exact same $W\mathbf{x}$ matrix multiplication we've been using since File 1.** In practice, real implementations skip the wasteful one-hot-vector-times-matrix computation and just directly index into the table (Section 9.4.2's approach), for efficiency — but mathematically, they're identical operations.

### 9.4.4 How Are Embeddings Actually Learned? (Connecting to Backpropagation)

This is a critical point that's easy to gloss over: **the embedding matrix $E$ is not designed by a human or computed by some separate similarity algorithm — it is simply a set of weights, exactly like every other weight matrix we've discussed, and it gets updated via gradient descent and backpropagation (Files 2's Steps 6-7), driven by whatever the overall task's loss function is.**

Concretely: suppose we're training a language model to predict the next word (Step 15's topic, previewed here). If the model, using its current (still bad, since training hasn't converged yet) embedding for "cat," makes a bad prediction, backpropagation computes $\frac{\partial \mathcal{L}}{\partial \mathbf{e}_{\text{cat}}}$ — exactly analogous to computing $\frac{\partial\mathcal{L}}{\partial w}$ for any other weight in File 2, Step 7 — and gradient descent nudges the "cat" embedding vector in the direction that would have reduced the loss. Over millions of training examples, words that tend to appear in similar contexts (like "cat" and "dog," both often appearing near words like "pet," "feed," "bark/meow," "veterinarian") receive **similar gradient nudges over and over**, and so their embedding vectors gradually drift toward each other in the high-dimensional space — this is the actual mechanical origin of the "similar words end up with similar vectors" property, not a designed-in feature, but an **emergent consequence of gradient descent optimizing a shared prediction task.**

## 9.5 Measuring Similarity Between Embeddings — Cosine Similarity

Once words are vectors, we need a precise way to measure "how similar" two word vectors are. The dot product (Section 9.3.2) is a starting point, but it has an issue: a dot product's magnitude is affected by the *length* (magnitude) of the vectors, not just their *direction*. Two vectors could point in nearly the same direction (very similar meaning) but have a small dot product just because one of them happens to have small magnitude — misleadingly suggesting low similarity.

### 9.5.1 The Formula, Derived

**Cosine similarity** fixes this by dividing the dot product by the magnitudes of both vectors, isolating purely the *directional* alignment:

$$\text{cosine\_sim}(\mathbf{a},\mathbf{b}) = \frac{\mathbf{a}\cdot\mathbf{b}}{\|\mathbf{a}\|\|\mathbf{b}\|}$$

where $\|\mathbf{a}\|$ denotes the **magnitude** (length) of vector $\mathbf{a}$, computed as:

$$\|\mathbf{a}\| = \sqrt{a_1^2+a_2^2+\dots+a_n^2}$$

(This comes directly from the Pythagorean theorem, generalized to $n$ dimensions — if you think of a 2D vector $(a_1,a_2)$, its length is $\sqrt{a_1^2+a_2^2}$, exactly the hypotenuse of a right triangle with legs $a_1$ and $a_2$. This generalizes naturally to any number of dimensions.)

**Why does dividing by the magnitudes isolate direction?** This comes from the geometric definition of the dot product:

$$\mathbf{a}\cdot\mathbf{b} = \|\mathbf{a}\|\|\mathbf{b}\|\cos(\theta)$$

where $\theta$ is the angle between the two vectors. Rearranging this equation to solve for $\cos(\theta)$:

$$\cos(\theta) = \frac{\mathbf{a}\cdot\mathbf{b}}{\|\mathbf{a}\|\|\mathbf{b}\|}$$

This is *exactly* the cosine similarity formula — it literally computes the cosine of the angle between the two vectors, which depends purely on their directions, not their magnitudes. 

**Range and interpretation**: 
- $\cos(\theta)=1$ when $\theta=0°$ (vectors point in exactly the same direction — maximally similar)
- $\cos(\theta)=0$ when $\theta=90°$ (vectors are perpendicular — unrelated)
- $\cos(\theta)=-1$ when $\theta=180°$ (vectors point in exactly opposite directions — maximally dissimilar/opposite)

### 9.5.2 Fully Worked Numerical Example

Let's use simple 3-dimensional toy embeddings (real ones would have hundreds of dimensions, but 3 lets us compute by hand):

$$\mathbf{e}_{\text{cat}} = \begin{bmatrix}0.8\\0.6\\0.1\end{bmatrix}, \qquad \mathbf{e}_{\text{dog}} = \begin{bmatrix}0.7\\0.7\\0.2\end{bmatrix}, \qquad \mathbf{e}_{\text{car}} = \begin{bmatrix}-0.2\\0.1\\0.9\end{bmatrix}$$

**Step 1 — compute the dot product of cat and dog:**

$$\mathbf{e}_{\text{cat}}\cdot\mathbf{e}_{\text{dog}} = (0.8)(0.7)+(0.6)(0.7)+(0.1)(0.2)$$

$$= 0.56+0.42+0.02 = 1.00$$

**Step 2 — compute the magnitudes:**

$$\|\mathbf{e}_{\text{cat}}\| = \sqrt{0.8^2+0.6^2+0.1^2} = \sqrt{0.64+0.36+0.01} = \sqrt{1.01}\approx1.005$$

$$\|\mathbf{e}_{\text{dog}}\| = \sqrt{0.7^2+0.7^2+0.2^2} = \sqrt{0.49+0.49+0.04}=\sqrt{1.02}\approx1.010$$

**Step 3 — compute cosine similarity:**

$$\text{cosine\_sim}(\text{cat},\text{dog}) = \frac{1.00}{(1.005)(1.010)} = \frac{1.00}{1.015}\approx0.985$$

**Very high similarity (0.985, close to the maximum of 1.0)** — matching our intuition that cat and dog are semantically close.

**Now let's compute cat vs. car:**

$$\mathbf{e}_{\text{cat}}\cdot\mathbf{e}_{\text{car}} = (0.8)(-0.2)+(0.6)(0.1)+(0.1)(0.9)$$

$$= -0.16+0.06+0.09 = -0.01$$

$$\|\mathbf{e}_{\text{car}}\| = \sqrt{(-0.2)^2+0.1^2+0.9^2} = \sqrt{0.04+0.01+0.81}=\sqrt{0.86}\approx0.927$$

$$\text{cosine\_sim}(\text{cat},\text{car}) = \frac{-0.01}{(1.005)(0.927)} = \frac{-0.01}{0.932}\approx-0.0107$$

**Nearly zero (slightly negative) similarity** — matching our intuition that "cat" and "car" (despite sharing similar spelling, which is irrelevant to an embedding, which cares about *meaning/usage context*, not spelling) are semantically unrelated. This is an important point worth emphasizing: **embeddings capture meaning based on usage patterns in training data, completely independent of superficial features like spelling** — "cat" and "car" look similar as strings of letters, but a well-trained embedding correctly places them far apart, because they're used in entirely different contexts.

## 9.6 The Famous Analogy Property: King - Man + Woman ≈ Queen

One of the most celebrated discoveries about word embeddings (from the Word2Vec research, 2013) is that embeddings often capture **relationships** as consistent *directions* in the vector space, enabling vector arithmetic to solve word analogies.

### 9.6.1 The Idea, Explained

Suppose the "difference vector" between "king" and "man" captures something like "the concept of royalty" (since king = man + royalty, roughly speaking). If embeddings capture this consistently, then adding that same "royalty direction" to "woman" should land near "queen":

$$\mathbf{e}_{\text{king}} - \mathbf{e}_{\text{man}} + \mathbf{e}_{\text{woman}} \approx \mathbf{e}_{\text{queen}}$$

### 9.6.2 Fully Worked (Simplified) Numerical Illustration

Let's construct simple toy embeddings designed to numerically demonstrate this relationship, using just 2 dimensions for clarity (dimension 1 = "royalty-ness," dimension 2 = "gender," purely for illustration — real embeddings don't have such clean, human-interpretable dimensions, but the arithmetic works the same way regardless):

$$\mathbf{e}_{\text{king}} = \begin{bmatrix}0.9\\0.8\end{bmatrix}, \quad \mathbf{e}_{\text{man}}=\begin{bmatrix}0.1\\0.8\end{bmatrix}, \quad \mathbf{e}_{\text{woman}}=\begin{bmatrix}0.1\\0.2\end{bmatrix}, \quad \mathbf{e}_{\text{queen}}=\begin{bmatrix}0.9\\0.2\end{bmatrix}$$

(Here, dimension 1 is high [0.9] for royal words, low [0.1] for common words; dimension 2 is high [0.8] for "male-associated" and low [0.2] for "female-associated," in this deliberately simplified illustration.)

**Compute $\mathbf{e}_{\text{king}} - \mathbf{e}_{\text{man}} + \mathbf{e}_{\text{woman}}$:**

$$\begin{bmatrix}0.9\\0.8\end{bmatrix} - \begin{bmatrix}0.1\\0.8\end{bmatrix} + \begin{bmatrix}0.1\\0.2\end{bmatrix}$$

Computing dimension 1: $0.9-0.1+0.1 = 0.9$

Computing dimension 2: $0.8-0.8+0.2 = 0.2$

$$\text{result} = \begin{bmatrix}0.9\\0.2\end{bmatrix}$$

Compare this to $\mathbf{e}_{\text{queen}} = \begin{bmatrix}0.9\\0.2\end{bmatrix}$ — **an exact match** in this clean illustrative example! (Real embeddings, learned from messy real-world text data, only approximate this relationship — it's a strong statistical tendency observed empirically, not a mathematically perfect guarantee for every single analogy — but the effect is genuinely, robustly observed across many word relationships in real trained embeddings, which was a striking and influential discovery.)

## 9.7 Embeddings in Modern LLMs — What Changes at Scale

Everything above describes the *classic* view of embeddings (as popularized by Word2Vec and GloVe, pre-2018 techniques). In modern LLMs, embeddings work on the same fundamental principle (a lookup table matrix, learned via gradient descent), but with important refinements you should know about, since you're specifically building GPT-style models:

1. **Subword tokens, not whole words**: as you already know from your BPE tokenization studies, modern LLMs don't have one embedding per whole word — they have one embedding per **token**, which might be a whole word, part of a word, or even a single character, depending on frequency. This means the "vocabulary" $V$ in our embedding matrix $E$ is actually the tokenizer's vocabulary (commonly 32,000-200,000+ tokens), not a dictionary of whole English words.

2. **Contextual vs. static embeddings**: the embeddings we've discussed so far are **static** — the word "bank" gets the *exact same* embedding vector whether it means "riverbank" or "financial bank." This is a real limitation. Modern Transformer-based LLMs (Step 13 onward) start with these static token embeddings, but then, through the self-attention mechanism (Step 12) and subsequent layers, transform them into **contextual embeddings** — where the *same* token can end up with a *different* final representation depending on the surrounding words. This is a crucial upgrade we'll build up to precisely in later files, but it's built ON TOP of the static embedding lookup described in this section — it's not a replacement for it, but an enrichment of it through subsequent processing.

3. **Learned jointly with the rest of the model**: unlike the historical approach (train Word2Vec embeddings *separately*, then plug them into a downstream model), modern LLMs learn their embedding matrix $E$ **simultaneously** with every other weight in the entire network, all driven by the same backpropagation signal from the same overall training objective (next-token prediction, Step 15). This tends to produce embeddings even more specifically tailored to the exact task the full model needs to perform.

---

# Step 10: RNN (Recurrent Neural Networks)

### Main Question: *How do neural networks process sequences?*

## 10.1 The Everyday Analogy

Imagine you're reading a mystery novel, one word at a time. As you read each new word, you don't process it in complete isolation — you carry forward a **running mental summary** of everything you've read so far ("the butler seemed suspicious a few chapters ago," "the murder happened in the library," "there was a strange noise at midnight"). When you read the next word or sentence, you interpret it **in light of this accumulated understanding** — and then you update your mental summary to incorporate this new information, ready for the next word.

**This exact pattern — maintain a running "memory" that gets updated as you process each new piece of sequential information — is precisely what a Recurrent Neural Network (RNN) does.** The "mental summary" is called the **hidden state**, and it gets passed forward and updated at every single step of the sequence.

## 10.2 The Tech Analogy

Think of an RNN like a **running total in a loop**, similar to code you may have written like:

```python
running_total = 0
for number in list_of_numbers:
    running_total = running_total + number  # update the running memory
```

Except instead of a simple sum, the "update" step is a full neural network computation, and instead of numbers, we're processing a sequence of word embeddings (from Step 9). Another useful tech analogy: a **video game's save state** — a game doesn't need to re-simulate your entire playthrough from the very beginning every time you make a new move; it maintains a compact "current state" (health, inventory, position) that gets updated incrementally with each action, carrying forward exactly the information needed to continue, without needing the entire history explicitly re-processed each time.

## 10.3 Why We Need a New Architecture — the Limitation of MLPs for Sequences

Recall the MLP from File 1, Step 3: it takes a **fixed-size** input vector and produces an output. This creates two fundamental problems for processing language:

**Problem 1 — Variable length**: Sentences have different lengths. "I am happy." (3 words) and "I am extremely happy today because the weather is beautiful." (10 words) cannot both be fed into the same fixed-size-input MLP without some awkward workaround (like padding every sentence to some fixed maximum length, which wastes computation and doesn't elegantly handle sequences longer than that maximum).

**Problem 2 — No sense of order/memory**: Suppose you tried to handle variable length by, say, averaging all the word embeddings in a sentence into one fixed-size vector before feeding it to an MLP. This would make "the dog bit the man" and "the man bit the dog" produce the **exact same input representation** (since averaging ignores word order entirely) — despite these two sentences having drastically different, even opposite, meanings! Language is fundamentally sequential and order-dependent; we need an architecture that respects this.

RNNs solve both problems: they process a sequence **one element at a time**, using the *same* set of weights at every time step (solving the variable-length problem — you just run the loop for as many steps as your sequence has), while maintaining a hidden state that carries forward order-dependent information from earlier in the sequence (solving the no-memory problem).

## 10.4 The Full Mathematics — Step by Step

### 10.4.1 Setting Up Notation

Let's say our input sequence has $T$ time steps (e.g., $T$ words in a sentence), and we denote the input at time step $t$ as $\mathbf{x}_t$ (this would typically be the embedding vector for the $t$-th word, from Step 9).

The RNN maintains a **hidden state** $\mathbf{h}_t$ at each time step — this is the "running mental summary" from our analogy. We initialize $\mathbf{h}_0$ (before processing any input) typically as a vector of all zeros.

### 10.4.2 The Core RNN Update Equation

At every time step $t$, the RNN computes a new hidden state using: (1) the current input $\mathbf{x}_t$, and (2) the **previous** hidden state $\mathbf{h}_{t-1}$ (this is exactly how "memory" gets carried forward):

$$\mathbf{h}_t = f\left(W_{xh}\mathbf{x}_t + W_{hh}\mathbf{h}_{t-1}+\mathbf{b}_h\right)$$

Let's dissect every piece of this equation:

- $W_{xh}$: a weight matrix that transforms the current input $\mathbf{x}_t$ — this is conceptually just like the weight matrices from File 1's MLP.
- $W_{hh}$: a weight matrix that transforms the *previous hidden state* $\mathbf{h}_{t-1}$ — this is the genuinely new ingredient that makes this "recurrent." It's what allows information from step $t-1$ to influence step $t$.
- $\mathbf{b}_h$: a bias vector, same role as always.
- $f$: an activation function, commonly $\tanh$ for RNNs (recall File 1, Section 4.4.2) — chosen partly because its zero-centered, bounded output range $(-1,1)$ helps keep the hidden state's magnitude from growing unboundedly over many time steps.

**Absolutely crucial point**: $W_{xh}$, $W_{hh}$, and $\mathbf{b}_h$ are **the exact same weights, reused at every single time step**. This is called **weight sharing** or **parameter sharing across time**, and it's what allows an RNN to handle sequences of ANY length using a fixed, finite number of parameters — whether your sentence has 3 words or 300 words, you're using the same $W_{xh}$, $W_{hh}$, $\mathbf{b}_h}$ at every step, just running the loop more or fewer times.

### 10.4.3 Producing an Output

Depending on the task, we might want an output $\mathbf{y}_t$ at every time step (e.g., predicting the next word after every word — exactly what a language model needs), or just a single output after processing the entire sequence (e.g., classifying the overall sentiment of a whole sentence). For the "output at every step" case:

$$\mathbf{y}_t = g\left(W_{hy}\mathbf{h}_t+\mathbf{b}_y\right)$$

where $g$ is often softmax (File 1, Section 4.4.6) if we're predicting a probability distribution over possible next words — again, exactly the mechanism underlying every autoregressive language model, now equipped with the machinery (RNN hidden states) to actually process a sequence leading up to that prediction.

### 10.4.4 Unrolling the RNN — A Crucial Visualization Concept

The recurrence relation $\mathbf{h}_t = f(W_{xh}\mathbf{x}_t+W_{hh}\mathbf{h}_{t-1}+\mathbf{b}_h)$ can be **"unrolled"** across time steps, which is the standard way to visualize (and to derive backpropagation for) an RNN. Unrolling simply means: write out the computation graph explicitly for each time step, as if it were a (very deep, but weight-sharing) feedforward network:

$$\mathbf{h}_0 \xrightarrow{\mathbf{x}_1} \mathbf{h}_1 \xrightarrow{\mathbf{x}_2} \mathbf{h}_2 \xrightarrow{\mathbf{x}_3}\mathbf{h}_3 \to \dots \to \mathbf{h}_T$$

Once unrolled, an RNN processing a sequence of length $T$ looks structurally just like a $T$-layer deep feedforward network (from File 2, Step 8) — except **every "layer" shares the exact same weights** ($W_{xh}, W_{hh}, \mathbf{b}_h$). This unrolled view is essential for understanding how RNNs are actually trained.

## 10.5 Fully Worked Numerical Example — Forward Pass Through an RNN

Let's process a tiny 3-word sequence through a small RNN by hand. Suppose our hidden state has dimension 2, and our (already-embedded) input words are 2-dimensional vectors as well, for simplicity.

**Setup:**

Input sequence (already embedded, using Step 9's concept): 
$$\mathbf{x}_1 = \begin{bmatrix}1\\0\end{bmatrix}, \quad \mathbf{x}_2=\begin{bmatrix}0\\1\end{bmatrix}, \quad \mathbf{x}_3=\begin{bmatrix}1\\1\end{bmatrix}$$

Weights:
$$W_{xh} = \begin{bmatrix}0.5 & -0.3\\0.2&0.4\end{bmatrix}, \quad W_{hh}=\begin{bmatrix}0.1&0.2\\-0.1&0.3\end{bmatrix}, \quad \mathbf{b}_h=\begin{bmatrix}0.1\\0.1\end{bmatrix}$$

Initial hidden state: $\mathbf{h}_0 = \begin{bmatrix}0\\0\end{bmatrix}$ (standard choice — no information before the sequence starts)

We'll use $\tanh$ as our activation function $f$.

### 10.5.1 Time Step 1

$$W_{xh}\mathbf{x}_1 = \begin{bmatrix}0.5&-0.3\\0.2&0.4\end{bmatrix}\begin{bmatrix}1\\0\end{bmatrix} = \begin{bmatrix}0.5(1)+(-0.3)(0)\\0.2(1)+0.4(0)\end{bmatrix} = \begin{bmatrix}0.5\\0.2\end{bmatrix}$$

$$W_{hh}\mathbf{h}_0 = \begin{bmatrix}0.1&0.2\\-0.1&0.3\end{bmatrix}\begin{bmatrix}0\\0\end{bmatrix} = \begin{bmatrix}0\\0\end{bmatrix} \quad \text{(anything times the zero vector is zero)}$$

Sum, plus bias:

$$\text{pre-activation} = \begin{bmatrix}0.5\\0.2\end{bmatrix}+\begin{bmatrix}0\\0\end{bmatrix}+\begin{bmatrix}0.1\\0.1\end{bmatrix} = \begin{bmatrix}0.6\\0.3\end{bmatrix}$$

Apply $\tanh$ element-wise. We need $\tanh(0.6)$ and $\tanh(0.3)$:

Using the formula $\tanh(z) = \frac{e^z-e^{-z}}{e^z+e^{-z}}$, or known approximate values: $\tanh(0.6)\approx0.5370$, $\tanh(0.3)\approx0.2913$

$$\mathbf{h}_1 = \begin{bmatrix}0.5370\\0.2913\end{bmatrix}$$

### 10.5.2 Time Step 2

$$W_{xh}\mathbf{x}_2 = \begin{bmatrix}0.5&-0.3\\0.2&0.4\end{bmatrix}\begin{bmatrix}0\\1\end{bmatrix} = \begin{bmatrix}0.5(0)+(-0.3)(1)\\0.2(0)+0.4(1)\end{bmatrix} = \begin{bmatrix}-0.3\\0.4\end{bmatrix}$$

$$W_{hh}\mathbf{h}_1 = \begin{bmatrix}0.1&0.2\\-0.1&0.3\end{bmatrix}\begin{bmatrix}0.5370\\0.2913\end{bmatrix}$$

Computing each row:
Row 1: $(0.1)(0.5370)+(0.2)(0.2913) = 0.05370+0.05826=0.11196$

Row 2: $(-0.1)(0.5370)+(0.3)(0.2913) = -0.05370+0.08739=0.03369$

$$W_{hh}\mathbf{h}_1 = \begin{bmatrix}0.11196\\0.03369\end{bmatrix}$$

Sum, plus bias:

$$\text{pre-activation} = \begin{bmatrix}-0.3\\0.4\end{bmatrix}+\begin{bmatrix}0.11196\\0.03369\end{bmatrix}+\begin{bmatrix}0.1\\0.1\end{bmatrix} = \begin{bmatrix}-0.08804\\0.53369\end{bmatrix}$$

Apply $\tanh$: we need $\tanh(-0.08804)$ and $\tanh(0.53369)$.

$\tanh(-0.08804) \approx -0.0878$ (for small values, $\tanh(z)\approx z$, since $\tanh$ is nearly linear very close to 0 — a useful mental shortcut)

$\tanh(0.53369) \approx 0.4885$ (interpolating from known values: $\tanh(0.5)\approx0.4621$, $\tanh(0.6)\approx0.5370$, and $0.534$ is roughly a third of the way from 0.5 to 0.6, giving approximately $0.4621+0.34\times(0.5370-0.4621)\approx0.4621+0.0255\approx0.4876$; close enough to our stated approximation for hand-calculation purposes)

$$\mathbf{h}_2 \approx \begin{bmatrix}-0.0878\\0.4885\end{bmatrix}$$

### 10.5.3 Time Step 3

$$W_{xh}\mathbf{x}_3 = \begin{bmatrix}0.5&-0.3\\0.2&0.4\end{bmatrix}\begin{bmatrix}1\\1\end{bmatrix} = \begin{bmatrix}0.5-0.3\\0.2+0.4\end{bmatrix} = \begin{bmatrix}0.2\\0.6\end{bmatrix}$$

$$W_{hh}\mathbf{h}_2 = \begin{bmatrix}0.1&0.2\\-0.1&0.3\end{bmatrix}\begin{bmatrix}-0.0878\\0.4885\end{bmatrix}$$

Row 1: $(0.1)(-0.0878)+(0.2)(0.4885) = -0.00878+0.0977=0.08892$

Row 2: $(-0.1)(-0.0878)+(0.3)(0.4885) = 0.00878+0.14655=0.15533$

$$W_{hh}\mathbf{h}_2 = \begin{bmatrix}0.08892\\0.15533\end{bmatrix}$$

Sum, plus bias:

$$\text{pre-activation} = \begin{bmatrix}0.2\\0.6\end{bmatrix}+\begin{bmatrix}0.08892\\0.15533\end{bmatrix}+\begin{bmatrix}0.1\\0.1\end{bmatrix} = \begin{bmatrix}0.38892\\0.85533\end{bmatrix}$$

Apply $\tanh$: $\tanh(0.38892)\approx0.3706$, $\tanh(0.85533)\approx0.6934$

$$\mathbf{h}_3 \approx \begin{bmatrix}0.3706\\0.6934\end{bmatrix}$$

**This final hidden state, $\mathbf{h}_3$, is a vector that has "absorbed" information from all three input words, in order** — it's fundamentally different from, say, just processing $\mathbf{x}_3$ alone, because it carries forward influence from $\mathbf{x}_1$ (via $\mathbf{h}_1$) and $\mathbf{x}_2$ (via $\mathbf{h}_2$), each having been transformed and blended together through the recurrence. If we swapped the order of $\mathbf{x}_1$ and $\mathbf{x}_2$, we would get a **different** $\mathbf{h}_3}$ — confirming the RNN genuinely respects sequence order, directly solving Problem 2 from Section 10.3.

## 10.6 Backpropagation Through Time (BPTT)

Training an RNN requires computing gradients, exactly as in File 2's Step 7 — but since the RNN is "unrolled" across time steps (Section 10.4.4), backpropagation here has a special name: **Backpropagation Through Time (BPTT)**. Conceptually, it is *not* a fundamentally new algorithm — it's the exact same chain-rule-based backward pass from File 2, just applied across the unrolled time-step structure, where gradients flow backward from the last time step toward the first, and — critically — **gradients with respect to the shared weights $W_{xh}, W_{hh}, \mathbf{b}_h$ get accumulated (summed) across every time step**, since those same weights were used at every single step of the sequence.

### 10.6.1 Why This Leads to a Familiar Problem

Let's trace through what happens to a gradient flowing backward from the final hidden state $\mathbf{h}_T$ toward an early hidden state $\mathbf{h}_1$, focusing specifically on how it passes through the $W_{hh}$ term at each step. Using the chain rule (exactly as we derived layer-by-layer gradients in File 2, Section 7.5.4), the gradient of the loss with respect to an early hidden state involves a **repeated multiplication by $W_{hh}$ and by $f'$ (the tanh derivative) at every single intermediate time step**:

$$\frac{\partial\mathcal{L}}{\partial\mathbf{h}_1} \propto \left(\prod_{t=2}^{T} W_{hh}^T \cdot \text{diag}(f'(\mathbf{z}_t))\right) \times \frac{\partial\mathcal{L}}{\partial\mathbf{h}_T}$$

(The $\prod$ symbol means "repeated multiplication," analogous to how $\sum$ means "repeated addition" — here, multiplying together one such term for every time step between $t=2$ and $t=T$.)

**This should look extremely familiar** — it is structurally *identical* to the vanishing/exploding gradient analysis we did in File 2, Section 8.5, for deep feedforward networks! Recall $\tanh'(z)$ has a maximum value of exactly 1 (at $z=0$) and shrinks toward 0 for large $|z|$ (File 1, Section 4.4.2). Just as with deep feedforward networks, repeatedly multiplying by $W_{hh}^T$ and by tanh-derivative terms across MANY time steps (a sentence could easily have 20, 50, or hundreds of words/tokens) causes gradients to either **vanish** (shrink toward zero, if these repeated multiplications tend to shrink the signal) or **explode** (grow unboundedly, if they tend to amplify it).

### 10.6.2 Why This Is Especially Severe for RNNs

For a feedforward network, the number of layers is a fixed architectural choice (you decide "I'll use 12 layers"). But for an RNN, the "effective depth" (in terms of the unrolled computation graph) equals the **length of the input sequence** — and language sequences can easily be dozens or hundreds of tokens long. This makes the vanishing/exploding gradient problem **especially severe and unavoidable** for vanilla RNNs processing anything but short sequences: a 100-word sentence effectively creates a 100-layer-deep unrolled network, all sharing the same weights, and gradient signals from the end of the sequence must survive being multiplied through all 100 of those steps to have any meaningful influence on how the model learns to use information from the very beginning of the sequence.

**Practical consequence**: vanilla RNNs are, in practice, quite bad at **long-range dependencies** — situations where understanding a later part of a sentence requires remembering something from much earlier. Consider: "The cat, which had been sitting quietly on the windowsill all afternoon watching the birds outside, suddenly **jumped**." To correctly predict/understand that "jumped" relates back to "the cat" (agreement in number, and semantic connection), the model needs to carry forward information about "cat" across many intervening words — exactly the scenario where vanishing gradients cripple a vanilla RNN's ability to learn this connection during training.

**This exact problem — vanilla RNNs struggling with long-range dependencies due to vanishing/exploding gradients through time — is the direct motivation for LSTMs and GRUs, which is precisely our next file's subject (Step 11), and eventually for the attention mechanism (Step 12) and Transformers (Step 13), which sidestep this sequential-gradient-decay problem in an entirely different, more powerful way.**

## 10.7 Types of RNN Architectures by Input/Output Structure

Before we close this file, it's worth cataloguing the different ways RNNs can be configured, since you'll encounter all of these patterns in practice:

- **One-to-one**: standard fixed-size input/output (not really using the "recurrent" property at all — this is just a regular feedforward network; included here only for completeness of the taxonomy).
- **One-to-many**: single input, sequence output. Example: image captioning — one image in, a whole sentence describing it out, generated one word at a time.
- **Many-to-one**: sequence input, single output. Example: sentiment classification — a whole product review sentence in, a single "positive/negative" label out. Only the FINAL hidden state $\mathbf{h}_T$ (which has, in principle, absorbed information from the entire sequence) is used for the final prediction.
- **Many-to-many (aligned)**: sequence input, sequence output, one output per input position. Example: predicting the next word after EVERY word in a sentence — exactly what a language model does, and exactly the $\mathbf{y}_t$ output formula from Section 10.4.3.
- **Many-to-many (unaligned/seq2seq)**: sequence input, sequence output, but of potentially DIFFERENT lengths, and not necessarily aligned position-by-position. Example: machine translation — an English sentence of 8 words might translate to a French sentence of 11 words; there's no simple 1-to-1 alignment between input and output positions. This configuration requires a more sophisticated **encoder-decoder** structure (briefly: one RNN "encodes" the entire input sequence into a summary representation, and a second RNN "decodes" that summary into the output sequence, one token at a time) — this exact encoder-decoder pattern, as you'll see, becomes hugely important again when we reach the original Transformer architecture in Step 13, which was originally introduced specifically for machine translation.

---

# Summary Cheat Sheet

**Embeddings** — turning discrete words/tokens into meaningful dense vectors:

$$\mathbf{e}_i = E[i,:] \quad \text{(row } i \text{ of a learned } V\times d \text{ matrix)}$$

$$\text{cosine\_sim}(\mathbf{a},\mathbf{b}) = \frac{\mathbf{a}\cdot\mathbf{b}}{\|\mathbf{a}\|\|\mathbf{b}\|}$$

Learned via ordinary backpropagation, driven by whatever downstream task the full model is trained on. Similar-context words converge to similar vectors as an emergent property of this shared training signal, not by explicit design.

**RNNs** — processing sequences of any length using shared weights and a running hidden state:

$$\mathbf{h}_t = f(W_{xh}\mathbf{x}_t+W_{hh}\mathbf{h}_{t-1}+\mathbf{b}_h)$$

Trained via Backpropagation Through Time (BPTT) — the same chain-rule machinery from File 2, applied across the unrolled sequence — which suffers from vanishing/exploding gradients especially severely, since "depth" here equals sequence length, motivating the next file's LSTM/GRU architectures.

---

# Self-Test Questions

1. Explain, using the library-shelf analogy, why cosine similarity rather than raw dot product is often preferred for comparing embeddings of very different magnitudes.
2. Compute, by hand, the one-hot dot product between any two DIFFERENT words in a 5-word vocabulary, and confirm it's always exactly 0, explaining why in your own words.
3. Given toy 2D embeddings $\mathbf{e}_a=[0.6,0.8]$ and $\mathbf{e}_b=[0.8,0.6]$, compute their cosine similarity by hand, showing every step (dot product, both magnitudes, then the division).
4. In your own words, explain why embeddings are described as "emergent" from training rather than explicitly designed, tying this back to the backpropagation mechanics from File 2.
5. Write out, from memory, the core RNN recurrence equation, and explain what each of the three weight matrices/vectors does.
6. Explain why processing "the man bit the dog" versus "the dog bit the man" through an RNN produces different final hidden states, while a simple bag-of-words averaging approach would not distinguish them.
7. In the fully worked RNN example (Section 10.5), recompute $\mathbf{h}_2$ if $\mathbf{x}_2$ had instead been $\begin{bmatrix}1\\0\end{bmatrix}$ (same as $\mathbf{x}_1$), and compare your result to the original $\mathbf{h}_2$ — is it identical to $\mathbf{h}_1$? Why or why not?
8. Explain, using the concept of "effective depth equals sequence length," why vanishing gradients are a more severe practical problem for RNNs processing long sentences than for a fixed, moderately-deep feedforward network.
9. Give a concrete example sentence (different from the "cat...jumped" example in this file) illustrating a long-range dependency that a vanilla RNN would likely struggle to learn.
10. Match each of the five RNN input/output configurations (one-to-one, one-to-many, many-to-one, many-to-many aligned, many-to-many unaligned/seq2seq) to a real-world task not mentioned in this file.

---

*End of File 3. File 4 will cover: LSTM/GRU and Attention (Steps 11-12) — first, the gating mechanisms that specifically fix the vanishing gradient problem for sequences, and then the attention mechanism, which will fundamentally change how we think about processing sequences altogether, moving away from strict step-by-step recurrence entirely.*

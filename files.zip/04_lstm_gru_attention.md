# File 4 of 20: Fixing Memory, Then Reinventing It
## LSTM/GRU → Attention

> **Continuity note**: File 3 ended by identifying a serious problem: vanilla RNNs suffer from vanishing/exploding gradients across long sequences, making them poor at long-range dependencies. This file solves that problem twice, in two very different ways. First, **LSTMs and GRUs** patch the RNN architecture with clever "gates" that let gradients flow more freely across time. Then, **Attention** throws out the sequential bottleneck entirely, allowing any position in a sequence to directly look at any other position, regardless of distance. Attention is the single most important mechanism in this entire 20-file series — it is the mathematical heart of every Transformer, and therefore every modern LLM, including the model writing this sentence.

---

# Table of Contents

1. [Step 11: LSTM/GRU](#step-11-lstmgru)
2. [Step 12: Attention](#step-12-attention)
3. [Summary Cheat Sheet](#summary-cheat-sheet)
4. [Self-Test Questions](#self-test-questions)

---

# Step 11: LSTM/GRU

### Main Question: *Why wasn't vanilla RNN enough?*

## 11.1 The Everyday Analogy

Imagine your brain's short-term memory works like a **whiteboard** that gets erased and rewritten at every single moment, with no way to protect important information from being overwritten. If you're told "remember the number 47" and then, one second later, told "now remember the number 92," your vanilla-RNN-brain would completely overwrite 47 with 92, with no ability to selectively decide "actually, 47 was important, let me hang onto that specifically, even while processing new information."

Now imagine instead your brain has a **notebook with a smart editor**: an editor who, at every new piece of information, asks three questions: (1) "should I erase anything currently written in the notebook?" (2) "should I write this new information into the notebook?" and (3) "given everything currently in the notebook, what's actually relevant to say or act on right now?" This deliberate, selective control over what to keep, what to discard, and what to output is exactly what an **LSTM (Long Short-Term Memory)** network provides — it doesn't just blindly overwrite its memory at every step like a vanilla RNN; it has learned, deliberate gates controlling the flow of information.

## 11.2 The Tech Analogy

Think of an LSTM like a **version-controlled database with fine-grained write permissions**, as opposed to a vanilla RNN, which is like a single global variable that gets reassigned completely on every loop iteration:

```python
# Vanilla RNN - completely overwrites state every step
state = new_computation(state, input)

# LSTM - selectively updates state with fine-grained control
if forget_gate_says_so:
    state = erase_some_parts(state)
if input_gate_says_so:
    state = add_some_new_info(state, input)
output = decide_what_to_expose(state)  # output gate
```

Or think of it like a **shopping cart on an e-commerce site with smart auto-management**: some items get removed (forgotten) because they went out of stock or you removed them, new items get added (input) based on what you're currently browsing, and what's shown in your cart summary widget (output) might be a filtered/relevant view rather than literally everything ever added.

## 11.3 The Full Mathematics — Building Up Every Gate From Scratch

### 11.3.1 The Core Idea: Separate the "Memory" From the "Working Output"

The single most important structural change LSTMs make, compared to vanilla RNNs, is to maintain **two** separate vectors instead of one:

- **Cell state** $\mathbf{c}_t$: the long-term memory — designed to flow through time with minimal, carefully-controlled modification, specifically to avoid the repeated-multiplication vanishing gradient problem from File 3.
- **Hidden state** $\mathbf{h}_t$: the "working output" at this time step — a filtered, task-relevant view derived from the cell state, similar in spirit to the hidden state in a vanilla RNN.

### 11.3.2 The Forget Gate — Deciding What to Erase From Memory

The first gate decides: **of everything currently in the cell state (long-term memory), what should we discard?**

$$\mathbf{f}_t = \sigma\left(W_f[\mathbf{h}_{t-1},\mathbf{x}_t]+\mathbf{b}_f\right)$$

Let's unpack this carefully:

- $[\mathbf{h}_{t-1},\mathbf{x}_t]$ denotes **concatenation** — stacking the previous hidden state and the current input into one longer vector. (E.g., if $\mathbf{h}_{t-1}$ has 4 dimensions and $\mathbf{x}_t$ has 3 dimensions, this concatenated vector has 7 dimensions.) This is just a notational convenience — it lets us write one weight matrix $W_f$ instead of two separate matrices multiplying $\mathbf{h}_{t-1}$ and $\mathbf{x}_t$ individually and then adding the results (both approaches are mathematically equivalent).
- $\sigma$ is the **sigmoid** function (File 1, Section 4.4.1) — and this choice is deliberate and crucial: sigmoid squashes its output into the range $(0,1)$, which lets us interpret each entry of $\mathbf{f}_t$ as a **"keep percentage"** — 0 means "completely forget this piece of memory," 1 means "completely retain it," and values in between mean partial retention.

**Why is this gate learned, rather than fixed?** The weights $W_f$ and bias $\mathbf{b}_f$ are ordinary trainable parameters, updated via backpropagation exactly like every other weight we've discussed. The network **learns**, from data, what kinds of situations call for forgetting old information versus retaining it — for example, it might learn that encountering a period "." or a new paragraph is a good signal to forget certain kinds of short-term contextual information, since a new sentence or topic may be starting.

### 11.3.3 The Input Gate — Deciding What New Information to Add

Next, we need to decide what NEW information from the current input should be added to the cell state. This actually involves two sub-computations:

**Sub-computation 1 — the "candidate" new information** (what COULD be added, computed the same way a vanilla RNN would compute its hidden state):

$$\tilde{\mathbf{c}}_t = \tanh\left(W_c[\mathbf{h}_{t-1},\mathbf{x}_t]+\mathbf{b}_c\right)$$

We use $\tanh$ here (not sigmoid) because we want this candidate vector's values to range over $(-1,1)$ — allowing the new information to either increase or decrease each dimension of the memory, not just contribute a bounded-positive-only amount.

**Sub-computation 2 — the input gate itself** (HOW MUCH of that candidate should actually be added, using the same sigmoid-gate pattern as the forget gate):

$$\mathbf{i}_t = \sigma\left(W_i[\mathbf{h}_{t-1},\mathbf{x}_t]+\mathbf{b}_i\right)$$

Again, sigmoid squashes this into $(0,1)$, representing "how much of the candidate information to actually let in" — 0 means "ignore this candidate entirely," 1 means "fully incorporate it."

### 11.3.4 Updating the Cell State — Combining Forget and Input

Now we can write the actual cell state update equation, combining everything above:

$$\mathbf{c}_t = \mathbf{f}_t \odot \mathbf{c}_{t-1} + \mathbf{i}_t \odot \tilde{\mathbf{c}}_t$$

Recall $\odot$ means element-wise multiplication (File 2, Section 7.5.3). Let's carefully parse this equation, term by term:

- $\mathbf{f}_t \odot \mathbf{c}_{t-1}$: take the OLD cell state, and multiply each of its dimensions by the corresponding "keep percentage" from the forget gate. If $f_t$'s value in some dimension is 0.1, that means "keep only 10% of whatever was stored in this dimension of memory" — effectively mostly erasing it.
- $\mathbf{i}_t \odot \tilde{\mathbf{c}}_t$: take the NEW candidate information, and scale it by "how much to actually let in," per dimension.
- **Add these two pieces together** to get the new cell state.

**This is the single most important equation in the entire LSTM architecture**, and it's worth pausing to appreciate exactly why it solves the vanishing gradient problem. Notice: unlike the vanilla RNN's hidden state update (File 3, Section 10.4.2), which passes the previous state through a matrix multiplication AND a squashing non-linearity at every step (both of which contribute to gradient shrinkage), the cell state update here involves the previous cell state $\mathbf{c}_{t-1}$ being multiplied only by $\mathbf{f}_t$ (an element-wise gate, NOT a full matrix multiplication) and then simply **added** to new information — no repeated matrix multiplication chain, no squashing non-linearity directly applied to $\mathbf{c}_{t-1}$ itself. If the forget gate learns to output values close to 1 (i.e., "keep almost everything"), gradients can flow backward through many time steps via this addition-based pathway with very little shrinkage — directly counteracting the repeated-multiplication vanishing gradient problem we derived precisely in File 3, Section 10.6.1.

### 11.3.5 The Output Gate — Deciding What to Expose as the Hidden State

Finally, we compute the hidden state $\mathbf{h}_t$ (the "working output" for this time step) as a filtered view of the cell state:

$$\mathbf{o}_t = \sigma\left(W_o[\mathbf{h}_{t-1},\mathbf{x}_t]+\mathbf{b}_o\right)$$

$$\mathbf{h}_t = \mathbf{o}_t \odot \tanh(\mathbf{c}_t)$$

We apply $\tanh$ to squash the (potentially large-magnitude, since it's been accumulating via addition) cell state back into a bounded $(-1,1)$ range, and then use the output gate $\mathbf{o}_t$ to decide how much of each dimension to actually expose as the hidden state used for predictions or passed to the next layer.

## 11.4 Fully Worked Numerical Example — One Complete LSTM Step

Let's compute one full LSTM time step by hand, using small 1-dimensional cell/hidden states and 1-dimensional input, for maximum clarity (real LSTMs use vectors with many dimensions, but the exact same scalar arithmetic applies to every single dimension independently, since all our gate operations are element-wise).

**Setup:**

Previous hidden state: $h_{t-1}=0.3$. Previous cell state: $c_{t-1}=0.5$. Current input: $x_t=1.0$.

(Since everything is 1-dimensional here, "concatenation" $[h_{t-1},x_t]$ is just the pair $(0.3, 1.0)$, and each weight "matrix" $W$ is really just two scalar weights, one for each of $h_{t-1}$ and $x_t$.)

Weights (all chosen arbitrarily for this illustration):

Forget gate: $w_{f,h}=0.5, w_{f,x}=0.3, b_f=0.1$

Input gate: $w_{i,h}=0.6, w_{i,x}=0.4, b_i=-0.1$

Candidate: $w_{c,h}=0.4, w_{c,x}=0.5, b_c=0.0$

Output gate: $w_{o,h}=0.3, w_{o,x}=0.6, b_o=0.1$

### 11.4.1 Compute the Forget Gate

$$f_t = \sigma(w_{f,h}h_{t-1}+w_{f,x}x_t+b_f)$$

$$= \sigma\left((0.5)(0.3)+(0.3)(1.0)+0.1\right)$$

$$= \sigma(0.15+0.3+0.1) = \sigma(0.55)$$

We need $\sigma(0.55) = \frac{1}{1+e^{-0.55}}$. Using $e^{-0.55}\approx0.5769$:

$$f_t = \frac{1}{1.5769}\approx0.6342$$

### 11.4.2 Compute the Input Gate

$$i_t = \sigma(w_{i,h}h_{t-1}+w_{i,x}x_t+b_i)$$

$$= \sigma\left((0.6)(0.3)+(0.4)(1.0)+(-0.1)\right)$$

$$= \sigma(0.18+0.4-0.1) = \sigma(0.48)$$

Using $e^{-0.48}\approx0.6188$:

$$i_t = \frac{1}{1.6188}\approx0.6177$$

### 11.4.3 Compute the Candidate Cell State

$$\tilde{c}_t = \tanh(w_{c,h}h_{t-1}+w_{c,x}x_t+b_c)$$

$$= \tanh\left((0.4)(0.3)+(0.5)(1.0)+0\right)$$

$$= \tanh(0.12+0.5) = \tanh(0.62)$$

Using $\tanh(0.62)\approx0.5511$:

$$\tilde{c}_t \approx 0.5511$$

### 11.4.4 Update the Cell State

$$c_t = f_t \cdot c_{t-1} + i_t \cdot \tilde{c}_t$$

$$= (0.6342)(0.5) + (0.6177)(0.5511)$$

Computing each term:
$$(0.6342)(0.5) = 0.3171$$
$$(0.6177)(0.5511) \approx 0.3404$$

$$c_t = 0.3171+0.3404 = 0.6575$$

Notice the new cell state (0.6575) is a genuinely blended combination: 63.4% of the old memory (0.5) was retained, PLUS a substantial (61.8%-scaled) contribution from the new candidate information (0.5511) — precisely the "selective update" behavior we described in the analogy at the start of this section.

### 11.4.5 Compute the Output Gate

$$o_t = \sigma(w_{o,h}h_{t-1}+w_{o,x}x_t+b_o)$$

$$= \sigma\left((0.3)(0.3)+(0.6)(1.0)+0.1\right)$$

$$= \sigma(0.09+0.6+0.1) = \sigma(0.79)$$

Using $e^{-0.79}\approx0.4538$:

$$o_t = \frac{1}{1.4538}\approx0.6879$$

### 11.4.6 Compute the New Hidden State

$$h_t = o_t \cdot \tanh(c_t) = 0.6879 \times \tanh(0.6575)$$

We need $\tanh(0.6575)$. Interpolating from known values ($\tanh(0.6)\approx0.5370$, $\tanh(0.7)\approx0.6044$): approximately $\tanh(0.6575)\approx0.5772$

$$h_t = 0.6879 \times 0.5772 \approx 0.3971$$

**Final result**: $c_t \approx 0.6575$ (updated long-term memory), $h_t\approx0.3971$ (this time step's working output). This pair $(c_t, h_t)$ gets passed forward to the next time step, where the exact same six equations (forget gate, input gate, candidate, cell update, output gate, hidden state) get applied again, with $x_{t+1}$ as the new input.

## 11.5 GRU (Gated Recurrent Unit) — A Simplified Alternative

The GRU, introduced later than the LSTM, achieves similar gradient-flow benefits with a **simpler** structure — notably, it merges the cell state and hidden state into a single vector, and uses only 2 gates instead of LSTM's 3.

### 11.5.1 The Full Mathematics

**Update gate** (plays a role similar to a combined forget+input gate):

$$\mathbf{z}_t = \sigma\left(W_z[\mathbf{h}_{t-1},\mathbf{x}_t]+\mathbf{b}_z\right)$$

**Reset gate** (decides how much of the previous hidden state to consider when computing the new candidate):

$$\mathbf{r}_t = \sigma\left(W_r[\mathbf{h}_{t-1},\mathbf{x}_t]+\mathbf{b}_r\right)$$

**Candidate hidden state** (notice $\mathbf{r}_t$ is applied to $\mathbf{h}_{t-1}$ BEFORE it's used to compute the candidate — this is the "reset" in action, letting the model decide to ignore some of the past when forming new candidate information):

$$\tilde{\mathbf{h}}_t = \tanh\left(W_h[\mathbf{r}_t\odot\mathbf{h}_{t-1},\mathbf{x}_t]+\mathbf{b}_h\right)$$

**Final hidden state update** (a single equation blends old and new, using the update gate to interpolate):

$$\mathbf{h}_t = (1-\mathbf{z}_t)\odot\mathbf{h}_{t-1} + \mathbf{z}_t \odot \tilde{\mathbf{h}}_t$$

### 11.5.2 Understanding the Final Update Equation

This last equation deserves special attention because of its elegant structure: it's a **weighted average** (technically, a convex combination, since the weights $1-\mathbf{z}_t$ and $\mathbf{z}_t$ always sum to exactly 1) between the old hidden state and the new candidate. If $z_t=0$ in some dimension: $h_t = 1\cdot h_{t-1}+0\cdot\tilde{h}_t = h_{t-1}$ — completely retain the old value, ignore the candidate entirely. If $z_t=1$: $h_t = 0\cdot h_{t-1}+1\cdot\tilde{h}_t=\tilde{h}_t$ — completely replace with the new candidate. Values in between blend proportionally. This single equation elegantly achieves what took LSTM two separate gates (forget + input) and two separate multiplications to accomplish, which is why GRUs are often described as a computationally cheaper, nearly-as-effective alternative to LSTMs — with roughly 25% fewer parameters for an equivalent hidden size, since there's one fewer gate to compute.

### 11.5.3 Fully Worked Numerical Example — GRU

Using the same style of small scalar example as Section 11.4, let's compute one GRU step.

**Setup**: $h_{t-1}=0.3$, $x_t=1.0$.

Update gate weights: $w_{z,h}=0.5, w_{z,x}=0.3, b_z=0$

Reset gate weights: $w_{r,h}=0.4, w_{r,x}=0.2, b_r=0$

Candidate weights: $w_{h,h}=0.6, w_{h,x}=0.5, b_h=0$

**Step 1 — update gate:**

$$z_t = \sigma((0.5)(0.3)+(0.3)(1.0)) = \sigma(0.15+0.3)=\sigma(0.45)$$

Using $e^{-0.45}\approx0.6376$: $z_t = \frac{1}{1.6376}\approx0.6106$

**Step 2 — reset gate:**

$$r_t = \sigma((0.4)(0.3)+(0.2)(1.0)) = \sigma(0.12+0.2)=\sigma(0.32)$$

Using $e^{-0.32}\approx0.7261$: $r_t = \frac{1}{1.7261}\approx0.5793$

**Step 3 — candidate hidden state** (note: multiply $r_t$ by $h_{t-1}$ first):

$$r_t \cdot h_{t-1} = 0.5793\times0.3 = 0.17379$$

$$\tilde{h}_t = \tanh\left((0.6)(0.17379)+(0.5)(1.0)\right) = \tanh(0.10427+0.5)=\tanh(0.60427)$$

Using $\tanh(0.6)\approx0.5370$ as a close approximation: $\tilde{h}_t\approx0.5401$ (slight upward adjustment for the extra 0.00427)

**Step 4 — final hidden state:**

$$h_t = (1-z_t)h_{t-1}+z_t\tilde{h}_t = (1-0.6106)(0.3)+(0.6106)(0.5401)$$

$$= (0.3894)(0.3)+(0.6106)(0.5401)$$

$$= 0.11682+0.32979$$

$$h_t \approx 0.4466$$

**Compare to the LSTM's result** ($h_t\approx0.3971$ from Section 11.4.6) — different numerical value, as expected since these are different architectures with different (arbitrarily chosen, for illustration) weights, but structurally, both computations achieve the same conceptual goal: blending old memory with new information in a learned, controlled way, rather than the vanilla RNN's uncontrolled full overwrite.

## 11.6 LSTM/GRU vs. Vanilla RNN — Summary of the Fix

| Aspect | Vanilla RNN | LSTM | GRU |
|---|---|---|---|
| Memory update mechanism | Full overwrite via matrix mult + nonlinearity | Additive update via gates | Weighted blend via update gate |
| Number of gates | 0 | 3 (forget, input, output) | 2 (update, reset) |
| Separate cell state? | No | Yes ($c_t$ separate from $h_t$) | No (merged into $h_t$) |
| Long-range dependency handling | Poor (severe vanishing gradients) | Much improved | Much improved, comparable to LSTM |
| Relative computational cost | Lowest | Highest | Middle |

## 11.7 The Remaining Limitation — Why Even LSTMs/GRUs Weren't the Final Answer

LSTMs and GRUs significantly improved long-range dependency handling compared to vanilla RNNs, and they were the dominant architecture for sequence modeling for several years (roughly 2014-2017). However, they retain one fundamental limitation that neither gating mechanism solves: **they still process sequences strictly one step at a time**, which creates two remaining problems:

1. **Sequential computation cannot be parallelized**: to compute $\mathbf{h}_{100}$, you MUST first compute $\mathbf{h}_1, \mathbf{h}_2, \dots, \mathbf{h}_{99}$ in strict order — there's no way to compute step 100 without waiting for step 99, which waited for step 98, and so on. On modern hardware (GPUs/TPUs, which excel at massively parallel computation), this strict sequential dependency is a severe bottleneck, since you cannot use the hardware's parallel processing power to speed up processing a single long sequence.

2. **Even with gating, very long-range dependencies still degrade**: while LSTMs/GRUs dramatically help compared to vanilla RNNs, information still has to flow through many sequential steps to connect very distant parts of a long sequence (a 1,000-word document, for instance) — and in practice, even gated architectures show measurably degrading performance on dependencies spanning very long distances.

**This is exactly the motivation for the Attention mechanism**, our next topic, which we will show completely sidesteps BOTH of these problems: attention allows **direct, single-step connections between any two positions in a sequence, regardless of distance, and can be computed in parallel across the entire sequence at once.**

---

# Step 12: Attention

### Main Question: *How can a model focus on relevant tokens?*

## 12.1 The Everyday Analogy

Imagine you're in a noisy classroom with 30 students all talking at once, and your teacher asks you a specific question: "What did Priya say about the homework?" To answer, you don't process every single student's voice with equal attention — you **selectively focus** on Priya's voice specifically, tuning out (though not entirely ignoring — you might still catch your name mentioned elsewhere) the other 29 conversations.

Crucially, notice that WHO you pay attention to depends entirely on WHAT you're currently trying to figure out (the question about homework, specifically about Priya). If instead you were asked "What did Rohan say about the exam?", you'd redirect your attention to Rohan instead. **This dynamic, question-dependent, selective focusing is exactly what the attention mechanism formalizes mathematically** — for every word being processed, attention computes exactly which other words (across the entire sequence, regardless of distance) are most relevant to focus on right now, and blends information from them accordingly.

## 12.2 The Tech Analogy

Think of attention like a **highly intelligent, context-aware search engine operating INSIDE the neural network**, at every single position of a sequence. When you type a search query, a search engine doesn't treat every webpage in its index with equal importance — it computes a **relevance score** between your specific query and every candidate document, then returns results weighted heavily toward the most relevant ones, while still being aware (with much lower weight) that other documents exist.

In fact, this analogy isn't just a loose comparison — the actual terminology used in the attention mechanism is **literally borrowed from database/information-retrieval systems**: we compute a **Query**, compare it against a set of **Keys**, and use the resulting relevance scores to weight a combination of **Values.** We will now build this up in complete mathematical detail, since this Query-Key-Value (QKV) framework is the single most important piece of machinery in this entire 20-file series.

## 12.3 The Core Problem Attention Solves, Restated Precisely

Recall from Step 11.7: RNN-family architectures (vanilla RNN, LSTM, GRU) process information by passing it through a **sequential chain** of hidden states — information from position 1 can only reach position 100 by flowing through positions 2, 3, 4, ..., 99 first, getting transformed (and partially degraded/forgotten) at every intermediate step.

**Attention asks a radically different question**: what if, instead of forcing information to flow through a long sequential chain, we let **every position directly access every other position**, in a single computational step, with the model **learning** how much attention to pay to each other position, depending on relevance? 

## 12.4 The Full Mathematics — Query, Key, Value, Built From Absolute Scratch

### 12.4.1 Setting Up: What We Start With

Suppose we have a sequence of $n$ tokens, and each token currently has some vector representation — let's call the representation of token $i$ simply $\mathbf{x}_i$ (this might be a word embedding from Step 9, or, in a deeper network, the output of a previous layer — the attention mechanism doesn't care which; it just needs *some* vector per token to work with).

### 12.4.2 The Three Learned Projections: Query, Key, Value

For every single token $i$, we compute THREE separate vectors, each via its own learned weight matrix:

$$\mathbf{q}_i = W_Q \mathbf{x}_i \qquad \text{(the "Query" vector)}$$
$$\mathbf{k}_i = W_K \mathbf{x}_i \qquad \text{(the "Key" vector)}$$
$$\mathbf{v}_i = W_V \mathbf{x}_i \qquad \text{(the "Value" vector)}$$

$W_Q, W_K, W_V$ are all separate, learned weight matrices — ordinary trainable parameters, exactly like every weight matrix we've discussed since File 1, updated via backpropagation.

**What do these three vectors conceptually represent?** This is the single most important intuition to internalize before diving into the formulas:

- **Query** ($\mathbf{q}_i$): represents "what is token $i$ currently looking for / asking about?" — think of this as the specific question Priya's classmate is implicitly asking in our analogy ("What did Priya say about homework?").
- **Key** ($\mathbf{k}_i$): represents "what does token $i$ have to offer, as advertised to others who might be looking for it?" — think of this as each student's "topic tag," e.g., Priya's key might signal "I'm currently discussing: homework, math, tomorrow's deadline."
- **Value** ($\mathbf{v}_i$): represents "the actual content/information token $i$ will contribute, if attended to" — this is the actual substance of what Priya said, which gets passed along IF she's the one being attended to.

**Why do we need THREE separate vectors, rather than just directly comparing the raw $\mathbf{x}_i$ vectors to each other?** This is a subtle but important design choice: it allows the "matching criterion" (Query vs Key comparison) to be **learned separately** from "what information actually gets passed along" (the Value). A token's raw representation $\mathbf{x}_i$ might contain many different kinds of information (grammatical role, semantic meaning, position in sentence, etc.), and separating Query/Key (used purely for computing WHO should attend to WHOM) from Value (used for WHAT information actually flows) gives the network flexibility to learn specialized, different projections for these two distinct purposes — rather than being forced to use the exact same representation for both "how should I be found" and "what do I actually contain."

### 12.4.3 Step 1 of the Attention Computation: Compute Relevance Scores

For a given query position $i$ (the token currently "asking a question"), we compute how relevant EVERY other token $j$ in the sequence is, by taking the **dot product** between $\mathbf{q}_i$ and every $\mathbf{k}_j$:

$$\text{score}(i,j) = \mathbf{q}_i \cdot \mathbf{k}_j$$

**Why the dot product specifically?** Recall from Step 9.5.1: the dot product between two vectors is large (positive) when they point in similar directions, and small/negative when they don't. So, if token $i$'s query vector happens to point in a similar direction to token $j$'s key vector, their dot product will be large — signaling "token $j$ offers exactly the kind of information token $i$ is looking for." This is a direct, elegant reuse of the exact similarity-measuring intuition we built for embeddings in Step 9.

### 12.4.4 Step 2: Scaling — Why We Divide by $\sqrt{d_k}$

The actual formula used in practice includes a scaling factor:

$$\text{score}(i,j) = \frac{\mathbf{q}_i\cdot\mathbf{k}_j}{\sqrt{d_k}}$$

where $d_k$ is the dimensionality of the key/query vectors.

**Why is this scaling necessary? Let's derive the reasoning precisely.** Suppose each individual component of $\mathbf{q}_i$ and $\mathbf{k}_j$ is a random value with mean 0 and variance 1 (a reasonable assumption for freshly-initialized or well-normalized network activations). The dot product is:

$$\mathbf{q}_i\cdot\mathbf{k}_j = \sum_{m=1}^{d_k} q_{i,m}k_{j,m}$$

This is a sum of $d_k$ independent random terms, each with mean 0. By basic properties of variance (variance of a sum of independent random variables equals the sum of their variances, and the variance of a product of two independent mean-0, variance-1 random variables is 1), the **variance of this entire sum grows linearly with $d_k$**:

$$\text{Var}(\mathbf{q}_i\cdot\mathbf{k}_j) = d_k \times \text{Var}(q_{i,m}k_{j,m}) = d_k \times 1 = d_k$$

So the *standard deviation* (square root of variance) of the dot product grows as $\sqrt{d_k}$. This means: **as we increase the dimensionality $d_k$ of our query/key vectors (which we do, in practice — real Transformers use $d_k$ values like 64, 128, or more per attention head), the raw dot products naturally become larger in magnitude, purely as a side effect of summing more terms — not because the tokens are genuinely "more relevant" to each other.**

**Why is large-magnitude score bad?** Because these scores get passed through softmax next (Section 12.4.5), and recall from File 1, Section 4.4.1's discussion of sigmoid (and the same logic applies to softmax, which is built from the same exponential function): very large input magnitudes push softmax into a **saturated regime**, where the output becomes extremely close to a one-hot vector (nearly all probability mass on the single largest score, nearly zero everywhere else) — and in this saturated regime, softmax's gradient becomes vanishingly small (directly analogous to the vanishing gradient problem for sigmoid we derived precisely in File 1, Section 4.4.1). This would severely hinder training via backpropagation.

**Dividing by $\sqrt{d_k}$ exactly cancels out this growth**: since the standard deviation of the raw dot product scales as $\sqrt{d_k}$, dividing by $\sqrt{d_k}$ renormalizes the scores back to having a standard deviation of approximately 1, regardless of how large $d_k$ is — keeping the softmax input in a well-behaved numerical range, avoiding saturation, and preserving healthy gradients for training. This is precisely why this mechanism is officially called **"Scaled Dot-Product Attention."**

### 12.4.5 Step 3: Softmax — Converting Scores Into Attention Weights

For query position $i$, we now have a raw score against every key position $j=1,\dots,n$. We convert these into a proper probability distribution using **softmax** (File 1, Section 4.4.6) — exactly the same function, applied here to attention scores instead of classification logits:

$$\alpha_{i,j} = \text{softmax}_j\left(\frac{\mathbf{q}_i\cdot\mathbf{k}_j}{\sqrt{d_k}}\right) = \frac{\exp\left(\frac{\mathbf{q}_i\cdot\mathbf{k}_j}{\sqrt{d_k}}\right)}{\sum_{j'=1}^{n}\exp\left(\frac{\mathbf{q}_i\cdot\mathbf{k}_{j'}}{\sqrt{d_k}}\right)}$$

$\alpha_{i,j}$ is called the **attention weight** — it represents "how much should position $i$ attend to position $j$," and crucially, for a fixed $i$, these weights across all $j$ sum to exactly 1 (a valid probability distribution, exactly as we verified for softmax in File 1, Section 4.4.6).

### 12.4.6 Step 4: Weighted Sum of Values — Producing the Output

Finally, we compute the output for position $i$ as a **weighted average of every token's Value vector**, using the attention weights as the weights:

$$\mathbf{z}_i = \sum_{j=1}^{n}\alpha_{i,j}\mathbf{v}_j$$

**This is the final output of the attention mechanism for position $i$**: a blended combination of information from every position in the sequence, where positions deemed highly relevant (high $\alpha_{i,j}$) contribute much more to the blend, and irrelevant positions (low $\alpha_{i,j}$, possibly near 0) contribute almost nothing — all computed via one direct, single-step weighted average, with **no sequential chain of hidden states required at all.**

### 12.4.7 The Compact Matrix Formula

All of the above, across an entire sequence at once (not just one query position $i$), is typically written in one compact matrix equation. If $Q, K, V$ are matrices where row $i$ contains $\mathbf{q}_i, \mathbf{k}_i, \mathbf{v}_i$ respectively:

$$\text{Attention}(Q,K,V) = \text{softmax}\left(\frac{QK^T}{\sqrt{d_k}}\right)V$$

Every piece of this matches what we derived step by step above: $QK^T$ computes ALL pairwise dot products between every query and every key simultaneously (a single matrix multiplication produces the entire $n \times n$ grid of scores at once); dividing by $\sqrt{d_k}$ applies our derived scaling; softmax (applied row-wise, so each row/query position gets its own normalized probability distribution over all key positions) converts scores to attention weights; and multiplying by $V$ computes the weighted sum of value vectors for every query position simultaneously, in one final matrix multiplication.

## 12.5 Fully Worked Numerical Example — Complete Attention Computation

Let's compute self-attention (meaning: the queries, keys, AND values all come from the same sequence — every token attends to every token in the same sentence, including itself) for a tiny 3-token sequence, with everything computed by hand.

**Setup**: Suppose after applying $W_Q, W_K, W_V$ (we'll skip the projection step and just directly specify the resulting Q, K, V vectors for simplicity, as if these projections have already happened), we have, for 3 tokens, with $d_k=2$:

$$\mathbf{q}_1=\begin{bmatrix}1\\0\end{bmatrix}, \mathbf{q}_2=\begin{bmatrix}0\\1\end{bmatrix}, \mathbf{q}_3=\begin{bmatrix}1\\1\end{bmatrix}$$

$$\mathbf{k}_1=\begin{bmatrix}1\\0\end{bmatrix}, \mathbf{k}_2=\begin{bmatrix}0\\1\end{bmatrix}, \mathbf{k}_3=\begin{bmatrix}1\\1\end{bmatrix}$$

$$\mathbf{v}_1=\begin{bmatrix}10\\0\end{bmatrix}, \mathbf{v}_2=\begin{bmatrix}0\\10\end{bmatrix}, \mathbf{v}_3=\begin{bmatrix}5\\5\end{bmatrix}$$

(Notice, for this illustration, $Q=K$, meaning queries and keys are identical vectors — this is a simplification purely to make hand-computation easier; in a real trained network, $W_Q \neq W_K$ in general, so $Q$ and $K$ would differ even for the same input tokens.)

**We'll compute the full output for query position $i=1$ (i.e., $\mathbf{z}_1$).**

### 12.5.1 Step 1 — Raw Dot Product Scores

$$\mathbf{q}_1\cdot\mathbf{k}_1 = (1)(1)+(0)(0) = 1$$

$$\mathbf{q}_1\cdot\mathbf{k}_2 = (1)(0)+(0)(1) = 0$$

$$\mathbf{q}_1\cdot\mathbf{k}_3 = (1)(1)+(0)(1) = 1$$

### 12.5.2 Step 2 — Scale by $\sqrt{d_k}$

Here $d_k=2$, so $\sqrt{d_k}=\sqrt{2}\approx1.4142$.

$$\text{score}(1,1) = \frac{1}{1.4142}\approx0.7071$$

$$\text{score}(1,2) = \frac{0}{1.4142}=0$$

$$\text{score}(1,3) = \frac{1}{1.4142}\approx0.7071$$

### 12.5.3 Step 3 — Softmax

We need $e^{0.7071}$, $e^0$, $e^{0.7071}$.

$$e^{0.7071}\approx2.0281$$
$$e^0 = 1$$

Sum: $2.0281+1+2.0281 = 5.0562$

$$\alpha_{1,1} = \frac{2.0281}{5.0562}\approx0.4011$$

$$\alpha_{1,2} = \frac{1}{5.0562}\approx0.1978$$

$$\alpha_{1,3} = \frac{2.0281}{5.0562}\approx0.4011$$

**Sanity check**: $0.4011+0.1978+0.4011 = 1.0000$ ✓

**Interpretation so far**: token 1 attends almost equally to token 1 (itself) and token 3, each getting about 40.1% of the attention weight, while token 2 receives noticeably less attention (19.8%) — this matches our setup, since $\mathbf{q}_1$ had a higher dot-product similarity with $\mathbf{k}_1$ and $\mathbf{k}_3$ than with $\mathbf{k}_2$.

### 12.5.4 Step 4 — Weighted Sum of Values

$$\mathbf{z}_1 = \alpha_{1,1}\mathbf{v}_1+\alpha_{1,2}\mathbf{v}_2+\alpha_{1,3}\mathbf{v}_3$$

$$= 0.4011\begin{bmatrix}10\\0\end{bmatrix}+0.1978\begin{bmatrix}0\\10\end{bmatrix}+0.4011\begin{bmatrix}5\\5\end{bmatrix}$$

Computing each scaled vector:

$$0.4011\begin{bmatrix}10\\0\end{bmatrix} = \begin{bmatrix}4.011\\0\end{bmatrix}$$

$$0.1978\begin{bmatrix}0\\10\end{bmatrix} = \begin{bmatrix}0\\1.978\end{bmatrix}$$

$$0.4011\begin{bmatrix}5\\5\end{bmatrix} = \begin{bmatrix}2.0055\\2.0055\end{bmatrix}$$

Sum all three:

Dimension 1: $4.011+0+2.0055 = 6.0165$

Dimension 2: $0+1.978+2.0055 = 3.9835$

$$\mathbf{z}_1 \approx \begin{bmatrix}6.0165\\3.9835\end{bmatrix}$$

**This vector, $\mathbf{z}_1$, is the final self-attention output for token 1** — it's a specific blend of the three value vectors, weighted according to how relevant each token was determined to be to token 1's query. Notice this final vector is NOT identical to any single input value vector — it's a genuinely new, blended representation, richly informed by the entire sequence's content, computed in a single parallel step (no sequential chain required, unlike the RNN/LSTM approach from Step 11).

## 12.6 Multi-Head Attention — Running Several Attention "Perspectives" in Parallel

In practice, real Transformers don't use just ONE set of $(W_Q,W_K,W_V)$ matrices — they use **several**, called **attention heads**, each learning to focus on potentially different kinds of relationships.

### 12.6.1 Why Multiple Heads? The Intuition

Going back to our classroom analogy: perhaps one useful "attention pattern" is "pay attention to who's speaking about the SAME topic as me" (semantic relevance), while a completely different useful pattern might be "pay attention to whoever is sitting immediately next to me" (positional/syntactic relevance, like subject-verb agreement in grammar). A single attention mechanism, with one shared $W_Q, W_K, W_V$, would have to compromise and try to capture some blend of all useful patterns simultaneously. **Multi-head attention instead runs several independent attention computations in parallel, each with its OWN separately learned $W_Q,W_K,W_V$ matrices**, allowing each head to specialize in a different kind of relationship — empirically, when researchers have inspected trained Transformers, different heads DO often learn to specialize in interpretable patterns (e.g., some heads consistently attend to the immediately preceding word, others attend to syntactically related words like a verb's subject, others attend to semantically similar words elsewhere in a document).

### 12.6.2 The Full Mathematics

For $h$ heads, we compute $h$ separate attention outputs:

$$\text{head}_m = \text{Attention}(QW_Q^{(m)}, KW_K^{(m)}, VW_V^{(m)}) \quad \text{for } m=1,\dots,h$$

(each head has its own projection matrices $W_Q^{(m)}, W_K^{(m)}, W_V^{(m)}$, typically projecting down to a smaller dimension $d_k/h$ per head, so that the total computational cost across all heads combined is comparable to one full-sized attention computation)

Then we **concatenate** all the heads' outputs back together, and apply one final learned linear transformation $W_O$ to mix information across heads:

$$\text{MultiHead}(Q,K,V) = \text{Concat}(\text{head}_1,\dots,\text{head}_h)W_O$$

### 12.6.3 A Small Worked Illustration of Concatenation

Suppose we have $h=2$ heads, and each head produces a 2-dimensional output for some token:

$$\text{head}_1 = \begin{bmatrix}3\\5\end{bmatrix}, \qquad \text{head}_2 = \begin{bmatrix}1\\2\end{bmatrix}$$

Concatenation simply stacks these into one longer vector:

$$\text{Concat}(\text{head}_1,\text{head}_2) = \begin{bmatrix}3\\5\\1\\2\end{bmatrix}$$

This 4-dimensional concatenated vector then gets multiplied by $W_O$ (a learned matrix mapping from 4 dimensions back to whatever dimension the model uses for its main representations) to produce the final multi-head attention output for this token — allowing the model to combine and weigh the different "perspectives" captured by each individual head.

## 12.7 Self-Attention vs. Cross-Attention — An Important Distinction

Everything computed above was **self-attention**: Query, Key, and Value all derived from the SAME sequence (every token in a sentence attends to every other token, including itself, within that same sentence). This is what's used inside GPT-style models processing a single piece of text.

**Cross-attention** is a variant where the Query comes from one sequence, but the Key and Value come from a DIFFERENT sequence. This is used, for example, in machine translation Transformers (recall the encoder-decoder structure mentioned in File 3, Section 10.7): while generating the French translation word by word, each output position's Query attends to Keys/Values derived from the ENTIRE English source sentence, allowing the translator to look back at the relevant English words while producing each French word — again, all in a single direct-access step, regardless of how far apart the relevant words are in the two sequences.

## 12.8 Why Attention Fully Solves Both of LSTM's Remaining Problems

Let's explicitly revisit the two problems identified in Step 11.7 and confirm attention resolves both:

**Problem 1 — Sequential computation cannot be parallelized.** Look at the matrix formula $\text{softmax}\left(\frac{QK^T}{\sqrt{d_k}}\right)V$: computing this requires NO sequential dependency between positions — $QK^T$ is a single matrix multiplication that computes ALL pairwise scores simultaneously, and there's no step where you need position $i-1$'s result before you can start computing position $i$'s result. This can be massively parallelized on GPU/TPU hardware, unlike the strictly sequential RNN/LSTM recurrence — a transformative practical advantage that's a major reason Transformers (built around this attention mechanism, covered fully in Step 13) can be trained on vastly larger datasets in feasible amounts of time.

**Problem 2 — Long-range dependencies still degrade even with gating.** In self-attention, the "distance" between any two positions $i$ and $j$ is **irrelevant** to how directly they can interact — token 1 and token 1000 in a long document compute their attention score via the exact same single dot-product operation as token 1 and token 2 would. There's no chain of intermediate steps for information to degrade through. This is a fundamentally different, and fundamentally more powerful, solution to the long-range dependency problem than LSTM's gating mechanism, which still requires information to flow through every intermediate time step, just with better-preserved gradients along the way.

---

# Summary Cheat Sheet

**LSTM** — three gates control memory flow via addition rather than repeated multiplication:

$$\mathbf{f}_t=\sigma(W_f[\mathbf{h}_{t-1},\mathbf{x}_t]+\mathbf{b}_f) \quad \mathbf{i}_t=\sigma(W_i[\cdot]+\mathbf{b}_i) \quad \tilde{\mathbf{c}}_t=\tanh(W_c[\cdot]+\mathbf{b}_c)$$
$$\mathbf{c}_t = \mathbf{f}_t\odot\mathbf{c}_{t-1}+\mathbf{i}_t\odot\tilde{\mathbf{c}}_t \qquad \mathbf{o}_t=\sigma(W_o[\cdot]+\mathbf{b}_o) \qquad \mathbf{h}_t=\mathbf{o}_t\odot\tanh(\mathbf{c}_t)$$

**GRU** — a simpler 2-gate alternative, merging cell and hidden state:

$$\mathbf{h}_t = (1-\mathbf{z}_t)\odot\mathbf{h}_{t-1}+\mathbf{z}_t\odot\tilde{\mathbf{h}}_t$$

**Attention** — the single most important formula in this entire series:

$$\text{Attention}(Q,K,V) = \text{softmax}\left(\frac{QK^T}{\sqrt{d_k}}\right)V$$

Query = "what am I looking for," Key = "what do I offer," Value = "what I actually contribute if attended to." Scaling by $\sqrt{d_k}$ prevents softmax saturation as dimensionality grows. Multi-head attention runs several independent Query/Key/Value projections in parallel, letting different heads specialize in different relationship types, then concatenates and combines their outputs.

---

# Self-Test Questions

1. Using the whiteboard-vs-notebook analogy, explain in your own words why an LSTM's additive cell-state update helps preserve gradients better than a vanilla RNN's full-overwrite update.
2. Write out, from memory, all six LSTM equations (forget gate, input gate, candidate, cell update, output gate, hidden state), and explain the role of each.
3. Redo the fully worked LSTM numerical example (Section 11.4) with $x_t=0.5$ instead of $1.0$, keeping all weights the same, and compare your resulting $c_t$ and $h_t$ to the original.
4. Explain why a GRU's final update equation is described as a "convex combination," and what happens in the extreme cases $z_t=0$ and $z_t=1$.
5. In your own words, explain what Query, Key, and Value conceptually represent, using an analogy of your own choosing (different from the classroom example in this file).
6. Derive, from the assumption that query/key components are mean-0 variance-1 random variables, why the standard deviation of their dot product grows as $\sqrt{d_k}$, and explain why this motivates the scaling factor in attention.
7. Redo the fully worked attention example (Section 12.5) but compute $\mathbf{z}_2$ (the output for query position 2) instead of $\mathbf{z}_1$, showing every step.
8. Explain why multi-head attention is expected to capture richer relationships than single-head attention, using the concept of different heads specializing in different relationship types.
9. Explain the difference between self-attention and cross-attention, and give an example task (other than machine translation) where cross-attention would be useful.
10. Explain precisely, referencing the matrix formula, why attention computation has no sequential dependency between positions, and why this matters practically for training on modern hardware.

---

*End of File 4. File 5 will cover: The Transformer architecture and GPT (Steps 13-14) — assembling attention, multi-head attention, feedforward layers, residual connections, and layer normalization into the complete architecture that underlies every modern LLM, and then specifically how a Transformer becomes an autoregressive language model capable of generating text.*

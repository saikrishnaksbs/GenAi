# File 2 of 20: How Networks Learn
## Loss Functions → Gradient Descent → Backpropagation → Deep Networks

> **Continuity note**: File 1 ended with a hand-designed MLP that solved XOR — but we designed those weights ourselves, using logic. This file answers the question we deliberately left hanging: **how does a network find good weights automatically, from data, with no human designing anything?** This is the single most important mechanical question in all of deep learning, and by the end of this file you will be able to derive, by hand, the exact update to every single weight in a small network.

---

# Table of Contents

1. [Step 5: Loss Functions](#step-5-loss-functions)
2. [Step 6: Gradient Descent](#step-6-gradient-descent)
3. [Step 7: Backpropagation](#step-7-backpropagation)
4. [Step 8: Deep Networks](#step-8-deep-networks)
5. [Summary Cheat Sheet](#summary-cheat-sheet)
6. [Self-Test Questions](#self-test-questions)

---

# Step 5: Loss Functions

### Main Question: *How do we know the network is wrong?*

## 5.1 The Everyday Analogy

Imagine you're learning to throw darts. You throw a dart, it lands somewhere on the board, and you need some way to answer: **"how bad was that throw?"**

If you hit the bullseye, the answer is "not bad at all — 0." If you hit the very edge of the board, the answer is "pretty bad — a big number." If you miss the board entirely, "really bad — an even bigger number." 

Crucially, you need this "badness score" to be **precise and numeric**, not just a vague feeling, because you're going to use this exact number to figure out *how* to adjust your arm next time (that adjustment process is Gradient Descent, Step 6). A loss function is exactly this: **a single number that measures how bad the network's current prediction is**, computed by comparing the prediction $\hat{y}$ to the true answer $y$.

## 5.2 The Tech Analogy

Think about how a GPS app calculates "how far off course are you?" It doesn't just say "you're off course" — it computes an actual distance, in meters, between where you are and where you should be. That distance is a **loss** — small when you're on track, large when you've wandered far off. The app then uses this precise measurement to calculate exactly which turn to make to correct course.

Similarly, when you're testing code and an assertion fails (`assert output == expected`), a good testing framework doesn't just say "test failed" — good diffing tools show you exactly *how* the output differed from the expected value, character by character. A loss function is this idea generalized into continuous mathematics: not just "right or wrong," but "wrong by exactly how much, in which direction."

## 5.3 Why We Need a Precise, Differentiable Number (Not Just "Right/Wrong")

Here's a subtlety that's easy to miss: why not just use a simple "correct or incorrect" count? Because that gives us **no directional information** about *how* to improve. If I tell you "you got the answer wrong," you don't know if you need to increase or decrease any particular weight, or by how much. But if I tell you "your predicted value was 0.3, but it should have been 0.9, so you're off by 0.6, and specifically you *underestimated*" — now there's a clear signal for correction.

This is why loss functions are designed to be **smooth, continuous, and differentiable** (meaning: we can compute their slope/derivative at any point) — because Step 6 (Gradient Descent) works by using the *slope* of the loss function to figure out which direction to adjust weights. A jagged, non-differentiable "badness score" (like simple accuracy, which jumps in discrete steps) can't give us this smooth directional signal.

## 5.4 Mean Squared Error (MSE) — For Regression Problems

**Regression** means predicting a continuous number (e.g., predicting a house price, a temperature, a stock value) — as opposed to **classification**, which predicts a category (e.g., "cat" vs "dog").

### 5.4.1 The Formula, Built Up Piece by Piece

Let's build MSE from scratch, reasoning about each piece.

**Step 1**: For a single example, define the **error** as the difference between the true value and the predicted value:

$$\text{error} = y - \hat{y}$$

**Step 2**: Why not just use this error directly as our loss? Problem: errors can be positive (we underestimated) or negative (we overestimated). If we have multiple examples and just add up their errors, positive and negative errors could **cancel out**, making it look like the model is doing great even if it's making huge mistakes in both directions. 

*Concrete illustration*: suppose on example 1, error = +10 (we underestimated badly), and on example 2, error = -10 (we overestimated badly). If we just summed these: $10 + (-10) = 0$, suggesting "zero total error" — completely misleading! The model is actually making two huge mistakes.

**Step 3**: The fix is to **square** the error before summing, since squaring makes every value positive (or zero), regardless of the original sign:

$$(\text{error})^2 = (y-\hat{y})^2$$

Now, in our illustration: $(10)^2 + (-10)^2 = 100 + 100 = 200$ — correctly reflecting that two big mistakes were made, rather than canceling to zero.

**Step 4**: If we have $N$ training examples, we compute the squared error for each one, and take the **average** (mean) — hence "Mean Squared Error":

$$\text{MSE} = \frac{1}{N}\sum_{k=1}^{N} \left(y_k - \hat{y}_k\right)^2$$

Here $y_k$ is the true value for the $k$-th example, and $\hat{y}_k$ is the model's prediction for that same example.

### 5.4.2 A Note on the Factor of 1/2 (You Will See This Variant Constantly)

You will very often see MSE written with an extra $\frac{1}{2}$ factor:

$$\text{MSE} = \frac{1}{2N}\sum_{k=1}^{N}\left(y_k-\hat{y}_k\right)^2$$

**Why?** This is purely a convenience for calculus, not a conceptual change. When we take the derivative of $(y-\hat{y})^2$ with respect to $\hat{y}$ (which we will need for gradient descent), the power rule brings down a factor of 2:

$$\frac{d}{d\hat{y}}(y-\hat{y})^2 = 2(y-\hat{y}) \times (-1) = -2(y-\hat{y})$$

That stray factor of 2 is mathematically harmless (it just slightly rescales the learning rate — a number we choose anyway), but it's aesthetically annoying to carry around in every subsequent equation. So, many textbooks pre-emptively cancel it by inserting $\frac{1}{2}$ up front:

$$\frac{d}{d\hat{y}}\left[\frac{1}{2}(y-\hat{y})^2\right] = \frac{1}{2} \times \left(-2(y-\hat{y})\right) = -(y-\hat{y}) = \hat{y}-y$$

Much cleaner. Both versions (with or without the $\frac12$) are "correct" — they just differ by a constant multiplicative factor that gets absorbed into the learning rate during training. We will use the $\frac12$ version going forward in this file, since it will make our backpropagation derivation (Step 7) noticeably cleaner.

### 5.4.3 Fully Worked Numerical Example

Suppose we're predicting house prices (in lakhs of rupees, to keep numbers small), and we have 4 test examples:

| Example | True price $y$ | Predicted price $\hat{y}$ | Error $y-\hat{y}$ | Squared error |
|---|---|---|---|---|
| 1 | 50 | 48 | 2 | 4 |
| 2 | 70 | 75 | -5 | 25 |
| 3 | 30 | 30 | 0 | 0 |
| 4 | 90 | 82 | 8 | 64 |

**Computing MSE (without the 1/2 factor first, for clarity):**

$$\text{MSE} = \frac{1}{4}(4+25+0+64)$$

Adding the squared errors:
$$4+25 = 29$$
$$29+0=29$$
$$29+64=93$$

$$\text{MSE} = \frac{93}{4} = 23.25$$

**Interpretation**: on average, our squared prediction error is 23.25 (in units of lakhs-squared, which isn't very intuitive on its own — this is a known quirk of MSE, addressed by looking at RMSE, the square root of MSE, which brings units back to lakhs: $\sqrt{23.25}\approx 4.82$ lakhs of typical error).

**With the 1/2 factor:**

$$\text{MSE}_{1/2} = \frac{1}{2\times 4}(93) = \frac{93}{8} = 11.625$$

Notice this is exactly half of the previous value — confirming the factor of $\frac12$ is just a constant rescaling, exactly as we discussed.

## 5.5 Cross-Entropy Loss — For Classification Problems

Regression problems predict continuous numbers; **classification** problems predict a category — like "is this email spam or not," or "what's the next word in this sentence" (which, as you already know from your prior LLM studies, is a classification problem over the entire vocabulary). MSE is not the right tool here, so we need a different loss.

### 5.5.1 Building Cross-Entropy From Scratch — Binary Case First

Let's start with the simplest case: binary classification (2 classes, e.g., "spam" or "not spam"). Suppose the true label $y$ is either 0 or 1, and the model outputs $\hat{y}$, a predicted **probability** that the label is 1 (so $\hat{y}$ is a number between 0 and 1, typically produced by a sigmoid output — recall File 1, Section 4.4.1).

**The intuitive goal**: we want to penalize the model heavily when it's confidently wrong, and barely penalize it when it's correctly confident. Let's reason through what "penalize" should look like:

- If true $y=1$ and the model predicts $\hat{y}=0.99$ (highly confident and correct): loss should be **very small**.
- If true $y=1$ and the model predicts $\hat{y}=0.01$ (highly confident and WRONG): loss should be **very large**.
- If true $y=1$ and the model predicts $\hat{y}=0.5$ (uncertain): loss should be **moderate**.

### 5.5.2 Where Does the Logarithm Come From?

The function that captures this "harshly punish confident wrongness" behavior is the **negative logarithm**. Let's understand why, using the natural log $\ln$ (log base $e$).

Recall some basic properties of $\ln(p)$ for $p$ between 0 and 1:
- As $p \to 1$: $\ln(p) \to 0$ (log of 1 is exactly 0)
- As $p \to 0$: $\ln(p) \to -\infty$ (log of numbers approaching 0 plunges toward negative infinity)

So $-\ln(p)$ behaves like:
- As $p \to 1$: $-\ln(p) \to 0$ (near-zero penalty for near-certain correct predictions)
- As $p \to 0$: $-\ln(p) \to +\infty$ (penalty explodes toward infinity for near-certain WRONG predictions)

This is *exactly* the punishing behavior we wanted: barely any penalty for confident correctness, and an unboundedly severe penalty for confident wrongness.

### 5.5.3 The Binary Cross-Entropy Formula

For a single example with true label $y \in \{0,1\}$ and predicted probability $\hat{y}$:

$$\mathcal{L}_{\text{BCE}} = -\left[y\ln(\hat{y}) + (1-y)\ln(1-\hat{y})\right]$$

**Why does this formula have two terms?** Notice that whichever term corresponds to the *true* label is the one that "activates" (the other term gets multiplied by 0):

- If $y=1$: the term $(1-y)\ln(1-\hat{y})$ becomes $(1-1)\ln(1-\hat{y}) = 0 \times (\text{anything}) = 0$. So the loss simplifies to $-y\ln(\hat{y}) = -1 \times \ln(\hat{y}) = -\ln(\hat{y})$ — exactly matching our intuition above: we penalize based on how far $\hat{y}$ is from 1.
  
- If $y=0$: the term $y\ln(\hat{y})$ becomes $0 \times \ln(\hat{y}) = 0$. So the loss simplifies to $-(1-y)\ln(1-\hat{y}) = -\ln(1-\hat{y})$ — this penalizes based on how far $\hat{y}$ is from 0 (since $1-\hat{y}$ measures "how far is the predicted probability of class 0 from certainty").

The formula is a clever single expression that automatically "selects" the correct penalty term depending on whether the true label is 0 or 1, without needing an explicit if-else branch.

### 5.5.4 Fully Worked Numerical Example — Binary Cross-Entropy

**Case A: True label $y=1$, model predicts $\hat{y}=0.9$ (confident and correct)**

$$\mathcal{L} = -\left[1 \times \ln(0.9) + 0 \times \ln(0.1)\right] = -\ln(0.9)$$

We need $\ln(0.9)$. Using the approximation $\ln(1-x) \approx -x - x^2/2$ for small $x$ (here $x=0.1$):

$$\ln(0.9) \approx -0.1 - 0.005 = -0.105$$

(The true value, from a calculator, is $\ln(0.9) \approx -0.10536$ — our approximation is very close.)

$$\mathcal{L} = -(-0.10536) = 0.10536$$

Small loss — as expected, since the model was confident AND correct.

**Case B: True label $y=1$, model predicts $\hat{y}=0.1$ (confident and WRONG)**

$$\mathcal{L} = -\left[1 \times \ln(0.1) + 0\right] = -\ln(0.1)$$

We know $\ln(0.1) = \ln(1/10) = -\ln(10) \approx -2.3026$

$$\mathcal{L} = -(-2.3026) = 2.3026$$

Much larger loss (2.3026 vs 0.10536 — over 20 times larger) — exactly reflecting that confident wrongness is punished far more severely than confident correctness is rewarded with a low loss. This asymmetric, harsh punishment of confident mistakes is a deliberate and important design property of cross-entropy loss.

**Case C: True label $y=1$, model predicts $\hat{y}=0.5$ (uncertain)**

$$\mathcal{L} = -\ln(0.5)$$

Since $0.5 = 1/2$: $\ln(0.5) = \ln(1) - \ln(2) = 0 - 0.6931 = -0.6931$

$$\mathcal{L} = 0.6931$$

This sits between our two extremes (0.105 and 2.303) — moderate penalty for genuine uncertainty. This value, $\ln(2) \approx 0.693$, is actually a landmark number worth remembering: **it's the loss a model gets for being maximally uncertain (50/50) on a binary problem** — a useful sanity-check baseline when you're debugging a real training run (if your loss starts around 0.69 for a binary classifier, that confirms it's initialized as an uninformed coin-flip, which is expected).

### 5.5.5 Generalizing to Multiple Classes — Categorical Cross-Entropy

For problems with more than 2 classes (like predicting the next word among 50,000 vocabulary options — exactly what an LLM does), we generalize using the softmax output (recall File 1, Section 4.4.6). If we have $K$ classes, and $y_i$ represents whether class $i$ is the true class (1 if yes, 0 for all other classes — this encoding is called **one-hot encoding**), and $\hat{y}_i$ is the model's predicted probability for class $i$:

$$\mathcal{L}_{\text{CE}} = -\sum_{i=1}^{K} y_i \ln(\hat{y}_i)$$

Because $y_i$ is 0 for every class except the true one, **every term in this sum vanishes except the single term corresponding to the correct class.** If the true class is class $c$, this collapses beautifully to:

$$\mathcal{L}_{\text{CE}} = -\ln(\hat{y}_c)$$

**This is an extremely important simplification to internalize**: in practice, computing cross-entropy loss for classification (including next-token prediction in every LLM you'll ever use) means: *look up the probability the model assigned to the correct answer, and take the negative log of just that one number.* Everything else the model predicted for the wrong classes doesn't directly enter the loss calculation (though, as we'll see in Step 7, it absolutely does affect the *gradients*, because the softmax function couples all the classes' probabilities together).

### 5.5.6 Fully Worked Numerical Example — Categorical Cross-Entropy (Language Model Style)

Let's revisit our File 1 softmax example: a language model outputs probabilities for the next word:

$$P(\text{cat})=0.6590, \quad P(\text{dog})=0.2424, \quad P(\text{fish})=0.0986$$

Suppose the **true** next word (from our training data) is "dog." Then $y_{\text{dog}}=1$ and all others are 0. The loss is:

$$\mathcal{L} = -\ln(\hat{y}_{\text{dog}}) = -\ln(0.2424)$$

We need $\ln(0.2424)$. We can write $0.2424 \approx e^{-1.417}$ (you'd typically get this from a calculator or computed table; let's verify: $e^{-1.417} \approx e^{-1.4} \times e^{-0.017} \approx 0.2466 \times 0.9831 \approx 0.2424$ ✓)

$$\mathcal{L} = -(-1.417) = 1.417$$

**Interpretation**: the model assigned only 24.24% probability to the actually-correct word "dog" (it favored "cat" instead, at 65.9%), so it receives a moderately high loss of 1.417. If the model had instead assigned $\hat{y}_{\text{dog}} = 0.99$ (highly confident and correct), the loss would have been $-\ln(0.99) \approx 0.01$ — dramatically smaller. **This is precisely the loss computed, averaged over every single word in a training document, that drives the entire pretraining process of every LLM in existence** (full mechanics in Step 15 — but the loss computation itself is exactly this formula, applied per-token, at massive scale).

## 5.6 Choosing the Right Loss for the Right Problem

| Problem type | Example | Loss function |
|---|---|---|
| Regression (continuous number) | House price prediction | Mean Squared Error (MSE) |
| Binary classification | Spam or not spam | Binary Cross-Entropy |
| Multi-class classification | Handwritten digit (0-9) | Categorical Cross-Entropy |
| Next-token prediction (LLMs) | Predicting next word | Categorical Cross-Entropy (over full vocabulary) |

---

# Step 6: Gradient Descent

### Main Question: *How do we improve weights?*

## 6.1 The Everyday Analogy

Imagine you're standing somewhere on a hillside in thick fog — you can't see the whole landscape, only the ground immediately around your feet. Your goal: **reach the lowest point of the valley.**

What's the sensible strategy? Feel the slope of the ground right where you're standing. If the ground slopes downward to your left, step left. If it slopes downward to your right, step right. Take a step in the downhill direction, then repeat this process — feel the new slope, take another small downhill step — over and over, until you reach a point where the ground feels flat in every direction (you've reached the bottom, or at least a local bottom).

**This is precisely gradient descent.** The "hillside" is the loss function (Step 5), the "lowest point" is the set of weights that gives minimum loss, and "feeling the slope" is computing the **gradient** (the mathematical generalization of slope) of the loss with respect to the weights.

## 6.2 The Tech Analogy

Think of gradient descent like a **binary search that got generalized to continuous, smooth problems**, or like how a thermostat's PID controller continuously nudges the heating power up or down based on how far the current temperature is from the target, repeatedly, in small steps, until it converges near the target. Or, if you've played a "guess the number, hot/cold" game: someone tells you "warmer" or "colder" after each guess, and you use that directional feedback to adjust your next guess. Gradient descent formalizes "warmer/colder" feedback into an exact mathematical direction and magnitude.

## 6.3 The Full Mathematics — Step by Step

### 6.3.1 What Is a Derivative, Really? (Quick Refresher, Building From First Principles)

Before we can talk about gradients, let's make sure the concept of a **derivative** is rock solid, since everything else in this file depends on it.

The derivative of a function $g(w)$ at a point $w$ tells you **the instantaneous rate of change of $g$ at that exact point** — in other words, if you nudge $w$ by a tiny amount, how much does $g(w)$ change, and in which direction?

Formally:

$$g'(w) = \lim_{h \to 0} \frac{g(w+h)-g(w)}{h}$$

This is the "slope formula" ($\frac{\text{rise}}{\text{run}}$) you learned in algebra, but with the two points brought infinitesimally close together (that's what the limit as $h\to 0$ means).

**Sign convention, crucial for gradient descent**: 
- If $g'(w) > 0$: the function is increasing at $w$ — moving $w$ slightly to the right (increasing $w$) increases $g$.
- If $g'(w) < 0$: the function is decreasing at $w$ — moving $w$ slightly to the right decreases $g$.
- If $g'(w) = 0$: you're at a flat point — possibly a minimum, maximum, or saddle point.

### 6.3.2 The Key Insight: To Minimize, Move Opposite the Derivative's Sign

Suppose we want to find the value of $w$ that **minimizes** some loss function $\mathcal{L}(w)$.

- If $\mathcal{L}'(w) > 0$ (loss increasing as $w$ increases): we want to **decrease** $w$ to reduce the loss. So we should move in the negative direction.
- If $\mathcal{L}'(w) < 0$ (loss decreasing as $w$ increases): we want to **increase** $w$ to reduce the loss further. So we should move in the positive direction.

Notice in both cases: **we want to move in the direction opposite to the sign of the derivative.** This single observation is the entire essence of gradient descent, and it's captured in one elegant update formula:

$$w \leftarrow w - \eta \cdot \mathcal{L}'(w)$$

Let's verify this formula produces the correct behavior in both cases:

- If $\mathcal{L}'(w) > 0$: then $-\eta \mathcal{L}'(w)$ is negative (since $\eta > 0$), so $w$ decreases. ✓ Matches what we wanted.
- If $\mathcal{L}'(w) < 0$: then $-\eta \mathcal{L}'(w)$ is positive, so $w$ increases. ✓ Matches what we wanted.

$\eta$ (the **learning rate**, same symbol we saw for the perceptron in File 1) controls the **size** of each step. This is the single update rule that trains every neural network on Earth, from tiny XOR solvers to trillion-parameter LLMs — the *only* thing that changes at scale is how the gradient $\mathcal{L}'(w)$ gets computed for millions of weights simultaneously (that computation is backpropagation, Step 7).

### 6.3.3 Extending to Multiple Weights — The Gradient Vector

Real networks have many weights, not just one. If our loss $\mathcal{L}$ depends on multiple weights $w_1, w_2, \dots, w_n$, we need the **partial derivative** of $\mathcal{L}$ with respect to each weight individually — written $\frac{\partial \mathcal{L}}{\partial w_i}$. A partial derivative just means: "the derivative with respect to $w_i$, treating every other weight as a fixed constant during this calculation."

The **gradient**, written $\nabla \mathcal{L}$ (the nabla symbol $\nabla$ denotes gradient), is simply the vector containing all these partial derivatives:

$$\nabla \mathcal{L} = \begin{bmatrix} \frac{\partial \mathcal{L}}{\partial w_1} \\ \frac{\partial \mathcal{L}}{\partial w_2} \\ \vdots \\ \frac{\partial \mathcal{L}}{\partial w_n} \end{bmatrix}$$

**Crucial geometric fact** (stated here, proof is a standard multivariable calculus result you can take on faith for now): the gradient vector $\nabla \mathcal{L}$ always points in the direction of **steepest ascent** — the direction in which the loss increases fastest, if you were to move a tiny bit from your current position. Therefore, $-\nabla \mathcal{L}$ (the negative gradient) points in the direction of **steepest descent** — exactly the direction we want to move to decrease the loss as quickly as possible. This directly generalizes our foggy-hillside analogy: at any point on the hillside, $-\nabla \mathcal{L}$ tells you exactly which direction is "most downhill" from where you're standing.

The gradient descent update rule, generalized to a vector of weights:

$$\mathbf{w} \leftarrow \mathbf{w} - \eta \nabla \mathcal{L}$$

Or, written out for each individual weight:

$$w_i \leftarrow w_i - \eta \frac{\partial \mathcal{L}}{\partial w_i} \quad \text{for every } i$$

### 6.3.4 Fully Worked Numerical Example — Gradient Descent on a Simple Function

Let's minimize a simple function by hand: $\mathcal{L}(w) = w^2 - 4w + 7$. (This isn't a "real" neural network loss, but working with a clean, simple function first will make the mechanics crystal clear before we tackle the messier real loss functions.)

**Step 1: Find the derivative.**

$$\mathcal{L}'(w) = 2w - 4$$

**Step 2: Choose a starting point and learning rate.** Let's start at $w_0 = 0$, with learning rate $\eta = 0.1$.

**Iteration 1:**

$$\mathcal{L}'(0) = 2(0)-4 = -4$$

$$w_1 \leftarrow 0 - (0.1)(-4) = 0 + 0.4 = 0.4$$

**Iteration 2:**

$$\mathcal{L}'(0.4) = 2(0.4)-4 = 0.8-4=-3.2$$

$$w_2 \leftarrow 0.4 - (0.1)(-3.2) = 0.4+0.32=0.72$$

**Iteration 3:**

$$\mathcal{L}'(0.72) = 2(0.72)-4=1.44-4=-2.56$$

$$w_3 \leftarrow 0.72-(0.1)(-2.56)=0.72+0.256=0.976$$

**Iteration 4:**

$$\mathcal{L}'(0.976)=2(0.976)-4=1.952-4=-2.048$$

$$w_4 \leftarrow 0.976-(0.1)(-2.048)=0.976+0.2048=1.1808$$

**Iteration 5:**

$$\mathcal{L}'(1.1808)=2(1.1808)-4=2.3616-4=-1.6384$$

$$w_5 \leftarrow 1.1808-(0.1)(-1.6384)=1.1808+0.16384=1.34464$$

Notice the pattern: $w$ is climbing toward some target value, and the *steps are getting smaller* each time ($0.4, 0.32, 0.256, 0.2048, 0.16384, \dots$) because as $w$ approaches the true minimum, the derivative (slope) shrinks toward zero, so the update $-\eta \mathcal{L}'(w)$ also shrinks.

**Where does this converge?** We can solve exactly, using basic calculus (setting the derivative to 0 to find the minimum, which you can do directly for this simple function, though gradient descent doesn't need this shortcut for messy real neural network losses):

$$\mathcal{L}'(w) = 2w-4=0 \implies w=2$$

Our iterative process is indeed climbing toward $w=2$ ($0 \to 0.4 \to 0.72 \to 0.976 \to 1.18 \to 1.34 \to \dots \to 2$), getting closer each step, exactly as gradient descent should. If you continued this process for more iterations, $w$ would keep approaching 2 (though technically never exactly reaching it in finite steps with this particular learning rate schedule — it converges asymptotically).

**Let's verify $w=2$ really is the minimum**, by checking the loss value there versus nearby points:

$$\mathcal{L}(2) = (2)^2-4(2)+7 = 4-8+7=3$$
$$\mathcal{L}(1.5) = (1.5)^2-4(1.5)+7=2.25-6+7=3.25$$
$$\mathcal{L}(2.5) = (2.5)^2-4(2.5)+7=6.25-10+7=3.25$$

Indeed, $\mathcal{L}(2)=3$ is lower than both neighboring points we checked — confirming $w=2$ is (at least locally, and in this case globally, since this function is a simple upward-opening parabola) the minimum.

### 6.3.5 The Learning Rate — Why Getting This Number Right Matters So Much

Let's explore what happens with a **badly chosen** learning rate, using the same function $\mathcal{L}(w)=w^2-4w+7$, starting again at $w_0=0$.

**Case: Learning rate too large ($\eta = 1.1$)**

$$\mathcal{L}'(0)=-4$$
$$w_1 = 0-(1.1)(-4)=4.4$$

$$\mathcal{L}'(4.4)=2(4.4)-4=4.8$$
$$w_2 = 4.4-(1.1)(4.8)=4.4-5.28=-0.88$$

$$\mathcal{L}'(-0.88)=2(-0.88)-4=-5.76$$
$$w_3=-0.88-(1.1)(-5.76)=-0.88+6.336=5.456$$

Notice $w$ is **oscillating wildly and growing in magnitude** ($0 \to 4.4 \to -0.88 \to 5.456 \to \dots$) — overshooting the target of $w=2$ each time, by an ever-increasing amount. This is called **divergence**, and it's one of the most common practical failure modes when training real neural networks: if your learning rate is too high, instead of smoothly descending toward the minimum, your weights bounce around chaotically or even blow up toward infinity, and your loss actually *increases* over training instead of decreasing.

**Case: Learning rate too small ($\eta = 0.001$)**

$$\mathcal{L}'(0)=-4$$
$$w_1 = 0-(0.001)(-4)=0.004$$

After just one step, we've barely moved from $w=0$ to $w=0.004$ — and it would take thousands of iterations to approach $w=2$. This isn't *wrong*, exactly (it will eventually converge), but it's **wastefully slow**, burning enormous amounts of computation time and energy to make painfully small progress each step. For context, training a real large language model can cost many millions of dollars in compute — an unnecessarily small learning rate could multiply training time (and cost) by a large factor for no benefit.

**The practical takeaway**: the learning rate is one of the most important "knobs" (called a **hyperparameter** — a setting chosen by the practitioner, not learned by the network itself) in all of deep learning. Too large: divergence/instability. Too small: painfully slow convergence, or getting permanently stuck before reaching a good solution. In practice, modern training uses adaptive learning rate schedules (warming up, then decaying over training) and adaptive optimizers (like Adam, which adjusts the effective learning rate per-weight automatically) — but the fundamental tension this simple example demonstrates never goes away, no matter how sophisticated the optimizer.

## 6.4 Batch, Stochastic, and Mini-Batch Gradient Descent

There's an important practical question we've glossed over: when we compute $\nabla \mathcal{L}$, whose loss are we even talking about, if we have thousands or millions of training examples?

### 6.4.1 Batch Gradient Descent

Compute the loss (and its gradient) using **the entire training dataset** at once, then take one update step.

$$\mathcal{L} = \frac{1}{N}\sum_{k=1}^{N}\mathcal{L}_k \qquad \nabla \mathcal{L} = \frac{1}{N}\sum_{k=1}^{N}\nabla \mathcal{L}_k$$

**Pro**: the gradient is very accurate/stable, since it's averaged over all data. **Con**: for large datasets (millions or billions of examples — as is standard for LLM training), this is computationally very expensive per single update step, and doesn't fit in memory anyway.

### 6.4.2 Stochastic Gradient Descent (SGD)

Compute the loss and gradient using just **ONE randomly chosen training example**, and immediately update the weights, then move to the next example.

**Pro**: extremely fast per-step, since we're only looking at one example. Introduces useful "noise" into training that can help escape shallow local minima (small dips in the loss landscape that aren't the true best solution). **Con**: the gradient estimate from a single example is noisy/unreliable — imagine trying to judge the "true direction downhill" on a hillside by feeling the ground under just one foot, versus feeling with your whole body. Progress can be erratic.

### 6.4.3 Mini-Batch Gradient Descent (What's Actually Used in Practice)

Compute the loss and gradient using a **small, randomly sampled subset** ("mini-batch") of the data — commonly somewhere between 32 and a few thousand examples, depending on the task and available hardware memory.

$$\mathcal{L}_{\text{batch}} = \frac{1}{B}\sum_{k=1}^{B}\mathcal{L}_k$$

where $B$ is the **batch size** (number of examples in the mini-batch).

This is the **practical sweet spot**, and it's what's used to train essentially every modern neural network, including every LLM you've ever interacted with: it's fast enough per step (much cheaper than full-batch), while being far more stable than single-example SGD (averaging over, say, 512 examples smooths out a lot of the individual-example noise). The word "batch size" that you may have seen in model training configs refers exactly to this $B$.

## 6.5 The Loss Landscape — Local Minima, Global Minima, Saddle Points

Real neural network loss functions, unlike our simple parabola example, are **extremely high-dimensional and non-convex** (meaning: they have a complicated, bumpy shape with many hills and valleys, not one single smooth bowl). This introduces some important complications worth understanding conceptually:

- **Global minimum**: the single lowest point across the *entire* loss landscape — the theoretically best possible set of weights.
- **Local minimum**: a point that's lower than all its immediate neighbors, but not necessarily the lowest point overall — like a small valley partway down a mountain, surrounded by higher ground in every direction, but not the true bottom of the whole mountain range.
- **Saddle point**: a point where the gradient is zero (flat in some directions), but it's not a minimum at all — it curves up in some directions and down in others, like a horse's saddle, or a mountain pass between two peaks.

Gradient descent, as described, only "sees" the local slope around its current position — it has no way of knowing whether it's approaching the true global minimum or getting stuck in a local minimum or saddle point. In practice, for the extremely high-dimensional loss landscapes of real deep networks (millions/billions of weights), research has found that **bad local minima are surprisingly rare** — the geometry of high-dimensional spaces makes it statistically unlikely to get truly stuck, and most of the practical difficulty comes from saddle points and plateaus (very flat regions where progress is slow, though not fully stuck) rather than genuine local minima. This is a subtle and still actively researched area, but the practical upshot for you: mini-batch noise (from Section 6.4.3), momentum-based optimizers, and good learning rate schedules all help gradient descent navigate around these tricky landscape features in practice.

---

# Step 7: Backpropagation

### Main Question: *How do we calculate which weights caused the error?*

## 7.1 The Everyday Analogy

Imagine a school where a student's final exam score depends on a chain of study habits: **how much they slept** affects **how well they concentrated in class**, which affects **how well they took notes**, which affects **how well they understood the material**, which finally affects **their exam score**.

If the exam score is bad, and you want to figure out "how much did each factor along this chain contribute to the bad outcome, and how should each one change," you need to trace *backward* through this entire chain, at each step asking: "how much would a small change in this factor have changed the final outcome, given how it flows through everything downstream of it?" 

This backward-tracing-through-a-chain-of-causes is exactly what **backpropagation** does — except instead of vague life-factors, it's precise mathematical layers, and instead of "how much did this contribute," it's an exact number: a partial derivative.

## 7.2 The Tech Analogy

Think about debugging a multi-step data pipeline: raw data flows through Stage A → Stage B → Stage C → Stage D → final output. If the final output is wrong, a good debugging process works **backward**: check Stage D's output — is it consistent with what Stage C gave it? If Stage C's output looks fine but Stage D messed it up, the bug is in Stage D. If Stage C's output itself looks wrong, trace back further into Stage C, then Stage B, and so on, until you isolate exactly where things went wrong. 

Backpropagation is the *mathematically precise, fully automated version* of this backward-tracing debugging process — except instead of finding a single "bug," it's computing, for *every single weight in every single layer*, exactly how much that weight should change to reduce the final loss, quantified exactly via calculus, not guesswork.

## 7.3 The Chain Rule — The Single Mathematical Idea Behind All of Backpropagation

Backpropagation is, at its mathematical core, a highly organized, efficient application of one single calculus rule you may have already encountered: **the chain rule.**

### 7.3.1 The Chain Rule, From Scratch

Suppose $y$ depends on $u$, and $u$ in turn depends on $x$. In other words, $x$ affects $y$ only *indirectly*, by first affecting $u$, which then affects $y$. The chain rule tells us how to compute $\frac{dy}{dx}$ (how much $y$ changes when $x$ changes) in terms of the two more immediate relationships we might already know: $\frac{dy}{du}$ and $\frac{du}{dx}$:

$$\frac{dy}{dx} = \frac{dy}{du} \cdot \frac{du}{dx}$}$$

**Intuition for why this multiplication makes sense**: suppose a tiny change in $x$ causes $u$ to change by a factor of 3 (i.e., $\frac{du}{dx}=3$ — every unit change in $x$ causes a 3-unit change in $u$). And suppose a tiny change in $u$ causes $y$ to change by a factor of 5 (i.e., $\frac{dy}{du}=5$). Then a tiny change in $x$ causes $u$ to change 3x as much, and each of THOSE changes in $u$ causes $y$ to change 5x as much — so overall, $x$'s effect on $y$ is amplified by a factor of $3 \times 5 = 15$. This is exactly $\frac{dy}{dx} = \frac{dy}{du}\cdot\frac{du}{dx} = 5 \times 3 = 15$.

### 7.3.2 Extending the Chain Rule Through Multiple Steps

If $y$ depends on $u$, which depends on $v$, which depends on $x$ (a longer chain):

$$\frac{dy}{dx} = \frac{dy}{du}\cdot\frac{du}{dv}\cdot\frac{dv}{dx}$$

You just keep multiplying the "local" derivatives at each link of the chain. **This generalizes to a chain of any length** — and a deep neural network with, say, 50 layers, is precisely a 50-link chain of computations, from the input all the way to the loss. Backpropagation is nothing more than applying this chain-rule-through-many-links idea, done efficiently and systematically.

## 7.4 Deriving Backpropagation for a Single Neuron — Every Step Shown

Let's derive the full backpropagation math for the simplest possible case: a single neuron, with sigmoid activation, trained on MSE loss for one example.

### 7.4.1 Setting Up the Forward Pass

Given input $x$, weight $w$, bias $b$:

$$z = wx+b$$
$$a = \sigma(z)$$
$$\mathcal{L} = \frac{1}{2}(y-a)^2$$

(Here $a$ plays the role of $\hat{y}$ — the model's prediction — and we're using the $\frac12$-scaled MSE from Step 5.3.2.)

### 7.4.2 What We Want: $\frac{\partial \mathcal{L}}{\partial w}$ and $\frac{\partial \mathcal{L}}{\partial b}$

We want to know: if we nudge $w$ (or $b$) slightly, how does the final loss $\mathcal{L}$ change? We can't compute this directly in one step, because $w$ doesn't affect $\mathcal{L}$ directly — it affects $\mathcal{L}$ **through a chain**: $w$ affects $z$, $z$ affects $a$, and $a$ affects $\mathcal{L}$. This is exactly the multi-link chain rule setup from Section 7.3.2:

$$\frac{\partial \mathcal{L}}{\partial w} = \frac{\partial \mathcal{L}}{\partial a}\cdot\frac{\partial a}{\partial z}\cdot\frac{\partial z}{\partial w}$$

Let's compute each of these three "local" derivatives separately, then multiply them together.

### 7.4.3 Computing $\frac{\partial \mathcal{L}}{\partial a}$

$$\mathcal{L} = \frac{1}{2}(y-a)^2$$

Using the chain rule on this expression itself (treating $(y-a)$ as the "inner function"):

$$\frac{\partial \mathcal{L}}{\partial a} = \frac{1}{2} \times 2(y-a) \times \frac{\partial}{\partial a}(y-a) = (y-a) \times (-1) = a-y$$

(This matches exactly what we derived back in Step 5.4.2 — no surprise, since it's the same calculation.)

### 7.4.4 Computing $\frac{\partial a}{\partial z}$

Since $a = \sigma(z)$, and we already derived the sigmoid derivative in File 1, Section 4.4.1:

$$\frac{\partial a}{\partial z} = \sigma'(z) = \sigma(z)(1-\sigma(z)) = a(1-a)$$

(Using $a=\sigma(z)$ to substitute directly.)

### 7.4.5 Computing $\frac{\partial z}{\partial w}$

Since $z = wx+b$, and we're differentiating with respect to $w$ (treating $x$ and $b$ as constants for this particular partial derivative):

$$\frac{\partial z}{\partial w} = x$$

(Basic differentiation: the derivative of $wx$ with respect to $w$ is just $x$, since $x$ is being held constant, and the derivative of the constant $b$ with respect to $w$ is 0.)

### 7.4.6 Assembling the Full Chain Rule Result

$$\frac{\partial \mathcal{L}}{\partial w} = \underbrace{(a-y)}_{\partial \mathcal{L}/\partial a} \times \underbrace{a(1-a)}_{\partial a/\partial z} \times \underbrace{x}_{\partial z/\partial w}$$

$$\boxed{\frac{\partial \mathcal{L}}{\partial w} = (a-y)\cdot a(1-a)\cdot x}$$

And similarly, for the bias (since $\frac{\partial z}{\partial b} = 1$, because $z=wx+b$ and the derivative of $b$ with respect to itself is 1):

$$\frac{\partial \mathcal{L}}{\partial b} = (a-y)\cdot a(1-a)\cdot 1 = (a-y)\cdot a(1-a)$$

### 7.4.7 Fully Worked Numerical Example

Let's put in real numbers. Suppose $x=2$, $w=0.5$, $b=-0.1$, and the true label $y=1$.

**Forward pass:**

$$z = (0.5)(2)+(-0.1) = 1-0.1=0.9$$

$$a=\sigma(0.9) = \frac{1}{1+e^{-0.9}}$$

We need $e^{-0.9}$. Using $e^{-0.9} \approx 0.4066$:

$$a = \frac{1}{1+0.4066} = \frac{1}{1.4066} \approx 0.7109$$

**Loss:**

$$\mathcal{L} = \frac{1}{2}(1-0.7109)^2 = \frac{1}{2}(0.2891)^2 = \frac{1}{2}(0.0836) = 0.0418$$

**Backward pass — computing $\frac{\partial \mathcal{L}}{\partial w}$:**

First, $(a-y) = 0.7109-1 = -0.2891$

Next, $a(1-a) = 0.7109 \times (1-0.7109) = 0.7109 \times 0.2891 \approx 0.2055$

Finally, multiply all three pieces together (recall $x=2$):

$$\frac{\partial \mathcal{L}}{\partial w} = (-0.2891) \times (0.2055) \times (2)$$

Let's multiply step by step:
$$(-0.2891)\times(0.2055) \approx -0.05941$$
$$-0.05941 \times 2 \approx -0.11881$$

$$\frac{\partial \mathcal{L}}{\partial w} \approx -0.1188$$

**Interpretation**: the gradient is negative, meaning increasing $w$ would *decrease* the loss (recall Step 6.3.2: to minimize, move opposite the sign of the gradient — since the gradient is negative here, gradient descent will *increase* $w$).

**Applying the gradient descent update** (using learning rate $\eta=0.5$, just for this illustration):

$$w \leftarrow w - \eta \frac{\partial \mathcal{L}}{\partial w} = 0.5 - (0.5)(-0.1188) = 0.5+0.0594 = 0.5594$$

The weight increased slightly, exactly as our sign analysis predicted. Let's sanity check this was the right move: with the true label $y=1$, and our current prediction $a=0.7109$ being *less than* 1 (an underestimate), increasing $w$ (which increases $z$, which increases $a$, since sigmoid is an increasing function) should push our prediction $a$ closer to the true value of 1 — exactly what we want. **The math worked out exactly as intuition says it should**, which is a great habit to build: after every gradient computation, sanity-check the sign against what you'd intuitively expect.

## 7.5 Backpropagation Through Multiple Layers — The General Case

Now let's extend this to a network with multiple layers, which is where backpropagation earns its name — because we compute gradients by working **backward**, layer by layer, from the output toward the input, reusing computation at each step (this reuse is precisely what makes it efficient, rather than recomputing everything from scratch for every single weight).

### 7.5.1 Setting Up Notation for a 2-Layer Network

Recall from File 1, Section 3.4.5, the forward pass for a network with layers indexed by $\ell$:

$$\mathbf{z}^{(\ell)} = W^{(\ell)}\mathbf{a}^{(\ell-1)}+\mathbf{b}^{(\ell)}, \qquad \mathbf{a}^{(\ell)} = f(\mathbf{z}^{(\ell)})$$

Suppose we have 2 layers total: layer 1 (hidden) and layer 2 (output), and our loss is $\mathcal{L}$, computed from the final output $\mathbf{a}^{(2)}$.

### 7.5.2 Defining the "Error Signal" $\boldsymbol{\delta}$

To keep the notation clean (and to expose the structure that makes backpropagation efficient), we define an intermediate quantity called the **error signal** (or simply "delta") at each layer:

$$\boldsymbol{\delta}^{(\ell)} := \frac{\partial \mathcal{L}}{\partial \mathbf{z}^{(\ell)}}$$

This represents: "how sensitive is the final loss to a small change in this layer's pre-activation values?" This is the central quantity backpropagation computes, layer by layer, working backward.

### 7.5.3 Computing the Output Layer's Error Signal $\boldsymbol{\delta}^{(2)}$

At the output layer, we can compute this directly using the chain rule, exactly as we did for the single neuron in Section 7.4:

$$\boldsymbol{\delta}^{(2)} = \frac{\partial \mathcal{L}}{\partial \mathbf{a}^{(2)}} \odot f'(\mathbf{z}^{(2)})$$

Here, $\odot$ means **element-wise multiplication** (multiply corresponding entries of two vectors together, producing a new vector of the same size) — we need this instead of a dot product because we're computing a separate error signal for each individual neuron in the layer, not combining them into one number.

### 7.5.4 The Key Backward Recursion — How Error Signals Propagate Backward Through Layers

Here is the heart of backpropagation — the formula that lets us compute layer 1's error signal $\boldsymbol{\delta}^{(1)}$ **using layer 2's already-computed error signal** $\boldsymbol{\delta}^{(2)}$, without redoing the entire chain rule computation from scratch:

$$\boldsymbol{\delta}^{(1)} = \left( (W^{(2)})^T \boldsymbol{\delta}^{(2)} \right) \odot f'(\mathbf{z}^{(1)})$$

**Let's understand where this comes from.** We want $\frac{\partial \mathcal{L}}{\partial \mathbf{z}^{(1)}}$. The loss depends on $\mathbf{z}^{(1)}$ only through the chain: $\mathbf{z}^{(1)} \to \mathbf{a}^{(1)} \to \mathbf{z}^{(2)} \to \mathbf{a}^{(2)} \to \mathcal{L}$. 

For a single neuron $j$ in layer 1, using the chain rule (summing over all the layer-2 neurons $k$ that neuron $j$ feeds into, since neuron $j$'s output affects *every* neuron in the next layer, in a fully-connected network):

$$\frac{\partial \mathcal{L}}{\partial z^{(1)}_j} = \sum_k \frac{\partial \mathcal{L}}{\partial z^{(2)}_k}\cdot\frac{\partial z^{(2)}_k}{\partial a^{(1)}_j}\cdot\frac{\partial a^{(1)}_j}{\partial z^{(1)}_j}$$

We recognize $\frac{\partial \mathcal{L}}{\partial z^{(2)}_k} = \delta^{(2)}_k$ (that's literally the definition from Section 7.5.2). And since $z^{(2)}_k = \sum_j w^{(2)}_{k,j}a^{(1)}_j + b^{(2)}_k$, we have $\frac{\partial z^{(2)}_k}{\partial a^{(1)}_j} = w^{(2)}_{k,j}$ (the weight connecting neuron $j$ in layer 1 to neuron $k$ in layer 2). So:

$$\delta^{(1)}_j = \left(\sum_k w^{(2)}_{k,j}\delta^{(2)}_k\right) \times f'(z^{(1)}_j)$$

The sum $\sum_k w^{(2)}_{k,j}\delta^{(2)}_k$ is precisely what the matrix expression $(W^{(2)})^T\boldsymbol{\delta}^{(2)}$ computes for every $j$ simultaneously (transposing $W^{(2)}$ flips its rows and columns, which correctly redirects each weight's contribution backward to the neuron it originated from) — confirming the vector formula stated above.

**Why this matters computationally**: notice that computing $\boldsymbol{\delta}^{(1)}$ only required $\boldsymbol{\delta}^{(2)}$ (already computed), the weight matrix $W^{(2)}$ (already known from the forward pass), and $f'(\mathbf{z}^{(1)})$ (cheap to compute, and $\mathbf{z}^{(1)}$ was already saved from the forward pass). We never had to redo the full chain-rule derivation from scratch for layer 1 — we **reused** the work already done for layer 2. This reuse is what makes backpropagation computationally efficient: for a network with $L$ layers, computing all gradients takes roughly the same amount of computation as just ONE forward pass (not $L$ separate expensive recomputations) — an enormously important efficiency property, especially for networks with dozens or hundreds of layers, like modern LLMs.

### 7.5.5 From Error Signals to Actual Weight Gradients

Once we have $\boldsymbol{\delta}^{(\ell)}$ for every layer, getting the actual gradient with respect to the weights is straightforward (one more small step of the chain rule, since $z^{(\ell)}_j = \sum_i w^{(\ell)}_{j,i}a^{(\ell-1)}_i+b^{(\ell)}_j$, so $\frac{\partial z^{(\ell)}_j}{\partial w^{(\ell)}_{j,i}}=a^{(\ell-1)}_i$):

$$\frac{\partial \mathcal{L}}{\partial w^{(\ell)}_{j,i}} = \delta^{(\ell)}_j \cdot a^{(\ell-1)}_i$$

Or in clean matrix form:

$$\frac{\partial \mathcal{L}}{\partial W^{(\ell)}} = \boldsymbol{\delta}^{(\ell)}(\mathbf{a}^{(\ell-1)})^T$$

And for the bias, since $\frac{\partial z^{(\ell)}_j}{\partial b^{(\ell)}_j}=1$:

$$\frac{\partial \mathcal{L}}{\partial \mathbf{b}^{(\ell)}} = \boldsymbol{\delta}^{(\ell)}$$

## 7.6 Fully Worked Multi-Layer Numerical Example

Let's do a complete forward pass AND backward pass, by hand, for a tiny network: 2 inputs → 2 hidden neurons (sigmoid) → 1 output neuron (sigmoid), trained on MSE loss.

**Setup:**

Input: $x_1=1, x_2=0$. True label: $y=1$.

Weights (layer 1, hidden layer):
$$W^{(1)} = \begin{bmatrix} 0.3 & -0.2 \\ 0.4 & 0.1 \end{bmatrix}, \quad \mathbf{b}^{(1)} = \begin{bmatrix} 0.1 \\ -0.1 \end{bmatrix}$$

(Row 1 = weights for hidden neuron 1: $w_{1,1}=0.3, w_{1,2}=-0.2$. Row 2 = weights for hidden neuron 2: $w_{2,1}=0.4, w_{2,2}=0.1$.)

Weights (layer 2, output layer):
$$W^{(2)} = \begin{bmatrix} 0.5 & -0.3 \end{bmatrix}, \quad b^{(2)}=0.2$$

### 7.6.1 Forward Pass

**Hidden layer pre-activations:**

$$z^{(1)}_1 = (0.3)(1)+(-0.2)(0)+0.1 = 0.3+0+0.1=0.4$$
$$z^{(1)}_2 = (0.4)(1)+(0.1)(0)+(-0.1) = 0.4+0-0.1=0.3$$

**Hidden layer activations (sigmoid):**

$$a^{(1)}_1 = \sigma(0.4) = \frac{1}{1+e^{-0.4}}$$

Using $e^{-0.4}\approx 0.6703$:

$$a^{(1)}_1 = \frac{1}{1.6703} \approx 0.5987$$

$$a^{(1)}_2 = \sigma(0.3) = \frac{1}{1+e^{-0.3}}$$

Using $e^{-0.3}\approx 0.7408$:

$$a^{(1)}_2 = \frac{1}{1.7408}\approx 0.5744$$

**Output layer pre-activation:**

$$z^{(2)} = (0.5)(0.5987)+(-0.3)(0.5744)+0.2$$

Computing each term:
$$(0.5)(0.5987) = 0.29935$$
$$(-0.3)(0.5744) = -0.17232$$

$$z^{(2)} = 0.29935-0.17232+0.2 = 0.32703$$

**Output activation:**

$$a^{(2)}=\sigma(0.32703) = \frac{1}{1+e^{-0.32703}}$$

Using $e^{-0.32703}\approx 0.7211$:

$$a^{(2)} = \frac{1}{1.7211}\approx 0.5810$$

**Loss:**

$$\mathcal{L} = \frac{1}{2}(y-a^{(2)})^2 = \frac{1}{2}(1-0.5810)^2 = \frac{1}{2}(0.4190)^2 = \frac{1}{2}(0.17556) \approx 0.0878$$

### 7.6.2 Backward Pass

**Step 1 — output layer error signal $\delta^{(2)}$:**

$$\delta^{(2)} = (a^{(2)}-y)\cdot a^{(2)}(1-a^{(2)})$$

$$(a^{(2)}-y) = 0.5810-1=-0.4190$$

$$a^{(2)}(1-a^{(2)}) = 0.5810\times(1-0.5810)=0.5810\times0.4190\approx0.2434$$

$$\delta^{(2)} = (-0.4190)\times(0.2434)\approx-0.10199$$

**Step 2 — hidden layer error signals $\delta^{(1)}_1, \delta^{(1)}_2$, using the backward recursion:**

$$\boldsymbol{\delta}^{(1)} = \left((W^{(2)})^T\delta^{(2)}\right)\odot f'(\mathbf{z}^{(1)})$$

$(W^{(2)})^T$ is just $W^{(2)}=[0.5, -0.3]$ transposed into a column: $\begin{bmatrix}0.5\\-0.3\end{bmatrix}$

$$(W^{(2)})^T\delta^{(2)} = \begin{bmatrix}0.5\\-0.3\end{bmatrix}\times(-0.10199) = \begin{bmatrix}0.5\times(-0.10199)\\-0.3\times(-0.10199)\end{bmatrix} = \begin{bmatrix}-0.05100\\0.03060\end{bmatrix}$$

Now we need $f'(z^{(1)}_1)$ and $f'(z^{(1)}_2)$ — since $f=\sigma$:

$$\sigma'(z^{(1)}_1) = a^{(1)}_1(1-a^{(1)}_1) = 0.5987\times(1-0.5987)=0.5987\times0.4013\approx0.2403$$

$$\sigma'(z^{(1)}_2) = a^{(1)}_2(1-a^{(1)}_2) = 0.5744\times(1-0.5744)=0.5744\times0.4256\approx0.2445$$

Now, element-wise multiply:

$$\delta^{(1)}_1 = -0.05100\times0.2403\approx-0.01225$$
$$\delta^{(1)}_2 = 0.03060\times0.2445\approx0.00748$$

### 7.6.3 Computing the Actual Weight Gradients

**Output layer weights** ($\frac{\partial\mathcal{L}}{\partial W^{(2)}} = \delta^{(2)}(\mathbf{a}^{(1)})^T$):

$$\frac{\partial\mathcal{L}}{\partial w^{(2)}_1} = \delta^{(2)}\times a^{(1)}_1 = (-0.10199)\times(0.5987)\approx-0.06108$$

$$\frac{\partial\mathcal{L}}{\partial w^{(2)}_2} = \delta^{(2)}\times a^{(1)}_2 = (-0.10199)\times(0.5744)\approx-0.05858$$

$$\frac{\partial\mathcal{L}}{\partial b^{(2)}} = \delta^{(2)} = -0.10199$$

**Hidden layer weights** ($\frac{\partial\mathcal{L}}{\partial w^{(1)}_{j,i}} = \delta^{(1)}_j \times x_i$, since $\mathbf{a}^{(0)}=\mathbf{x}$):

$$\frac{\partial\mathcal{L}}{\partial w^{(1)}_{1,1}} = \delta^{(1)}_1\times x_1 = (-0.01225)\times1=-0.01225$$

$$\frac{\partial\mathcal{L}}{\partial w^{(1)}_{1,2}} = \delta^{(1)}_1\times x_2 = (-0.01225)\times0=0$$

$$\frac{\partial\mathcal{L}}{\partial w^{(1)}_{2,1}} = \delta^{(1)}_2\times x_1 = (0.00748)\times1=0.00748$$

$$\frac{\partial\mathcal{L}}{\partial w^{(1)}_{2,2}} = \delta^{(1)}_2\times x_2 = (0.00748)\times0=0$$

$$\frac{\partial\mathcal{L}}{\partial b^{(1)}_1}=\delta^{(1)}_1=-0.01225 \qquad \frac{\partial\mathcal{L}}{\partial b^{(1)}_2}=\delta^{(1)}_2=0.00748$$

**We now have every single gradient needed to update every single weight in this network**, computed via exactly ONE forward pass and ONE backward pass — this efficiency (one backward pass computes gradients for ALL weights simultaneously) is precisely why backpropagation made training deep networks computationally feasible, and it's the exact algorithm (scaled up to billions of parameters, and implemented with heavy engineering optimization) running every time any neural network, including every LLM, is trained.

**Applying gradient descent** (learning rate $\eta=0.5$, just to illustrate one update):

$$w^{(2)}_1 \leftarrow 0.5-(0.5)(-0.06108) = 0.5+0.03054=0.53054$$

Every other weight would update analogously, each nudged in the direction that reduces the loss, by an amount proportional to how much that specific weight contributed to the error (exactly what "backpropagation calculates which weights caused the error," our Step 7 main question, means in concrete, computed numbers).

---

# Step 8: Deep Networks

### Main Question: *How do multiple layers learn representations?*

## 8.1 The Everyday Analogy

Think about how you learned to read. You didn't jump straight from "seeing shapes on a page" to "understanding entire sentences." There was a hierarchy:

1. First, you learned to recognize individual **letter shapes** (a curve is "c" or "o", a vertical line with a hook is "j").
2. Then, you learned to combine letters into **phonetic sounds** and eventually whole **words**.
3. Then, you learned to combine words into **phrases and grammatical structures**.
4. Finally, you combine phrases into **full sentences with meaning**, and eventually, whole paragraphs and stories with themes and implications.

Each stage builds on the previous one, and each stage represents information at a more abstract, more useful level than the one before. **Deep networks learn representations in exactly this hierarchical way** — automatically, from data, without anyone telling them "first learn edges, then shapes" — the training process (gradient descent + backpropagation, Steps 6-7) discovers this hierarchy on its own, because it's genuinely the most effective way to solve most complex real-world problems.

## 8.2 The Tech Analogy

Think about how a modern software system is built in **layers of abstraction**: at the very bottom, there's raw electrical voltage and transistors. Above that, machine code (raw binary instructions). Above that, assembly language. Above that, a high-level programming language like Python. Above that, a web framework. Above that, your actual application logic. Each layer takes what the layer below provides and organizes it into a more useful, more abstract form, hiding the messy details of the layer beneath it. 

A deep neural network does the exact same thing, but the "layers of abstraction" are **learned automatically from data**, rather than designed by human engineers. The first layer might learn something like "detect this specific pixel pattern"; a middle layer might learn "detect an eye shape, given a certain pixel pattern"; a later layer might learn "detect a face, given eye + nose + mouth shapes are present" — all discovered purely by gradient descent minimizing a loss function, with no human ever explicitly programming "look for eyes."

## 8.3 Why Depth Specifically Helps — the Mathematical/Representational Argument

We already proved in File 1 (Section 4.3) that **stacking layers without non-linear activations is mathematically pointless** — it collapses to a single layer. But given that we DO have non-linear activations at every layer, why does adding MORE layers (going deeper) help, as opposed to just making ONE hidden layer WIDER (adding more neurons to a single hidden layer)?

### 8.3.1 The Universal Approximation Theorem (What It Says, and Its Important Limitation)

There's a famous mathematical result called the **Universal Approximation Theorem**, which states (informally): a neural network with just **one** sufficiently wide hidden layer, using a suitable non-linear activation function, can approximate **any** continuous function to arbitrary precision, given enough hidden neurons.

**This sounds like it means depth doesn't matter at all — a single wide layer can do anything!** But there's a crucial catch that's often glossed over: the theorem says such a network **exists**, but says nothing about:

1. **How many neurons are needed** — for genuinely complex functions (like "understand and generate human language," which is what LLMs do), the required width for a single-hidden-layer network to achieve good performance can be **exponentially large** — potentially requiring more neurons than atoms in the observable universe for sufficiently complex real-world tasks.

2. **How easy it is to actually find those weights via gradient descent** — the theorem is a pure existence proof; it says nothing about whether gradient descent (Step 6) can actually discover the right weights in practice, in a reasonable amount of training time.

### 8.3.2 The Practical Reality: Depth Provides Exponential Efficiency

Empirically (and to a significant extent, theoretically, in specific studied cases), **deep** networks (many layers, each moderately sized) can represent certain complex functions using **exponentially fewer total neurons** than a **shallow but very wide** network representing the same function. 

**Intuitive reasoning why**: think back to our hierarchical reading analogy. If a "wide, shallow" network had to learn to recognize a whole word directly from raw pixels, in one giant leap, it would need to independently learn every possible pixel-pattern-to-word mapping — an enormous, mostly-redundant undertaking. But a "deep" network can learn "detect edges" ONCE (in an early layer), and then **reuse** that edge-detection capability as a building block for recognizing many different letters (in a middle layer), and reuse letter-detection as a building block for recognizing many different words (in a later layer). This **reuse of intermediate representations** is what gives depth its exponential efficiency advantage — each layer's learned features become reusable "parts" that later layers can combine in combinatorially many ways, rather than each output category needing to be learned as an entirely separate, unrelated pattern.

## 8.4 What Do Different Layers Actually Learn? (Empirical Findings)

This is a question that's been studied extensively, especially in computer vision (where it's easier to visualize what a layer has learned, by looking at which input patterns most strongly activate a given neuron). The consistent empirical finding, across many different trained networks:

- **Early layers** learn very generic, simple, low-level features: edges, color gradients, simple textures. Remarkably, early layers in *completely different* networks, trained on *completely different* datasets and tasks, often learn nearly identical low-level features — suggesting these are close to universally useful building blocks for processing visual (or, analogously, sequential/linguistic) data.

- **Middle layers** learn more complex, combined features: for images, this might be textures, simple shapes, parts of objects (a wheel, an eye, a wing). For language models, this might be syntactic patterns, simple grammatical relationships, or basic semantic groupings (e.g., recognizing that "king," "queen," "prince" belong to a similar category).

- **Later layers** learn highly abstract, task-specific, high-level concepts: for image classifiers, entire object categories ("this is a golden retriever," combining fur texture + ear shape + snout shape + overall body proportions learned in earlier layers). For language models, this might be complex reasoning patterns, long-range contextual relationships, or task-specific behaviors.

This progression — generic/low-level to specific/high-level, as you go deeper — is remarkably consistent, and is the entire basis for a hugely important practical technique called **transfer learning**: since early layers tend to learn generic, broadly-useful features, you can often take a network already trained on one large dataset, keep its early layers mostly unchanged, and only retrain (or lightly adjust) the later layers for a new, related task — dramatically reducing the amount of new training data and computation needed. (We will return to this idea, in a more LLM-specific form, in Steps 16-17 on Fine-tuning and RLHF — the core intuition of "reuse a large pretrained network's general capabilities, then adapt only a smaller part for a specific purpose" is exactly this same principle.)

## 8.5 Practical Training Challenges With Deep Networks

Given everything above, it might seem like "just make the network deeper" is always a free lunch. In practice, there are serious challenges that emerge specifically as networks get deeper, which you've already studied at a conceptual level, and which we can now understand precisely given the backpropagation math from Step 7.

### 8.5.1 Vanishing Gradients — Now Provable, Given Step 7's Math

Recall from Section 7.5.4, the backward recursion for error signals:

$$\boldsymbol{\delta}^{(\ell)} = \left((W^{(\ell+1)})^T\boldsymbol{\delta}^{(\ell+1)}\right)\odot f'(\mathbf{z}^{(\ell)})$$

Notice that computing $\boldsymbol{\delta}^{(\ell)}$ (the error signal for an early layer) requires **multiplying together** a chain of terms involving $f'(\mathbf{z}^{(\ell)})$ from EVERY layer between $\ell$ and the output. If we're using sigmoid activation (recall from File 1: maximum derivative value is $0.25$, achieved only at $z=0$; typically much smaller), and our network has, say, 20 layers, the error signal reaching the very first layer involves multiplying roughly 20 sigmoid-derivative terms together:

$$\delta^{(1)} \propto f'(z^{(1)}) \times f'(z^{(2)}) \times \dots \times f'(z^{(20)}) \times (\text{other terms})$$

Even if every single $f'(z^{(\ell)})$ were at its theoretical maximum of $0.25$ (which is generally not the case in practice — many will be smaller), the product would be:

$$0.25^{20} \approx 0.00000000000009 = 9\times 10^{-14}$$

This is an almost incomprehensibly tiny number. Any gradient signal reaching the first layer would be multiplied by something on this order — meaning the first layer's weights would receive an essentially negligible learning signal, no matter how large the true "error" at the output actually is. **This is the vanishing gradient problem, now derived precisely from the backpropagation math**, rather than just stated as an empirical observation.

**Solutions developed by the field** (many of which you've already studied, and some of which we'll revisit in later files):
- **ReLU activation** (File 1, Section 4.4.3): has derivative exactly 1 for positive inputs, so it doesn't shrink the gradient at all when active — dramatically alleviating (though not entirely eliminating, due to dead ReLU issues) vanishing gradients.
- **Batch normalization** (which you've studied): keeps the pre-activation values $z$ in a well-behaved numerical range throughout training, preventing them from drifting into regions where activation derivatives become tiny.
- **Residual/skip connections**: a technique (used heavily in modern deep networks, including Transformers, which we'll formalize in Step 13) where a layer's input is added directly to its output, creating a "shortcut" path for gradients to flow backward without being multiplied through every single intermediate layer's derivative. We will derive the mathematics of exactly why this helps when we reach the Transformer architecture.

### 8.5.2 Exploding Gradients

The opposite problem: if the weight matrices $W^{(\ell)}$ have large values, the repeated multiplication in the backward recursion can cause gradients to grow **exponentially large** rather than exponentially small, leading to unstable, wildly oscillating training (similar in spirit to the "learning rate too large" divergence example we hand-computed in Section 6.3.5, but caused by network depth rather than an oversized learning rate). Common mitigations include **gradient clipping** (capping the maximum allowed gradient magnitude before applying the update) and careful weight initialization schemes (choosing the initial random weight values according to specific mathematical formulas designed to keep signal magnitudes stable across layers, such as Xavier/Glorot initialization or He initialization).

## 8.6 Fully Worked Illustration: Vanishing Gradient Magnitude, Layer by Layer

Let's make the vanishing gradient problem completely concrete with actual numbers, extending our understanding from Section 8.5.1.

Suppose we have a 5-layer sigmoid network, and suppose (for illustration) that at every layer, the pre-activation $z^{(\ell)}$ happens to equal exactly 2 (a specific, moderate value — not deep in the saturated region, but not at the peak either).

**Step 1: Compute $\sigma(2)$ and $\sigma'(2)$ (we actually already did this in File 1!):**

$$\sigma(2) \approx 0.881, \qquad \sigma'(2) = 0.881\times(1-0.881)=0.881\times0.119\approx0.1048$$

**Step 2: Suppose the output layer's error signal has magnitude $\delta^{(5)}=1.0$ (a clean round number for illustration).**

**Step 3: Propagate backward, assuming (for simplicity) all connecting weights are exactly 1** (so the weight-transpose-multiplication term doesn't change the magnitude, letting us isolate purely the effect of the repeated $\sigma'$ multiplications):

$$|\delta^{(4)}| = |\delta^{(5)}|\times\sigma'(2) = 1.0\times0.1048=0.1048$$

$$|\delta^{(3)}| = |\delta^{(4)}|\times\sigma'(2) = 0.1048\times0.1048\approx0.01098$$

$$|\delta^{(2)}| = |\delta^{(3)}|\times\sigma'(2) = 0.01098\times0.1048\approx0.001151$$

$$|\delta^{(1)}| = |\delta^{(2)}|\times\sigma'(2) = 0.001151\times0.1048\approx0.0001206$$

**Observe the magnitude collapsing**: $1.0 \to 0.1048 \to 0.01098 \to 0.001151 \to 0.0001206$ — roughly shrinking by a factor of 10 at every single layer. By the time this error signal reaches layer 1, it's over **8,000 times smaller** than it was at the output layer ($1.0 / 0.0001206 \approx 8{,}300$). In a network with even more layers (real modern networks can have hundreds of layers), this effect compounds catastrophically, which is exactly why the innovations mentioned in Section 8.5.1 (ReLU, batch norm, residual connections) were such crucial breakthroughs for enabling genuinely deep networks to train successfully at all.

---

# Summary Cheat Sheet

**Loss functions** — the "how wrong are we" measurement:
$$\text{MSE} = \frac{1}{N}\sum_k(y_k-\hat{y}_k)^2 \qquad \text{(regression)}$$
$$\mathcal{L}_{\text{CE}} = -\ln(\hat{y}_c) \qquad \text{(classification, } c \text{ = true class)}$$

**Gradient descent** — the "how do we improve" update rule:
$$w \leftarrow w-\eta\frac{\partial\mathcal{L}}{\partial w}$$

**Backpropagation** — the "how do we compute that gradient efficiently, for every weight" algorithm, via the chain rule:
$$\boldsymbol{\delta}^{(\ell)} = \left((W^{(\ell+1)})^T\boldsymbol{\delta}^{(\ell+1)}\right)\odot f'(\mathbf{z}^{(\ell)}) \qquad \frac{\partial\mathcal{L}}{\partial W^{(\ell)}} = \boldsymbol{\delta}^{(\ell)}(\mathbf{a}^{(\ell-1)})^T$$

**Deep networks** — depth provides exponentially more efficient representation than width alone, by allowing reuse of learned intermediate features across layers, but introduces vanishing/exploding gradient challenges that must be specifically engineered around (ReLU, batch norm, residual connections, careful initialization).

---

# Self-Test Questions

1. Derive, from first principles (reasoning about canceling positive/negative errors), why we square the error in MSE rather than just averaging raw errors.
2. Compute the binary cross-entropy loss by hand for true label $y=0$ and predicted $\hat{y}=0.2$.
3. Explain, using the foggy hillside analogy, what the gradient vector $\nabla\mathcal{L}$ represents geometrically, and why we move in the *negative* gradient direction.
4. Using $\mathcal{L}(w)=3w^2-12w+5$, perform 3 iterations of gradient descent by hand, starting at $w_0=0$ with $\eta=0.05$, showing every computation.
5. Explain the difference between batch, stochastic, and mini-batch gradient descent, and why mini-batch is the practical standard.
6. State the chain rule for a 3-link chain ($y$ depends on $u$, depends on $v$, depends on $x$), and explain in your own words why the derivatives multiply rather than add.
7. Without looking back at the derivation, re-derive $\frac{\partial\mathcal{L}}{\partial w}$ for a single sigmoid neuron trained on MSE loss, showing each of the three chain rule pieces.
8. In the multi-layer worked example (Section 7.6), explain in your own words what $\delta^{(1)}_1$ represents, and why its formula involves $W^{(2)}$ even though $W^{(2)}$ belongs to a "later" layer than the one we're computing the gradient for.
9. Explain why a network with one very wide hidden layer is theoretically capable of approximating any function (Universal Approximation Theorem), but deep networks are still preferred in practice.
10. Reproduce the numerical illustration in Section 8.6 with $z^{(\ell)}=1$ instead of $z^{(\ell)}=2$ at every layer, and compare how much faster or slower the gradient vanishes.

---

*End of File 2. File 3 will cover: Embeddings and RNNs (Steps 9-10) — moving from single fixed-size inputs toward representing words as vectors, and processing sequences of arbitrary length, which is the first major step toward language modeling.*

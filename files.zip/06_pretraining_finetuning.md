# File 6 of 20: From Architecture to Trained Model
## Pretraining → Fine-tuning

> **Continuity note**: File 5 completed the GPT architecture — every equation needed to take a sequence of tokens and produce next-token probabilities. But an architecture with random, untrained weights produces gibberish. This file explains exactly how billions of tokens of text get turned into the trained weights that make GPT actually useful (**Pretraining**), and then how a raw pretrained model — which is really just a very sophisticated autocomplete engine — gets shaped into something that behaves like a helpful assistant that follows instructions (**Fine-tuning**).

---

# Table of Contents

1. [Step 15: Pretraining](#step-15-pretraining)
2. [Step 16: Fine-tuning](#step-16-fine-tuning)
3. [Summary Cheat Sheet](#summary-cheat-sheet)
4. [Self-Test Questions](#self-test-questions)

---

# Step 15: Pretraining

### Main Question: *How is an LLM actually trained?*

## 15.1 The Everyday Analogy

Imagine a student preparing for a general-knowledge quiz competition by reading an enormous number of books, magazines, and articles — not with any single quiz question in mind, but simply absorbing patterns: how sentences are typically structured, what facts commonly appear together, how arguments are usually built, what typically follows what. Nobody sits with the student and grades each individual sentence; instead, the student continuously tests themselves with a simple, repeatable exercise: **cover up the next word in whatever they're reading, try to guess it, then reveal the actual word and see how close their guess was.** Repeated across millions of pages, this simple self-testing exercise, done at massive scale, builds a deep, general understanding of language, facts, and reasoning patterns — purely as a side effect of getting extremely good at the narrow task of "guess the next word."

**This is exactly what pretraining is.** The "quiz" is next-token prediction (Step 14's exact mechanism), the "books" are a massive text corpus, and the "self-grading" is the loss function (File 2, Step 5) computed automatically, without any human needing to label anything.

## 15.2 The Tech Analogy

Think of pretraining like **compiling a codebase with millions of unit tests that auto-generate themselves from the codebase's own history.** Every single position in every training document automatically becomes both an input (everything before that position) and a label (the actual next token) — there's no separate "labeling" step required, unlike traditional supervised learning where humans must manually annotate each example. This is why pretraining is called **self-supervised learning**: the supervision signal (the correct answer) comes directly from the data itself, not from external human annotation.

## 15.3 The Complete Pretraining Objective — Full Mathematical Derivation

### 15.3.1 Setting Up: The Data

Suppose our training corpus, after tokenization, is one enormous sequence of tokens: $w_1, w_2, w_3, \dots, w_M$ (where $M$ could be trillions of tokens for a large-scale modern LLM, though your own small models will use vastly smaller corpora — the mathematics is identical regardless of scale).

### 15.3.2 The Autoregressive Factorization — Deriving It From Probability Theory

Here is a foundational piece of mathematics worth deriving carefully, since it's the theoretical justification for why "just predict the next token, repeatedly" is a mathematically complete and sound strategy for modeling entire documents, not just an ad-hoc heuristic.

We want our model to represent the probability of an ENTIRE sequence of tokens, $P(w_1, w_2, \dots, w_M)$ — how likely is this whole document, according to the patterns of language? Directly modeling this joint probability over all possible token sequences is intractable (the number of possible sequences grows astronomically with length). Instead, we use the **chain rule of probability** (a standard result from probability theory, distinct from but named similarly to the calculus chain rule from File 2 — don't confuse the two):

$$P(w_1,w_2,\dots,w_M) = P(w_1)\cdot P(w_2|w_1)\cdot P(w_3|w_1,w_2)\cdots P(w_M|w_1,\dots,w_{M-1})$$

Or, written compactly using product notation $\prod$ (analogous to how $\sum$ means repeated addition, $\prod$ means repeated multiplication):

$$P(w_1,\dots,w_M) = \prod_{t=1}^{M} P(w_t | w_1,\dots,w_{t-1})$$

**Why is this decomposition exactly, mathematically correct, not just a convenient approximation?** This follows directly from the definition of conditional probability, applied repeatedly. Recall the basic definition: $P(A,B) = P(A)\cdot P(B|A)$ (the probability of both A and B happening equals the probability of A, times the probability of B GIVEN that A happened). Applying this repeatedly, peeling off one token at a time:

$$P(w_1,w_2,w_3) = P(w_1)\cdot P(w_2,w_3|w_1) = P(w_1)\cdot P(w_2|w_1)\cdot P(w_3|w_1,w_2)$$

This is not an assumption or simplification — it's a direct, exact consequence of how conditional probability is defined, and it holds for sequences of ANY length. **This is the precise mathematical justification for autoregressive generation** (which you've already studied at a practical level): a language model that can accurately estimate $P(w_t|w_1,\dots,w_{t-1})$ — exactly the next-token-prediction task GPT is built to perform (Step 14) — can, by this exact factorization, represent the FULL joint probability of entire documents, simply by multiplying together its next-token predictions at every position. There is no information being lost or approximated by this "just predict the next token" framing; it is a complete, exact representation of the full sequence probability, by a basic law of probability theory.

### 15.3.3 The Training Objective — Maximum Likelihood

Given this factorization, training a language model means choosing weights $\theta$ (a common shorthand symbol representing "all the trainable parameters of the model" — every weight matrix and bias vector across every layer, collected together) that make the TRAINING DATA as probable as possible, according to the model. This is called **Maximum Likelihood Estimation (MLE)**, a foundational concept in statistics: we choose parameters to maximize the probability the model assigns to the data we actually observed.

$$\theta^* = \arg\max_{\theta} \prod_{t=1}^{M} P_\theta(w_t|w_1,\dots,w_{t-1})$$

($\arg\max_\theta$ means "the value of $\theta$ that maximizes the following expression" — we're searching over all possible weight configurations for the one that makes this product as large as possible.)

### 15.3.4 Why We Use Log-Likelihood Instead of Raw Likelihood — A Practical Derivation

Directly working with this product of probabilities is numerically treacherous: multiplying together thousands or millions of probabilities (each a number between 0 and 1, often much smaller than 1) produces an astronomically tiny number, which can cause **numerical underflow** on a computer (the number becomes so small it's indistinguishable from zero due to floating-point precision limits). 

The standard fix: take the **logarithm** of the objective. Recall a key property of logarithms you've likely learned in math class: $\log(a\times b) = \log(a)+\log(b)$ — logarithms convert multiplication into addition. Applying this:

$$\log\left(\prod_{t=1}^{M}P_\theta(w_t|w_1,\dots,w_{t-1})\right) = \sum_{t=1}^{M}\log P_\theta(w_t|w_1,\dots,w_{t-1})$$

Since $\log$ is a **monotonically increasing function** (if $a>b$, then $\log(a)>\log(b)$ — logarithm never changes the relative ordering of values), maximizing the log-likelihood gives the EXACT SAME optimal $\theta$ as maximizing the raw likelihood — we haven't changed the answer to our optimization problem at all, we've just made it numerically tractable AND converted a product into a sum (which is both easier to compute and easier to differentiate, since the derivative of a sum is just the sum of derivatives, while the derivative of a product requires the more complex product rule).

### 15.3.5 Connecting Directly to Cross-Entropy Loss — Closing the Loop With File 2

$$\theta^* = \arg\max_\theta \sum_{t=1}^{M}\log P_\theta(w_t|w_1,\dots,w_{t-1})$$

By convention, optimization algorithms (like gradient descent, File 2 Step 6) are typically framed as MINIMIZING a loss, not maximizing an objective. We convert between these trivially by negating:

$$\theta^* = \arg\min_\theta \left[-\sum_{t=1}^{M}\log P_\theta(w_t|w_1,\dots,w_{t-1})\right]$$

**Look very closely at this expression.** Recall from File 2, Section 5.5.5, the categorical cross-entropy loss for a single prediction, where $c$ is the true class: $\mathcal{L}_{\text{CE}} = -\ln(\hat{y}_c)$. Our pretraining objective is **precisely this same cross-entropy loss, summed (or, in practice, averaged) across every single token position in the training corpus** — where, at each position $t$, the "true class" is the actual next token $w_t$, and $\hat{y}_c = P_\theta(w_t|w_1,\dots,w_{t-1})$ is exactly the probability the model assigned to that correct token, via the softmax output derived in File 5, Section 14.4.1.

**This is one of the most important unifying realizations in this entire 20-file series**: pretraining an LLM is not some exotic, unique training procedure requiring new mathematical machinery — it is **the exact same gradient descent + backpropagation + cross-entropy loss framework derived in complete generality back in File 2**, applied at the scale of an entire internet-sized text corpus, one next-token-prediction at a time, using the GPT architecture from File 5 to compute each $P_\theta(w_t|\dots)$.

## 15.4 Fully Worked Numerical Example — Computing Pretraining Loss on a Real Sequence

Let's compute the complete pretraining loss for a tiny example sequence, showing exactly how the abstract formula in Section 15.3.5 becomes concrete numbers.

**Setup**: Suppose our training sequence (after tokenization) is 4 tokens: "the", "cat", "sat", "down". Suppose our (partially-trained, imperfect) model, when given each prefix, produces the following probabilities for the ACTUAL next token that appeared in the training data:

| Position $t$ | Context (input prefix) | True next token | Model's assigned probability $P_\theta(w_t|\dots)$ |
|---|---|---|---|
| 1 | (nothing — start of sequence) | "the" | 0.15 |
| 2 | "the" | "cat" | 0.08 |
| 3 | "the cat" | "sat" | 0.35 |
| 4 | "the cat sat" | "down" | 0.60 |

(In a real model, position 1 with no context would typically predict from the marginal/overall frequency of tokens that commonly start documents — the specific value 0.15 is just illustrative here.)

**Step 1 — compute $-\log P_\theta$ for each position** (using natural log, matching our derivation):

$$-\ln(0.15) \approx -(-1.897) = 1.897$$

$$-\ln(0.08) \approx -(-2.526) = 2.526$$

$$-\ln(0.35) \approx -(-1.050) = 1.050$$

$$-\ln(0.60) \approx -(-0.511) = 0.511$$

(These log values can be verified: $\ln(0.15)=\ln(15/100)=\ln(15)-\ln(100)\approx2.708-4.605=-1.897$ ✓, and similarly for the others, using standard log properties and known reference values like $\ln(2)\approx0.693, \ln(10)\approx2.303$.)

**Step 2 — sum (this is our total loss for this 4-token sequence):**

$$\text{Total Loss} = 1.897+2.526+1.050+0.511 = 5.984$$

**Step 3 — average, if we want a per-token loss** (common in practice, so the loss value doesn't simply grow with sequence length, making it easier to compare across sequences of different lengths):

$$\text{Average Loss} = \frac{5.984}{4} = 1.496$$

**Interpretation**: on average, this partially-trained model incurs a loss of about 1.496 per token on this sequence. Notice position 2 ("the" → "cat") had the LOWEST assigned probability (0.08) and correspondingly the HIGHEST individual loss contribution (2.526) — this makes sense, since "the" could plausibly be followed by an enormous number of different nouns ("the dog," "the house," "the weather," etc.), so even a well-trained model would reasonably spread probability across many candidates, giving each one (including the actual correct one, "cat") a relatively modest individual probability. By contrast, position 4 ("the cat sat" → "down") had a much higher probability (0.60) and lower loss, since "down" (or perhaps "on," "quietly," etc.) is a much more constrained, predictable continuation given the specific preceding context.

## 15.5 Perplexity — Converting Loss Into an Interpretable Number

You've already studied perplexity as an evaluation metric, so let's now derive precisely how it connects to the loss we just computed, closing that conceptual loop.

### 15.5.1 The Formula and Its Derivation

$$\text{Perplexity} = e^{\text{Average Loss}}$$

(Using $e$, matching our natural-log-based loss computation above; if loss were computed using $\log_2$ instead, perplexity would be $2^{\text{Average Loss}}$ — the specific base must match between the loss computation and the perplexity exponentiation for the formula to be consistent.)

**Why exponentiate the average negative log-likelihood specifically? Let's derive the intuition precisely.** Consider a hypothetical "perfectly uncertain" model that assigns EQUAL probability to every one of $V$ possible tokens at every position — i.e., $P_\theta(w_t|\dots) = \frac{1}{V}$ always (this would be the behavior of a completely untrained, randomly-initialized model with no learned preferences whatsoever).

For such a model, the average loss would be:

$$\text{Average Loss} = -\ln\left(\frac{1}{V}\right) = \ln(V)$$

And the perplexity would be:

$$\text{Perplexity} = e^{\ln(V)} = V$$

**This is the key interpretive result**: perplexity equals $V$ (the full vocabulary size) precisely when the model is maximally uncertain (uniform probability over everything). This gives us a wonderfully intuitive interpretation: **perplexity can be understood as "the model behaves AS IF it's uniformly guessing between approximately this many equally-likely options" at each step.** A perplexity of 50 means "the model's uncertainty at each step is roughly equivalent to needing to pick uniformly among 50 options" — even though, in reality, the model isn't uniform at all (it typically concentrates most probability on a much smaller set of plausible tokens, exactly as we saw in Section 15.4's example, where "sat" and "down" received much higher probability than a uniform distribution would give them). Lower perplexity means better, more confident, more accurate predictions; a well-trained modern LLM might achieve a perplexity in the range of roughly 10-20 on typical held-out text (compared to a vocabulary size of 50,000+), reflecting genuinely substantial, learned predictive confidence, though exact figures vary considerably based on model size, training data, and the specific text being evaluated.

### 15.5.2 Fully Worked Numerical Example

Using our Section 15.4 result, Average Loss $=1.496$:

$$\text{Perplexity} = e^{1.496}$$

We need $e^{1.496}$. We know $e^{1.5}\approx4.4817$ (a commonly memorized reference value), and $1.496$ is very close to $1.5$:

$$e^{1.496} \approx e^{1.5}\times e^{-0.004} \approx 4.4817\times(1-0.004) \approx 4.4817\times0.996\approx4.464$$

**Interpretation**: this (still quite early-in-training, given the modest probabilities in our example) model's performance on this sequence is roughly equivalent to uniformly guessing among about 4.46 options at each step — a moderate level of uncertainty, consistent with a model that has learned SOME useful structure (it's much better than being uniform across an entire 50,000+ word vocabulary) but still has room for improvement (a fully converged, well-trained model would typically achieve a lower perplexity on text similar to its training distribution).

## 15.6 The Scale of Real Pretraining — What Actually Happens in Practice

While the mathematics above is complete and exact, it's worth being concrete about the practical scale at which this process actually runs for real, production LLMs (useful context for understanding why pretraining is so resource-intensive, even though every individual computation is one you now understand precisely):

- **Data scale**: modern large LLMs are pretrained on trillions of tokens — drawn from massive web crawls, books, code repositories, scientific papers, and other sources, filtered and cleaned extensively before training.
- **Compute scale**: this involves performing the forward pass (Section 14.5) and backward pass (backpropagation, File 2 Step 7 — now applied through the FULL depth of a many-layer Transformer, and across every token position, simultaneously, for every example in massive batches) for these trillions of tokens, using thousands of specialized GPU/TPU chips running in parallel for weeks or months.
- **Optimization details**: real pretraining doesn't use plain gradient descent as derived in File 2, Section 6.3 — it uses more sophisticated optimizers (most commonly **Adam** or its variants like AdamW), which adaptively adjust the effective learning rate for EACH individual weight, based on the recent history of that weight's gradients — helping navigate the extremely complex, high-dimensional loss landscape (recall File 2, Section 6.5) more effectively than plain gradient descent's single, global learning rate.
- **Learning rate schedules**: rather than a single, fixed learning rate throughout training, practical pretraining typically uses a "warmup" period (gradually increasing the learning rate from near-zero over the first portion of training, to avoid destabilizing the randomly-initialized weights with large early updates) followed by a gradual "decay" (slowly decreasing the learning rate over the remainder of training, allowing progressively finer-grained convergence toward a good solution) — directly informed by the learning-rate-sensitivity lessons we derived numerically in File 2, Section 6.3.5.

**The crucial reassurance for your own small-model work**: every one of these practical/scale considerations is a matter of DEGREE, not a fundamentally different algorithm. Your own tiny GPT models, trained on your Mac on a much smaller corpus, are running through the EXACT same mathematical process — autoregressive next-token prediction, cross-entropy loss, backpropagation, gradient-based weight updates — just at a scale that fits on consumer hardware in a reasonable amount of time, rather than requiring an industrial-scale compute cluster.

## 15.7 What Pretraining Actually Produces — the "Base Model"

It's crucial to understand precisely WHAT KIND of capability emerges purely from this next-token-prediction pretraining process, before we move to Step 16's fine-tuning, since this sets up exactly why fine-tuning is necessary.

A model that has ONLY been pretrained (often called a **base model**) has learned, with remarkable depth and nuance, **the statistical patterns of its training text** — including grammar, facts, reasoning patterns, and even stylistic conventions. However, it has learned to do exactly ONE thing: **continue text in a way that's statistically plausible, given its training distribution** — NOT specifically to be helpful, NOT specifically to follow instructions, NOT specifically to refuse harmful requests, NOT specifically to have a consistent "assistant" persona.

**Concrete illustration of the problem**: if you gave a pure base model the prompt "Explain photosynthesis," it might NOT actually answer your question directly. Since its training data likely contained many examples of similar-looking text in contexts like homework assignment LISTS, or forum threads where such a question is followed by OTHER, unrelated questions (rather than an actual answer), the base model might just as easily continue with "Explain cellular respiration. Explain mitosis. Explain..." (continuing a plausible-looking list of homework questions) rather than providing a helpful explanation — because, from a pure next-token-statistics perspective, continuing the list might be an entirely PLAUSIBLE (even highly probable, if such lists were common in its training data) continuation of that exact text pattern, and the base model has no learned preference whatsoever for "being helpful" over "being statistically plausible."

**This is precisely the gap that Step 16 (Fine-tuning) exists to close.**

---

# Step 16: Fine-tuning

### Main Question: *How does it become an assistant?*

## 16.1 The Everyday Analogy

Imagine a brilliant new employee who has just finished an extremely thorough general education — they've read an enormous number of books and absorbed vast general knowledge (this is our pretrained base model) — but they have never actually worked in a customer service job, and don't yet know the specific EXPECTED BEHAVIORS of that role: how to format a helpful response, when to ask a clarifying question versus when to just answer, how to politely decline inappropriate requests, what tone to use.

**Fine-tuning is precisely the on-the-job training phase**: giving this already-knowledgeable employee a smaller, much more specifically curated set of example interactions — "here's an example of a GREAT customer service response to this KIND of question," repeated across many examples covering many different situations — until the employee reliably adopts the desired behavioral PATTERN, while still drawing on all the general knowledge they already had from their earlier, much broader education.

## 16.2 The Tech Analogy

Recall the concept of **transfer learning**, which we introduced conceptually in File 2, Section 8.4: take a network already trained on one large, general task, and adapt it (often with much less additional data and computation) to a new, more specific task. Fine-tuning an LLM is a direct application of exactly this principle: the pretrained base model's weights already encode enormous amounts of useful general knowledge and language understanding (analogous to the "early/middle layers learn generic, broadly-useful features" finding from File 2, Section 8.4) — fine-tuning ADJUSTS these weights (typically with a much smaller dataset and much lower learning rate than pretraining used) to specifically shape the model's BEHAVIOR, without needing to relearn language and knowledge from scratch.

## 16.3 Supervised Fine-Tuning (SFT) — The Full Mathematics

### 16.3.1 What Changes, and What Doesn't

Here is a genuinely important, easy-to-miss point: **Supervised Fine-Tuning (SFT) uses the EXACT SAME mathematical objective as pretraining** — next-token prediction, via cross-entropy loss, via gradient descent and backpropagation (Section 15.3.5's complete derivation applies identically here). **The only thing that changes is the DATA.**

Instead of training on raw, unstructured internet/book text (where "what comes next" is simply whatever naturally followed in the original document), SFT trains on a curated dataset of **(instruction, ideal response)** pairs, specifically written or selected by humans (or increasingly, generated by other, already-capable AI models, then reviewed/filtered by humans) to DEMONSTRATE the desired assistant behavior.

### 16.3.2 The Data Format

A typical SFT training example looks like:

```
[INSTRUCTION]: Explain photosynthesis in simple terms.
[RESPONSE]: Photosynthesis is the process plants use to convert sunlight into energy. Using sunlight, water, and carbon dioxide, plants produce glucose (their food) and release oxygen as a byproduct...
```

During SFT training, this entire formatted text (instruction + response, often with special delimiter tokens marking where the instruction ends and the response begins) is fed through the model using the EXACT SAME autoregressive next-token-prediction mechanism from Section 15.3 — BUT with one crucial, deliberate modification:

### 16.3.3 Loss Masking — Only Learning From the Response

We typically compute the loss ONLY on the tokens belonging to the [RESPONSE] portion, NOT on the [INSTRUCTION] portion. This is called **loss masking**, and it's a direct, simple extension of the per-token loss summation from Section 15.3.5:

$$\mathcal{L}_{\text{SFT}} = -\sum_{t \in \text{response tokens}} \log P_\theta(w_t|w_1,\dots,w_{t-1})$$

Notice the sum now runs only over $t \in \text{response tokens}$ (a SUBSET of all token positions in the full instruction+response sequence), rather than over every single token position as in full pretraining (Section 15.3.5's sum ran over ALL $t$ from 1 to $M$).

**Why mask out the instruction portion specifically? Let's reason through this carefully.** We want the model to learn "GIVEN an instruction like this, PRODUCE a response like this" — we do NOT want to spend training signal teaching the model to predict/generate the INSTRUCTION text itself (that's not a useful skill for an assistant; the user will always provide their own instruction, the model never needs to generate one). By masking the loss to only the response tokens, we focus 100% of the gradient-based learning signal specifically on "how to respond well," using the (unmasked, still fully processed via forward-pass attention) instruction purely as CONTEXT that the model can attend to, without ever being penalized or rewarded for how well it could predict the instruction's own wording.

### 16.3.4 Fully Worked Numerical Example — Loss Masking in Action

Let's make this completely concrete with a tiny example sequence: "Explain gravity [SEP] Gravity pulls objects together" (using [SEP] as a simple delimiter marking where the instruction ends and response begins), where "Explain gravity [SEP]" is the instruction portion (4 tokens: "Explain", "gravity", "[SEP]" — let's simplify and treat "Explain gravity [SEP]" as exactly 3 tokens for this illustration) and "Gravity pulls objects together" is the response (4 tokens: "Gravity", "pulls", "objects", "together").

Suppose our model, processing this full 7-token sequence, produces the following per-position probabilities for each ACTUAL next token:

| Position | Token being predicted | Is this a response token? | Model's probability | Included in loss? |
|---|---|---|---|---|
| 1 | "Explain" | No (instruction) | 0.05 | Masked out |
| 2 | "gravity" | No (instruction) | 0.30 | Masked out |
| 3 | "[SEP]" | No (instruction) | 0.90 | Masked out |
| 4 | "Gravity" | Yes (response) | 0.20 | **Included** |
| 5 | "pulls" | Yes (response) | 0.40 | **Included** |
| 6 | "objects" | Yes (response) | 0.25 | **Included** |
| 7 | "together" | Yes (response) | 0.55 | **Included** |

**Computing the SFT loss** — we only sum over positions 4, 5, 6, 7:

$$-\ln(0.20) \approx 1.609$$
$$-\ln(0.40) \approx 0.916$$
$$-\ln(0.25) \approx 1.386$$
$$-\ln(0.55) \approx 0.598$$

$$\mathcal{L}_{\text{SFT}} = 1.609+0.916+1.386+0.598 = 4.509$$

Notice positions 1, 2, 3's probabilities (0.05, 0.30, 0.90) never entered this calculation at all — even though position 1's probability (0.05, quite low) would have contributed a substantial loss term (specifically $-\ln(0.05)\approx3.0$) if it HAD been included. By excluding it, we ensure gradient updates from this example are driven ENTIRELY by how well the model predicted the response text, not by how "surprised" it was by the specific wording of the instruction — exactly matching our derived rationale in Section 16.3.3.

## 16.4 Why Fine-Tuning Requires Vastly Less Data Than Pretraining

This is worth deriving conceptually, connecting back to File 2's discussion of representations (Section 8.4). Pretraining must teach the model EVERYTHING from scratch: grammar, vast factual knowledge, reasoning patterns, style conventions across every domain and topic imaginable — requiring an enormous, maximally diverse dataset (trillions of tokens) to adequately cover this immense scope.

Fine-tuning, by contrast, does NOT need to re-teach any of this. It only needs to teach a comparatively narrow, specific behavioral PATTERN: "when given an instruction, respond helpfully, directly, and appropriately" — a much more constrained skill that can be demonstrated effectively with a comparatively small number of well-chosen examples (production SFT datasets might range from thousands to a few hundred thousand examples — vastly smaller than pretraining's trillions of tokens), precisely because the heavy lifting of "understanding language and the world" was already accomplished during pretraining. This is the exact same transfer-learning efficiency argument from File 2, Section 8.4, now applied concretely to LLM training: fine-tuning **reuses** pretraining's general-purpose representations, adjusting them for a specific, narrower purpose, rather than learning everything anew.

## 16.5 Fully Worked Illustration — How Fine-Tuning Shifts Probability Mass

Let's illustrate, with concrete (simplified/illustrative) numbers, how the fine-tuning process might shift a model's behavior on our earlier "list continuation" problem from Section 15.7.

**Before fine-tuning** (base model), given the prompt "Explain photosynthesis," suppose the model's probability distribution over a few plausible next tokens is:

| Next token candidate | Base model probability |
|---|---|
| "." (ending the phrase, likely continuing with a list) | 0.40 |
| "Explain" (starting a new list item, e.g. "Explain cellular respiration") | 0.25 |
| "in" (beginning to actually answer, e.g. "in simple terms...") | 0.10 |
| "Photosynthesis" (beginning to actually answer) | 0.08 |
| (all other tokens, combined) | 0.17 |

The base model gives substantial probability (0.40+0.25=0.65 combined) to continuations that DON'T actually answer the question, versus only a modest combined probability (0.10+0.08=0.18) to tokens that would begin an actual explanation.

**After SFT** (having been trained on many examples where instructions are always followed by direct, helpful answers, using the loss-masking procedure from Section 16.3.3), gradient descent will have repeatedly pushed the model's weights in the direction that INCREASES probability on response-initiating tokens (since these were the "correct" next tokens in every training example) and DECREASES probability on list-continuation-style tokens (since these never appeared as correct answers in the curated SFT dataset). A plausible resulting distribution:

| Next token candidate | Post-SFT probability |
|---|---|
| "." | 0.02 |
| "Explain" | 0.01 |
| "in" | 0.35 |
| "Photosynthesis" | 0.45 |
| (all other tokens, combined) | 0.17 |

**The underlying KNOWLEDGE about photosynthesis hasn't changed at all** (that was already present from pretraining) — what has changed, purely through the fine-tuning process's gradient updates on curated instruction-response examples, is the model's learned BEHAVIORAL TENDENCY to actually USE that knowledge to directly answer questions, rather than to continue text in other statistically-plausible-but-unhelpful ways. This illustrates precisely, in probability terms, what "fine-tuning shapes behavior without needing to re-teach knowledge" concretely means.

## 16.6 A Preview of What's Still Missing

Supervised fine-tuning, as derived above, teaches a model to imitate the STYLE and FORMAT of good responses, based on curated examples. But it has an important limitation worth flagging clearly, since it directly motivates our next file: SFT can only teach the model to reproduce responses similar to ones humans (or other models) have EXPLICITLY written out in the training data. It provides no direct mechanism for capturing more nuanced, comparative human preferences — like "this response is fine, but THIS other response is even better, because it's more concise" or "avoid this SPECIFIC kind of response, even though no human has written out a full counter-example demonstrating exactly what to do instead." 

**This is precisely the gap that RLHF (Reinforcement Learning from Human Feedback) and DPO (Direct Preference Optimization) — our next file's subject — are designed to address**: rather than learning purely from "here is a good response, imitate its exact wording," these techniques learn from COMPARISONS ("response A is preferred over response B"), enabling a more nuanced, scalable shaping of model behavior that goes beyond what direct imitation of a fixed set of written examples can achieve.

---

# Summary Cheat Sheet

**Pretraining** — self-supervised next-token prediction at massive scale, using the exact File 2 loss/optimization framework:

$$\theta^* = \arg\min_\theta\left[-\sum_{t=1}^{M}\log P_\theta(w_t|w_1,\dots,w_{t-1})\right]$$

derived exactly from the probability chain rule and maximum likelihood estimation.

**Perplexity** — an interpretable transform of average loss:

$$\text{Perplexity} = e^{\text{Average Loss}}$$

interpretable as "the model behaves as if uniformly uncertain among approximately this many options."

**Base model limitation**: learns statistical patterns of text, NOT a preference for being helpful — will continue text in any statistically plausible way, including unhelpful ways.

**Supervised Fine-Tuning (SFT)** — the same next-token-prediction/cross-entropy machinery, applied to curated (instruction, response) pairs, with loss masked to only the response tokens:

$$\mathcal{L}_{\text{SFT}} = -\sum_{t\in\text{response tokens}}\log P_\theta(w_t|w_1,\dots,w_{t-1})$$

Requires vastly less data than pretraining, since it reshapes BEHAVIOR using pretraining's already-learned general KNOWLEDGE, rather than teaching knowledge from scratch.

---

# Self-Test Questions

1. Derive, using the definition of conditional probability, the chain rule factorization $P(w_1,w_2,w_3)=P(w_1)P(w_2|w_1)P(w_3|w_1,w_2)$, extending the two-token case shown in this file to three tokens explicitly.
2. Explain why taking the logarithm of the likelihood objective doesn't change WHICH weights $\theta$ are optimal, using the property of monotonically increasing functions.
3. Recompute the pretraining loss example from Section 15.4, but suppose the model's probability for "cat" (position 2) had instead been 0.02. Recompute the total loss, average loss, and resulting perplexity, and comment on how much these values changed compared to the original.
4. Derive, from scratch, why a maximally uncertain (uniform probability) model has a perplexity exactly equal to the vocabulary size $V$.
5. Explain, in your own words, why a purely pretrained base model might fail to directly answer a question, using a DIFFERENT example scenario than the "Explain photosynthesis" case in this file.
6. Explain what loss masking is, and reproduce the worked example in Section 16.3.4, but suppose position 1 ("Explain") were mistakenly INCLUDED in the loss with its 0.05 probability — compute the resulting (incorrect) loss, and explain conceptually why including it would be undesirable.
7. Using the transfer-learning argument from File 2, Section 8.4, explain in your own words why fine-tuning needs vastly less data than pretraining.
8. In the "before/after SFT" probability table (Section 16.5), verify that both the "before" and "after" probability columns each sum to 1.0, and explain what it would mean if they didn't.
9. Explain the practical difference between plain gradient descent (File 2, Section 6.3) and the Adam optimizer mentioned in Section 15.6, at a conceptual level (you aren't expected to derive Adam's full update rule yet, but should be able to explain what problem it's trying to solve).
10. Explain, in your own words, what specific limitation of SFT motivates the need for preference-based training methods like RLHF/DPO, previewed in Section 16.6.

---

*End of File 6. File 7 will cover: RLHF and DPO (Step 17) — how models learn from comparative human preferences rather than only from fixed example responses, including the full mathematics of reward modeling, policy optimization, and the more recent, simpler Direct Preference Optimization approach.*

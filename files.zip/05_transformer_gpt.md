# File 5 of 20: From Mechanism to Architecture to Language Model
## The Transformer → GPT

> **Continuity note**: File 4 derived the attention mechanism in complete mathematical detail — the single most important formula in modern deep learning. But attention alone is just one ingredient. This file assembles attention together with several other essential pieces (positional encoding, residual connections, layer normalization, feedforward blocks) into the complete **Transformer** architecture, and then shows precisely how this architecture is configured and trained to become **GPT** — an autoregressive language model capable of generating text one token at a time, exactly like the model producing this sentence.

---

# Table of Contents

1. [Step 13: The Transformer](#step-13-the-transformer)
2. [Step 14: GPT](#step-14-gpt)
3. [Summary Cheat Sheet](#summary-cheat-sheet)
4. [Self-Test Questions](#self-test-questions)

---

# Step 13: The Transformer

### Main Question: *How does attention become an architecture?*

## 13.1 The Everyday Analogy

Imagine attention (File 4) is like a brilliant idea for one specific tool — say, an incredibly sharp knife. A sharp knife alone doesn't make a kitchen; you also need a stove, a chopping board, a way to season food, a way to plate the final dish, and a recipe telling you in what ORDER to use all these tools together. 

**The Transformer is the complete "kitchen" built around the attention "knife."** It combines the attention mechanism with several other essential components — some purely structural (helping the network train stably and deeply, like a good chopping board that keeps things organized), and one that solves a problem we haven't discussed yet: attention, as derived in File 4, has **no inherent sense of word order** (we'll prove this precisely below) — a genuinely serious gap for processing language, where order is often critical to meaning, that must be explicitly patched in.

## 13.2 The Tech Analogy

Think of the Transformer like a **well-architected software application built from several well-tested components**, each solving a specific engineering problem:
- **Attention layers** = the core "business logic" doing the actual information-mixing work
- **Positional encoding** = metadata/timestamps injected into your data pipeline, since the core processing logic (attention) is otherwise "order-blind"
- **Residual connections** = like a version-control "diff" system — instead of each layer completely replacing the previous state, it computes and adds a small "patch" or "update," making it much easier to train very deep stacks of layers reliably
- **Layer normalization** = like standardizing units/formats between pipeline stages, so each stage receives well-behaved, consistently-scaled input, rather than wildly varying magnitudes that could destabilize training

Just as a real production software system needs more than just "the core algorithm" to actually work reliably at scale, a real Transformer needs more than just "the attention formula" to actually train successfully on deep, large-scale networks.

## 13.3 Proving Attention Alone Is Order-Blind (Permutation Invariance)

Before introducing the fix, let's rigorously establish the problem. Recall the attention formula from File 4:

$$\text{Attention}(Q,K,V) = \text{softmax}\left(\frac{QK^T}{\sqrt{d_k}}\right)V$$

**Claim**: if you shuffle (permute) the order of the input tokens, the SET of output vectors produced by self-attention is exactly the same set, just correspondingly reshuffled — meaning attention treats a sequence as an unordered SET of tokens, not an ordered sequence, unless something else provides order information.

**Reasoning**: Recall from Section 12.4.3-12.4.6, the output for query position $i$ is:

$$\mathbf{z}_i = \sum_{j=1}^{n}\alpha_{i,j}\mathbf{v}_j$$

This is a **sum over all $j$** — and addition is **commutative** (the order in which you add numbers doesn't change the sum: $a+b=b+a$). If we relabeled/reordered the indices $j$ (i.e., shuffled which token is "token 1," "token 2," etc.), the sum $\sum_j \alpha_{i,j}\mathbf{v}_j$ would still evaluate to the exact same value, as long as each $(\alpha_{i,j}, \mathbf{v}_j)$ pair stays correctly matched with each other. There is nothing in the formula ITSELF that encodes "token $j$ came before or after token $i$ in the original sentence" — the formula only cares about the CONTENT of each token's Query/Key/Value, not its POSITION.

**Concrete illustration of why this is a real problem**: consider the two sentences "the dog bit the man" and "the man bit the dog." Both sentences contain the exact same set of words/tokens — only their ORDER differs. If we fed both sentences' tokens into a pure self-attention layer (with no positional information whatsoever), the attention mechanism would have absolutely no way to distinguish which arrangement it's looking at, because it only sees each token's content-based Query/Key/Value vectors, never their position in the sequence. Yet these two sentences have **opposite meanings** (who bit whom!) — a catastrophic failure if left unaddressed.

## 13.4 Positional Encoding — Injecting Order Information

### 13.4.1 The Core Idea

The fix: before feeding token embeddings into the attention layers, we **add** a **position-dependent vector** to each token's embedding, such that the network can use this added information to recover ordering. If token embeddings are $\mathbf{x}_i$ (from Step 9) and positional encodings are $\mathbf{p}_i$ (one distinct vector per position $i=1,2,3,\dots$), the actual input to the Transformer becomes:

$$\mathbf{x}'_i = \mathbf{x}_i + \mathbf{p}_i$$

### 13.4.2 The Original Sinusoidal Positional Encoding — Full Mathematics

The original Transformer paper ("Attention Is All You Need," 2017) proposed a specific, clever formula using sine and cosine waves of different frequencies:

$$PE_{(pos,2m)} = \sin\left(\frac{pos}{10000^{2m/d}}\right)$$

$$PE_{(pos,2m+1)} = \cos\left(\frac{pos}{10000^{2m/d}}\right)$$

Here $pos$ is the position in the sequence (1st word, 2nd word, etc.), $d$ is the embedding dimension, and $m$ indexes which PAIR of dimensions we're computing (even-indexed dimensions use sine, odd-indexed dimensions use cosine, at the SAME underlying frequency for each pair).

**Why sine and cosine waves specifically? Let's build the intuition.** Think of an analog clock with multiple hands: a second hand (very fast rotation, high frequency), a minute hand (medium frequency), and an hour hand (slow rotation, low frequency). By reading the combined position of ALL THREE hands together, you can determine a very precise, essentially unique time (down to the second) across a full 12-hour cycle — even though each INDIVIDUAL hand, by itself, would give you only ambiguous, repeating information (the second hand alone can't tell you what hour it is).

The positional encoding scheme works exactly like this: different dimensions of $\mathbf{p}_i$ oscillate at **different frequencies** (controlled by the $10000^{2m/d}$ term in the denominator — as $m$ increases, this term grows, making the sine/cosine wave's frequency slower). Low-numbered dimensions oscillate very quickly (like a second hand — good for encoding fine-grained, LOCAL position information, like "am I right next to the previous word?"), while high-numbered dimensions oscillate very slowly (like an hour hand — good for encoding coarse, GLOBAL position information, like "am I near the beginning or end of a very long document?"). Combined across all dimensions, this gives every position a distinct, learnable "fingerprint."

### 13.4.3 Fully Worked Numerical Example — Computing Positional Encodings by Hand

Let's compute the positional encoding vector for position 1 ($pos=1$) and position 2 ($pos=2$), using a small embedding dimension $d=4$ (so $m=0$ and $m=1$, producing dimension pairs $(0,1)$ and $(2,3)$).

**For $m=0$** (dimensions 0 and 1): the denominator term is $10000^{2(0)/4} = 10000^0 = 1$

$$PE_{(pos,0)} = \sin\left(\frac{pos}{1}\right) = \sin(pos)$$
$$PE_{(pos,1)} = \cos\left(\frac{pos}{1}\right) = \cos(pos)$$

**For $m=1$** (dimensions 2 and 3): the denominator term is $10000^{2(1)/4} = 10000^{0.5} = \sqrt{10000}=100$

$$PE_{(pos,2)} = \sin\left(\frac{pos}{100}\right)$$
$$PE_{(pos,3)} = \cos\left(\frac{pos}{100}\right)$$

**Computing for $pos=1$:**

$$PE_{(1,0)} = \sin(1) \approx 0.8415$$
$$PE_{(1,1)} = \cos(1) \approx 0.5403$$
$$PE_{(1,2)} = \sin(0.01) \approx 0.0100$$
$$PE_{(1,3)} = \cos(0.01) \approx 0.99995$$

$$\mathbf{p}_1 \approx \begin{bmatrix}0.8415\\0.5403\\0.0100\\0.99995\end{bmatrix}$$

**Computing for $pos=2$:**

$$PE_{(2,0)} = \sin(2) \approx 0.9093$$
$$PE_{(2,1)} = \cos(2) \approx -0.4161$$
$$PE_{(2,2)} = \sin(0.02) \approx 0.0200$$
$$PE_{(2,3)} = \cos(0.02) \approx 0.9998$$

$$\mathbf{p}_2 \approx \begin{bmatrix}0.9093\\-0.4161\\0.0200\\0.9998\end{bmatrix}$$

**Notice**: dimensions 0-1 (the high-frequency pair) change substantially between position 1 and position 2 ($0.8415\to0.9093$ and $0.5403\to-0.4161$ — a big swing), while dimensions 2-3 (the low-frequency pair) barely change ($0.0100\to0.0200$, $0.99995\to0.9998$ — tiny movements). This exactly matches our clock-hands intuition: fast-oscillating dimensions distinguish nearby positions clearly, while slow-oscillating dimensions only meaningfully differ over much longer position ranges — together, all dimensions combined give every position a unique signature, distinguishable at both fine and coarse scales.

### 13.4.4 A Note on Modern Alternatives

Modern LLMs (including most recent GPT-style models) often use alternatives like **Rotary Positional Embeddings (RoPE)**, which encode position information by mathematically ROTATING the query and key vectors by an angle proportional to their position, rather than simply adding a fixed vector to the input embedding. The underlying goal is identical (give the network usable position information), but RoPE has empirically shown better performance, especially for handling sequences longer than what was seen during training. The full derivation of RoPE involves complex-number rotation mathematics that's somewhat involved; for now, understand that it's solving the exact same fundamental problem (attention's order-blindness) via a more sophisticated mechanism, and we note it here as something worth exploring further if you want to go deeper into modern architectural variants.

## 13.5 Residual (Skip) Connections

### 13.5.1 The Everyday Analogy

Imagine you're revising an essay draft. Instead of completely rewriting the entire essay from scratch at every revision pass (risking losing good parts that were already working well), a smart editing process is: **keep the original draft, and just ADD small, targeted improvements/corrections on top of it.** Each revision pass only needs to figure out "what small change should I make," not "let me regenerate the entire essay from nothing" — this is both easier to do well AND easier to learn how to do (as a skill), since you're not responsible for preserving everything that was already good; it's automatically preserved by default, and you only need to focus on the delta/improvement.

### 13.5.2 The Full Mathematics

A residual connection restructures a layer's computation from:

$$\mathbf{y} = \text{Layer}(\mathbf{x}) \qquad \text{(standard, non-residual)}$$

to:

$$\mathbf{y} = \mathbf{x} + \text{Layer}(\mathbf{x}) \qquad \text{(residual)}$$

The layer now only needs to learn the **residual** — the difference/correction to ADD to the input — rather than needing to learn how to reproduce the entire input's information from scratch AND add something useful on top of it.

### 13.5.3 Why This Dramatically Helps Gradient Flow — A Precise Derivation

Let's derive exactly why this helps, using the chain rule (File 2, Step 7). For the residual form $\mathbf{y}=\mathbf{x}+\text{Layer}(\mathbf{x})$, the gradient of $\mathbf{y}$ with respect to $\mathbf{x}$ is:

$$\frac{\partial\mathbf{y}}{\partial\mathbf{x}} = I + \frac{\partial \text{Layer}(\mathbf{x})}{\partial\mathbf{x}}$$

where $I$ is the **identity matrix** (the derivative of $\mathbf{x}$ with respect to itself is exactly 1 in every dimension, hence the identity matrix — a matrix with 1s on the diagonal and 0s elsewhere, which leaves any vector unchanged when multiplied).

**Why does adding this identity term matter so much?** Recall from File 2, Section 8.5.1 and File 3, Section 10.6.1: the vanishing gradient problem arises because gradients flowing backward through many layers get **repeatedly multiplied** by potentially-small derivative terms, causing the overall gradient to shrink toward zero (potentially catastrophically, as we computed numerically: $0.25^{20}\approx9\times10^{-14}$).

With a residual connection, the gradient flowing backward through this layer is $I + \frac{\partial\text{Layer}}{\partial\mathbf{x}}$ — even if $\frac{\partial\text{Layer}}{\partial\mathbf{x}}$ happens to be very small (a poorly-conditioned or still-early-in-training layer), the **identity term $I$ guarantees the gradient signal can flow through this connection completely unimpeded**, since multiplying by (or here, adding to a computation involving) the identity matrix passes information through perfectly, with no shrinkage whatsoever. Across MANY stacked residual layers (real Transformers can have dozens or even 100+ layers), the gradient has a "highway" of these identity-connections it can flow through unobstructed, dramatically mitigating vanishing gradients even in extremely deep networks — this is precisely why residual connections were a critical enabling breakthrough for training the very deep networks that power modern LLMs.

### 13.5.4 Fully Worked Numerical Illustration

Suppose a particular layer, early in training (with poorly-initialized or not-yet-useful weights), computes $\text{Layer}(\mathbf{x})$ such that its local gradient $\frac{\partial\text{Layer}}{\partial\mathbf{x}}$ happens to be very small — say, a scalar value of $0.02$ (representing a poorly-conditioned, barely-useful-yet layer, analogous to a small sigmoid-derivative value from a saturated neuron).

**Without a residual connection:**

$$\frac{\partial y}{\partial x} = 0.02$$

A gradient signal of magnitude 1.0 arriving at this layer's output would shrink to $1.0\times0.02=0.02$ by the time it passes backward through this one layer alone.

**With a residual connection:**

$$\frac{\partial y}{\partial x} = 1 + 0.02 = 1.02$$

A gradient signal of magnitude 1.0 arriving at this layer's output would become $1.0\times1.02=1.02$ — **actually slightly AMPLIFIED**, not shrunk, when passing backward through this layer, purely because of the added identity pathway. Across 50 such stacked layers, the non-residual version would shrink the gradient by a factor of $0.02^{50}$ (an inconceivably tiny number, for all practical purposes exactly zero), while the residual version would very roughly maintain gradient magnitude around 1 (multiplying $1.02^{50}\approx 2.69$ — a modest, entirely manageable growth, not the catastrophic collapse or explosion we'd see without this architectural safeguard).

## 13.6 Layer Normalization

### 13.6.1 The Everyday Analogy

Imagine a group project where different team members report their contributions using wildly different units — one person reports "I did 3 hours of work," another reports "I did 10,000 words of writing," another reports "I completed 0.5 of a milestone." Before you can meaningfully COMBINE or COMPARE these contributions, you'd want to first put them all on a common, standardized scale.

**Layer normalization does exactly this** for the numerical activations flowing through a neural network: at each layer, it rescales the activations to have a consistent, well-behaved statistical distribution (specifically, mean 0 and variance 1, before a final learned rescaling), preventing the wild swings in magnitude that could otherwise occur as data flows through many stacked layers, and which can destabilize training (recall the exploding gradient discussion from File 2, Section 8.5.2 — layer normalization is one of the standard practical tools for preventing this).

### 13.6.2 The Full Mathematics

For a vector of activations $\mathbf{x}=[x_1,x_2,\dots,x_d]$ (e.g., the $d$-dimensional output of some layer, for one specific token), layer normalization computes:

**Step 1 — compute the mean across the dimensions of this single vector:**

$$\mu = \frac{1}{d}\sum_{k=1}^{d}x_k$$

**Step 2 — compute the variance across the dimensions:**

$$\sigma^2 = \frac{1}{d}\sum_{k=1}^{d}(x_k-\mu)^2$$

**Step 3 — normalize** (subtract the mean, divide by the standard deviation, with a small constant $\epsilon$ added inside the square root purely to prevent division by zero if variance happens to be exactly 0):

$$\hat{x}_k = \frac{x_k-\mu}{\sqrt{\sigma^2+\epsilon}}$$

**Step 4 — apply a learned rescaling** (using trainable parameters $\gamma$ and $\beta$, allowing the network to learn to UNDO the normalization if that turns out to be beneficial for a specific layer/dimension, giving the network flexibility rather than rigidly forcing every layer to have exactly mean-0/variance-1 activations):

$$y_k = \gamma \hat{x}_k+\beta$$

**Important distinction from Batch Normalization (which you've already studied)**: batch normalization computes its mean/variance ACROSS THE BATCH (i.e., across many different training examples, for one specific feature/dimension), while layer normalization computes its mean/variance ACROSS THE FEATURES of a single example (i.e., across the $d$ dimensions of one specific token's vector). This distinction matters a great deal for sequence models: batch statistics depend on WHICH other examples happen to be in the current batch (and can behave poorly with variable-length sequences, or very small batch sizes), while layer normalization's statistics depend only on the single example itself, making it much better suited to the variable-length, sequential nature of language data — which is precisely why Transformers use layer normalization rather than batch normalization.

### 13.6.3 Fully Worked Numerical Example

Let's normalize a 4-dimensional activation vector: $\mathbf{x} = [10, 2, 6, 2]$

**Step 1 — mean:**

$$\mu = \frac{10+2+6+2}{4} = \frac{20}{4}=5$$

**Step 2 — variance:**

$$\sigma^2 = \frac{(10-5)^2+(2-5)^2+(6-5)^2+(2-5)^2}{4}$$

$$= \frac{25+9+1+9}{4} = \frac{44}{4}=11$$

**Step 3 — normalize** (using $\epsilon\approx0$ for simplicity, so $\sqrt{\sigma^2+\epsilon}\approx\sqrt{11}\approx3.3166$):

$$\hat{x}_1 = \frac{10-5}{3.3166} = \frac{5}{3.3166}\approx1.5077$$

$$\hat{x}_2 = \frac{2-5}{3.3166} = \frac{-3}{3.3166}\approx-0.9046$$

$$\hat{x}_3 = \frac{6-5}{3.3166} = \frac{1}{3.3166}\approx0.3015$$

$$\hat{x}_4 = \frac{2-5}{3.3166}\approx-0.9046$$

**Verification — the normalized vector should have mean approximately 0 and variance approximately 1:**

Mean check: $\frac{1.5077+(-0.9046)+0.3015+(-0.9046)}{4} = \frac{0.0000}{4}=0$ ✓ (exactly 0, as expected mathematically)

Variance check: $\frac{1}{4}\left[(1.5077)^2+(-0.9046)^2+(0.3015)^2+(-0.9046)^2\right]$

$$= \frac{1}{4}\left[2.2732+0.8183+0.0909+0.8183\right] = \frac{4.0007}{4}\approx1.0002$$

Very close to exactly 1 (tiny discrepancy purely from rounding in our hand calculations) ✓

**Step 4 — apply learned scale/shift** (suppose, for this example, the network has learned $\gamma=2, \beta=1$):

$$y_1 = 2(1.5077)+1 = 3.0154+1=4.0154$$
$$y_2 = 2(-0.9046)+1 = -1.8092+1=-0.8092$$
$$y_3 = 2(0.3015)+1 = 0.6030+1=1.6030$$
$$y_4 = 2(-0.9046)+1 = -0.8092$$

The final output $[4.0154, -0.8092, 1.6030, -0.8092]$ is what actually gets passed forward to the next part of the network — normalized for training stability, but with learned flexibility to rescale/shift as beneficial for this specific layer.

## 13.7 The Feedforward (MLP) Block Within a Transformer Layer

After the attention sub-layer, every Transformer layer also includes a position-wise feedforward network — which is, remarkably, nothing more than the plain MLP from File 1, Step 3, applied identically (same weights) to each token's vector independently:

$$\text{FFN}(\mathbf{x}) = W_2 \cdot \text{GELU}(W_1\mathbf{x}+\mathbf{b}_1) + \mathbf{b}_2$$

This is a two-layer MLP (recall File 1's exact structure), typically with an internal hidden dimension considerably LARGER than the model's main dimension (commonly 4x larger — e.g., if the main representation dimension is 768, this FFN's hidden layer might be 3072), using GELU activation (File 1, Section 4.4.5, which we noted specifically is the standard choice for modern Transformers).

**What is this feedforward block's conceptual role, distinct from attention?** Attention's job is to MIX information ACROSS different token positions (deciding what to borrow from where). The feedforward block's job is to further PROCESS the information WITHIN each individual token's representation, independently, after that mixing has occurred — you can think of attention as "gathering the right ingredients from around the sequence," and the feedforward block as "cooking/transforming what's now in front of you," applied identically and independently to every position.

## 13.8 Assembling the Complete Transformer Block

We now have every ingredient. A single Transformer block (also called a Transformer "layer," though it contains multiple sub-components) combines multi-head attention, residual connections, layer normalization, and the feedforward block, typically in this exact arrangement (called "Pre-LN," the arrangement most commonly used in modern LLMs including GPT-style models):

$$\mathbf{x}' = \mathbf{x} + \text{MultiHeadAttention}\left(\text{LayerNorm}(\mathbf{x})\right)$$

$$\mathbf{x}'' = \mathbf{x}' + \text{FFN}\left(\text{LayerNorm}(\mathbf{x}')\right)$$

Let's trace through this carefully: input $\mathbf{x}$ first gets layer-normalized, THEN passed through multi-head attention, and the ORIGINAL (pre-normalization) $\mathbf{x}$ is added back via the residual connection to produce $\mathbf{x}'$. Then $\mathbf{x}'$ gets layer-normalized again, passed through the feedforward block, and the original $\mathbf{x}'$ is added back again to produce the final output $\mathbf{x}''$ of this entire Transformer block.

**A full Transformer (and every GPT model) is simply this ENTIRE block, stacked $N$ times in sequence** (real models commonly use anywhere from 12 layers for smaller models to 96+ layers for very large models) — the output of block 1 becomes the input to block 2, and so on, with each block's residual connections providing the gradient-flow "highway" (Section 13.5.3) that makes training such deep stacks feasible at all.

## 13.9 A Complete Miniature Numerical Walkthrough

Let's trace a single token's vector through one entire simplified Transformer block, to see every piece working together (we'll use a small 4-dimensional representation and skip full multi-head splitting for tractability, treating this as single-head attention for this specific end-to-end illustration).

**Input** (a token's vector, already containing embedding + positional encoding, from Sections 9 and 13.4): $\mathbf{x} = [2, 4, 6, 8]$

**Step 1 — Layer Norm before attention:**

Mean: $\mu = \frac{2+4+6+8}{4}=\frac{20}{4}=5$

Variance: $\sigma^2 = \frac{(2-5)^2+(4-5)^2+(6-5)^2+(8-5)^2}{4} = \frac{9+1+1+9}{4}=\frac{20}{4}=5$

Normalize (using $\sqrt{5}\approx2.2361$):

$$\hat{\mathbf{x}} = \left[\frac{2-5}{2.2361},\frac{4-5}{2.2361},\frac{6-5}{2.2361},\frac{8-5}{2.2361}\right] = [-1.3416,-0.4472,0.4472,1.3416]$$

(Using $\gamma=1,\beta=0$ for simplicity here, so this is also our final layer-normalized output.)

**Step 2 — (Simplified) Attention**: for this illustration, let's suppose the attention mechanism (having processed this alongside other tokens in a real sequence — we'll skip the full multi-token computation, which we already fully demonstrated in Section 12.5, and just posit a plausible output) produces an attention output of $\text{Attn} = [0.5, -0.3, 0.8, 0.1]$.

**Step 3 — First residual connection** (add the ORIGINAL $\mathbf{x}$, not the normalized version, back to the attention output):

$$\mathbf{x}' = \mathbf{x} + \text{Attn} = [2+0.5, 4-0.3, 6+0.8, 8+0.1] = [2.5, 3.7, 6.8, 8.1]$$

**Step 4 — Layer Norm before feedforward:**

Mean: $\mu = \frac{2.5+3.7+6.8+8.1}{4} = \frac{21.1}{4}=5.275$

Variance: $\sigma^2 = \frac{(2.5-5.275)^2+(3.7-5.275)^2+(6.8-5.275)^2+(8.1-5.275)^2}{4}$

$$= \frac{(-2.775)^2+(-1.575)^2+(1.525)^2+(2.825)^2}{4} = \frac{7.7006+2.4806+2.3256+7.9806}{4}=\frac{20.4874}{4}\approx5.1219$$

Normalize (using $\sqrt{5.1219}\approx2.2632$):

$$\hat{\mathbf{x}}' \approx \left[\frac{2.5-5.275}{2.2632},\frac{3.7-5.275}{2.2632},\frac{6.8-5.275}{2.2632},\frac{8.1-5.275}{2.2632}\right]$$

$$\approx [-1.2262,-0.6959,0.6739,1.2483]$$

**Step 5 — Feedforward block** (again, for this illustration, let's posit a plausible output rather than fully specifying and computing through a real $W_1, W_2$ — we've already fully demonstrated MLP mechanics in File 1): suppose $\text{FFN}(\hat{\mathbf{x}}') = [0.2, 0.4, -0.1, 0.3]$

**Step 6 — Second residual connection:**

$$\mathbf{x}'' = \mathbf{x}' + \text{FFN} = [2.5+0.2, 3.7+0.4, 6.8-0.1, 8.1+0.3] = [2.7, 4.1, 6.7, 8.4]$$

**This final vector, $\mathbf{x}''=[2.7,4.1,6.7,8.4]$, is the output of one complete Transformer block for this token** — notice it still resembles the original input $[2,4,6,8]$ in overall structure/magnitude (thanks to the residual connections repeatedly adding back a version close to the original), but has been meaningfully refined by both the attention mechanism (incorporating context from other tokens) and the feedforward transformation. This exact six-step process repeats, block after block, for however many layers the full Transformer has (commonly dozens), progressively building up richer and richer contextual representations at each stage — directly extending the "each layer reshapes representations to make the next step's job easier" principle we first established with the hand-built XOR-solving MLP in File 1, Section 3.5.6, now operating at vastly greater depth and sophistication.

---

# Step 14: GPT

### Main Question: *How does a Transformer become a language model?*

## 14.1 The Everyday Analogy

Imagine the Transformer architecture we just built is like a general-purpose, extremely sophisticated "text understanding engine" — but an engine, by itself, doesn't tell a car where to go. GPT (**Generative Pre-trained Transformer**) takes this general engine and gives it one very specific, very consistent job: **given all the words so far, predict what word comes next** — over and over, one word at a time, using its own previous outputs as new inputs for the next prediction. This is precisely how you write a text message using predictive-text suggestions on your phone, except GPT does this with a vastly more sophisticated understanding of context, and generates entire coherent paragraphs, not just single-word suggestions.

## 14.2 The Tech Analogy

Think of GPT like an **autocomplete function running in a loop**:

```python
generated_text = "The weather today is"
for _ in range(50):  # generate 50 more tokens
    next_token = model.predict_next_token(generated_text)
    generated_text += next_token
```

Each iteration, the ENTIRE text generated so far (including the model's own previous predictions) is fed back in as input to predict just ONE more token. This self-referential loop — using your own output as your next input — is called **autoregressive generation**, a term you've already studied, and we're now formalizing exactly how the Transformer architecture from Step 13 gets adapted to make this loop work correctly.

## 14.3 The Critical Architectural Constraint: Causal (Masked) Self-Attention

### 14.3.1 The Problem With Plain Self-Attention for Generation

Recall from Section 12.4.6, plain self-attention lets every position attend to EVERY other position, including positions that come AFTER it in the sequence. This is perfectly fine for tasks where the ENTIRE input is available upfront (like translating a complete sentence you already have in full). 

But for a language model that must GENERATE text one token at a time, left to right, this is a serious problem: if we're trying to predict what word comes after "The cat sat on the," the model must NOT be allowed to "see" or attend to the actual correct answer (say, "mat") during training, or to any words that would come after it — otherwise, it's not learning to genuinely PREDICT the next word from only the preceding context; it's just learning to "cheat" by copying an answer it can already see. At actual generation time (Step 15 covers training; but let's establish the mechanism now), there IS no future text yet anyway — we're generating it one token at a time, so future tokens genuinely don't exist yet.

### 14.3.2 The Fix — Masking Future Positions

We modify the attention score computation to explicitly **forbid** any position from attending to positions that come after it, by setting those specific attention scores to negative infinity BEFORE applying softmax:

$$\text{score}(i,j) = \begin{cases} \dfrac{\mathbf{q}_i\cdot\mathbf{k}_j}{\sqrt{d_k}} & \text{if } j \leq i \\ -\infty & \text{if } j > i \end{cases}$$

**Why negative infinity specifically?** Recall the softmax formula (File 1, Section 4.4.6): $\text{softmax}(z_i) = \frac{e^{z_i}}{\sum_j e^{z_j}}$. If a score is set to $-\infty$, then $e^{-\infty} = 0$ exactly. This means, after softmax, the attention weight $\alpha_{i,j}$ for any FUTURE position $j>i$ becomes **exactly 0** — completely and precisely eliminating any contribution from future tokens, rather than just making it small. This masking pattern, when visualized as a grid (rows = query positions, columns = key positions), forms a **lower triangular** shape — position $i$ can attend to positions $1,2,\dots,i$ (itself and everything before it), but nothing at positions $i+1,i+2,\dots,n$ (anything after it).

### 14.3.3 Fully Worked Numerical Example — Causal Masking in Action

Let's revisit the exact attention example from File 4, Section 12.5, but now apply causal masking, computing the output for query position $i=1$ under the causal constraint (position 1 can ONLY attend to itself, since there's nothing before it).

Recall the raw dot-product scores we computed:

$$\text{score}(1,1)=0.7071, \quad \text{score}(1,2)=0, \quad \text{score}(1,3)=0.7071$$

**Under causal masking**, since $i=1$, only $j=1$ satisfies $j\leq i$. Positions $j=2$ and $j=3$ must be masked:

$$\text{score}(1,1)=0.7071 \quad(\text{unchanged, since } j=1\leq i=1)$$
$$\text{score}(1,2)=-\infty \quad(\text{masked, since }j=2>i=1)$$
$$\text{score}(1,3)=-\infty \quad(\text{masked, since }j=3>i=1)$$

**Applying softmax:**

$$e^{0.7071}\approx2.0281, \qquad e^{-\infty}=0, \qquad e^{-\infty}=0$$

Sum: $2.0281+0+0=2.0281$

$$\alpha_{1,1} = \frac{2.0281}{2.0281}=1.0 \qquad \alpha_{1,2}=0 \qquad \alpha_{1,3}=0$$

**The attention weight is exactly 1.0 on position 1 itself, and exactly 0 on everything else** — meaning $\mathbf{z}_1 = 1.0\times\mathbf{v}_1+0\times\mathbf{v}_2+0\times\mathbf{v}_3=\mathbf{v}_1$ exactly. This makes complete sense: the very first token in a sequence has no prior context whatsoever to draw on, so under a strictly causal (left-to-right) constraint, its representation can only be based on itself.

**By contrast, let's verify position $i=3$ (the last position) is UNAFFECTED by masking**, since $j\leq3$ includes all of $j=1,2,3$ — nothing gets masked for the very last position in the sequence, since everything else already comes before it. This means the LAST token in a sequence gets to attend to the FULL context (every earlier token) — exactly as we'd want, since predicting what comes after the last token should be informed by everything that's come before.

### 14.3.4 Why This Masking Pattern Is Called "GPT-style" or "Decoder-only"

The original Transformer paper (Section 13's "Attention Is All You Need") actually proposed an encoder-decoder architecture (recall File 3, Section 10.7's brief mention) with TWO different attention patterns: the "encoder" used unmasked (full, bidirectional) self-attention, appropriate for processing a complete, already-available input (like a full sentence to be translated). The "decoder" used the causal masking scheme just derived, appropriate for GENERATING output one token at a time. 

**GPT specifically uses ONLY the decoder-style, causally-masked component** — it discards the encoder entirely, and stacks many decoder-style (causally-masked self-attention + feedforward) blocks on top of each other. This is why GPT-style models are often described as **"decoder-only" Transformers** — they use exactly the architecture from Step 13, with the one crucial modification of causal masking applied to every self-attention layer throughout the entire stack.

## 14.4 From Final Representations to Next-Token Probabilities

After a token's vector has passed through all $N$ stacked Transformer blocks (Section 13.8), accumulating rich contextual information from every preceding token (subject to the causal masking constraint), we need to convert this final vector into an actual probability distribution over the ENTIRE vocabulary, for predicting the next token.

### 14.4.1 The Language Modeling Head

This final step uses one more learned weight matrix, commonly called the **language modeling head** (or "unembedding matrix"), which projects from the model's internal dimension $d$ back UP to the full vocabulary size $V$:

$$\text{logits} = W_{\text{head}}\,\mathbf{h}_{\text{final}}$$

where $W_{\text{head}}$ has shape $V \times d$ (recall the analogous shape discussion from File 1, Section 3.4.1 — this is structurally identical to any other weight matrix producing an output of a specific desired size), and $\mathbf{h}_{\text{final}}$ is the final Transformer block's output vector for the CURRENT (most recent) token position.

Then, exactly as derived in File 1, Section 4.4.6, and reiterated with a full worked example in File 2, Section 5.5.6:

$$P(\text{next token} = w) = \text{softmax}(\text{logits})_w = \frac{e^{\text{logit}_w}}{\sum_{w'=1}^{V}e^{\text{logit}_{w'}}}$$

**This is precisely the same softmax computation you've already fully worked through numerically in earlier files** — the entire elaborate architecture built up across Files 1 through this point (neurons, activations, embeddings, attention, residuals, normalization, causal masking) exists FOR THE SOLE PURPOSE of producing an increasingly sophisticated, deeply-contextualized final vector $\mathbf{h}_{\text{final}}$, which then gets converted, via this one final linear projection plus softmax, into next-token probabilities — the exact mechanism underlying every single token generated by GPT, Claude, or any other autoregressive LLM.

### 14.4.2 An Important Efficiency Note — Weight Tying

Many GPT-style implementations use a clever trick called **weight tying**: they reuse the SAME weight matrix for both the input embedding lookup (Step 9's embedding matrix $E$, shape $V\times d$) and this output language modeling head (shape $V\times d$, or its transpose $d\times V$, used identically) — i.e., $W_{\text{head}} = E^T$. This is motivated by an intuitive symmetry: the embedding matrix's row for "cat" represents "what does the token 'cat' mean, as an input," while the same row, reused in the output head, effectively asks "how much does this final contextual vector look like the concept 'cat', to determine if 'cat' should be predicted as the output." This trick roughly halves the total number of parameters devoted to vocabulary-related weights (a substantial savings, since $V$ is typically very large — tens of thousands to hundreds of thousands), while empirically maintaining, or even sometimes improving, model quality.

## 14.5 The Complete GPT Forward Pass, End to End — Full Pipeline Summary

Let's assemble everything from Files 1 through this point into ONE complete, precise pipeline description, so you can see the full journey from raw text to next-token prediction:

**Step 1 — Tokenization** (which you've already studied in depth): raw text gets split into tokens using BPE or a similar scheme, each token mapped to an integer ID.

**Step 2 — Embedding lookup** (Step 9): each token ID is used to look up its corresponding row in the embedding matrix $E$, producing a $d$-dimensional vector per token.

**Step 3 — Add positional encoding** (Section 13.4): a position-dependent vector is added to each token's embedding, injecting order information that attention alone cannot provide.

**Step 4 — Pass through $N$ stacked Transformer blocks** (Section 13.8), where EACH block performs:
   - Layer normalization, then causally-masked multi-head self-attention (Section 14.3), then a residual connection
   - Layer normalization, then a position-wise feedforward network (Section 13.7), then a residual connection

**Step 5 — Final layer normalization** (a standard additional layer norm applied after the very last Transformer block, before the language modeling head, for additional training stability).

**Step 6 — Language modeling head + softmax** (Section 14.4): project the final vector (for the most recent token position) to vocabulary-sized logits, then apply softmax to get next-token probabilities.

**Step 7 — Sampling** (a topic you've already studied in depth — greedy decoding, temperature sampling, top-k, top-p/nucleus sampling): select the actual next token from this probability distribution, using whichever sampling strategy is configured.

**Step 8 — Repeat**: append the newly generated token to the sequence, and go back to Step 2 (or, in an efficient real implementation, reuse cached computations via the KV-cache mechanism you've already studied, rather than recomputing everything from scratch) to generate the NEXT token, continuing until a stop condition is reached (e.g., generating an end-of-sequence token, or hitting a maximum length).

## 14.6 Model Scale — What Actually Changes as GPT Models Get Bigger

Since you're interested in eventually building small language models yourself, it's worth being precise about exactly WHAT changes as you scale a GPT-style model from tiny (which you can train on your Mac) to enormous (which requires massive industrial compute clusters). Reassuringly, **the architecture itself (every equation in this file) stays IDENTICAL** — what changes are purely a handful of size-related hyperparameters:

| Hyperparameter | What it controls | Typical range across model sizes |
|---|---|---|
| $d$ (model/embedding dimension) | Size of each token's vector representation | 128 (tiny) to 12,000+ (largest) |
| $N$ (number of Transformer blocks/layers) | How many times the block from Section 13.8 is stacked | 4-12 (tiny) to 96+ (largest) |
| $h$ (number of attention heads) | How many parallel attention "perspectives" per layer (Section 12.6) | 4-8 (tiny) to 96+ (largest) |
| $d_{\text{ff}}$ (feedforward hidden dimension) | Size of the FFN block's internal hidden layer (Section 13.7) | typically $4d$ | 
| $V$ (vocabulary size) | Number of distinct tokens the tokenizer can produce | 5,000-10,000 (tiny/custom) to 100,000-200,000+ (production) |
| Context length (max sequence length) | How many previous tokens the model can attend to at once | a few hundred (tiny) to 100,000+ (largest modern models) |

**Every single mathematical formula in this file — attention, residuals, layer norm, the feedforward block, causal masking, the final softmax — applies identically regardless of where in this table your specific model sits.** This is precisely why the small GPT implementations you've already built (the character-level tiny GPT and the word-level GPT with your custom BPE tokenizer) are not "toy approximations" of real LLMs — they are **structurally identical, scaled-down instances of the exact same architecture** described in complete mathematical detail throughout this file. Everything from here forward (Steps 15-20: pretraining, fine-tuning, RLHF, modern variants, reasoning, agents) concerns HOW this architecture gets trained and used, not further changes to the core architecture itself.

---

# Summary Cheat Sheet

**Positional encoding** — injecting order information attention cannot provide on its own:

$$PE_{(pos,2m)}=\sin\left(\frac{pos}{10000^{2m/d}}\right) \qquad PE_{(pos,2m+1)}=\cos\left(\frac{pos}{10000^{2m/d}}\right)$$

**Residual connections** — preserving gradient flow through deep stacks via an identity pathway:

$$\mathbf{y}=\mathbf{x}+\text{Layer}(\mathbf{x}) \implies \frac{\partial\mathbf{y}}{\partial\mathbf{x}}=I+\frac{\partial\text{Layer}}{\partial\mathbf{x}}$$

**Layer normalization** — standardizing activations per-token for training stability:

$$y_k = \gamma\cdot\frac{x_k-\mu}{\sqrt{\sigma^2+\epsilon}}+\beta$$

**Complete Transformer block** (Pre-LN arrangement, used in GPT):

$$\mathbf{x}'=\mathbf{x}+\text{MultiHeadAttention}(\text{LayerNorm}(\mathbf{x})) \qquad \mathbf{x}''=\mathbf{x}'+\text{FFN}(\text{LayerNorm}(\mathbf{x}'))$$

**Causal masking** — the one modification that turns a Transformer into an autoregressive language model:

$$\text{score}(i,j)=-\infty \text{ if } j>i, \text{ else } \frac{\mathbf{q}_i\cdot\mathbf{k}_j}{\sqrt{d_k}}$$

**GPT** = embedding + positional encoding → $N$× (causally-masked multi-head attention + FFN, both with residuals and layer norm) → final layer norm → language modeling head → softmax → sample next token → repeat.

---

# Self-Test Questions

1. Prove, using the commutativity of addition, why plain self-attention cannot distinguish "the dog bit the man" from "the man bit the dog" without positional encoding.
2. Using the clock-hands analogy, explain why positional encoding uses MULTIPLE frequencies rather than a single sine wave.
3. Compute the positional encoding vector for position 3, using the same $d=4$ setup as Section 13.4.3, showing every step.
4. Derive, from the chain rule, why a residual connection's gradient includes an identity term, and explain numerically (using your own chosen small local-gradient value) why this prevents vanishing gradients.
5. Explain the key difference between layer normalization and batch normalization, and why layer normalization is preferred for sequence models.
6. Redo the layer normalization worked example (Section 13.6.3) using the vector $[4,4,4,4]$, and explain what happens to the variance and why (this is a good edge case to reason through).
7. Explain, in your own words, the conceptual difference between what the attention sub-layer does and what the feedforward sub-layer does, within one Transformer block.
8. Using the softmax formula, explain precisely why setting a masked attention score to $-\infty$ (rather than just a very negative number) guarantees an attention weight of EXACTLY 0.
9. Explain why GPT is called "decoder-only," and what specifically was removed/kept from the original encoder-decoder Transformer architecture.
10. List all 6 hyperparameters from the model-scale table (Section 14.6) from memory, and explain in one sentence each what happens to the model's capability/computation as each one increases.

---

*End of File 5. File 6 will cover: Pretraining and Fine-tuning (Steps 15-16) — precisely how the billions of tokens of training text actually get turned into a trained GPT model via the loss functions and optimization techniques from File 2, and then how a "raw" pretrained model gets adapted into something that behaves like a helpful assistant.*

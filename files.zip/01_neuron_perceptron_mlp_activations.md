# File 1 of 20: The Building Blocks
## Neuron → Perceptron → MLP → Activation Functions

> **How to read this file**: Every concept is explained four times, in increasing depth: (1) an everyday analogy, (2) a technology/software analogy, (3) the full mathematics, worked step by step with no skipped algebra, (4) a fully worked numerical example you could reproduce by hand with a calculator. If you only have time to read one pass, read pass 3 and 4 — but pass 1 and 2 are what make the math *stick* in your head permanently.

---

# Table of Contents

1. [Why We Start Here](#why-we-start-here)
2. [Step 1: The Neuron](#step-1-the-neuron)
3. [Step 2: The Perceptron](#step-2-the-perceptron)
4. [Step 3: The Multi-Layer Perceptron (MLP)](#step-3-the-multi-layer-perceptron-mlp)
5. [Step 4: Activation Functions](#step-4-activation-functions)
6. [Summary Cheat Sheet](#summary-cheat-sheet)
7. [Self-Test Questions](#self-test-questions)

---

# Why We Start Here

Every large language model — GPT, Claude, Llama, Qwen — no matter how many billions of parameters it has, is built out of exactly one repeated Lego brick: **weighted sums passed through non-linear functions.** That's it. There is no other secret ingredient.

If you deeply understand this one file, you will understand the *atom* of every neural network that will ever exist. Everything else in this 20-file series — attention, transformers, GPT, RLHF — is just this same atom, arranged in increasingly clever patterns, at increasingly large scale.

So we go slow here. Painfully slow. Because rushing this file is the single most common reason people "learn" deep learning without ever actually understanding it.

---

# Step 1: The Neuron

### Main Question: *How does a neuron compute something?*

## 1.1 The Everyday Analogy

Imagine you're a 10th grader deciding: **"Should I go outside and play cricket today?"**

You don't make this decision randomly. You subconsciously weigh a few factors:

- Is it sunny? 
- Is my homework done?
- Are my friends free to play?

But here's the important part: **you don't weigh these factors equally**. Maybe you care *a lot* about whether your friends are free (if they're not free, what's the point?), you care *somewhat* about the weather, and you care *a little* about homework (you can always finish it later, but you feel a bit guilty).

So your brain (informally) does something like this:

```
importance_of_sun × (is it sunny?) 
+ importance_of_homework × (is homework done?) 
+ importance_of_friends × (are friends free?)
+ your_general_mood_today
= "urge to go play" score
```

If that score is high enough, you go outside. If not, you stay in. 

**This weighted-scoring-then-decide process is precisely what a single artificial neuron does.** Nothing more mystical is happening inside a neural network's smallest unit than this.

## 1.2 The Tech Analogy

If you've ever seen a spam filter, a credit score calculator, or a "should I recommend this video to this user" system, you've seen this exact structure, just with different words attached.

Consider a **simplified email spam scorer**:

```python
spam_score = (0.8 * contains_the_word_free) 
           + (0.6 * has_suspicious_link) 
           + (0.3 * many_exclamation_marks) 
           + (-0.4 * is_from_known_contact)
           + baseline_bias

if spam_score > threshold:
    mark_as_spam()
```

Notice:
- Each "feature" of the email (contains "free", has a suspicious link, etc.) is multiplied by a **weight** representing how important that feature is for detecting spam.
- These weighted features are **summed**.
- A **baseline bias** term is added (maybe most incoming mail defaults to "probably not spam," so bias starts negative).
- The final number decides the outcome.

A neuron is the *mathematical generalization* of this pattern — and critically, in a real neural network, **the weights (0.8, 0.6, 0.3, -0.4) are not hand-picked by an engineer. They are learned automatically from thousands of labeled examples of spam and non-spam emails.** That's what training a model means, and we will build up to exactly how that learning happens (Steps 5, 6, 7).

## 1.3 The Full Mathematics — Step by Step, No Skipping

### 1.3.1 Setting Up the Notation

A neuron receives a set of numerical inputs. Let's call them:

$$x_1, x_2, x_3, \dots, x_n$$

We can also write this as a **vector** (just a list of numbers, arranged in a column):

$$\mathbf{x} = \begin{bmatrix} x_1 \\ x_2 \\ x_3 \\ \vdots \\ x_n \end{bmatrix}$$

Each input $x_i$ has a corresponding **weight** $w_i$, representing how important that input is:

$$\mathbf{w} = \begin{bmatrix} w_1 \\ w_2 \\ w_3 \\ \vdots \\ w_n \end{bmatrix}$$

There is also one extra number, the **bias**, written $b$. Think of the bias as the neuron's "baseline tendency" — how eager or reluctant it is to activate, *regardless* of the inputs. (In our cricket example, this was "your general mood today.")

### 1.3.2 The Weighted Sum (Pre-Activation)

The neuron's first computation is to multiply each input by its corresponding weight, and add them all up, plus the bias. We call this raw, unprocessed result $z$ (the "pre-activation," because we haven't applied the activation function yet — that comes in Step 4):

$$z = w_1 x_1 + w_2 x_2 + w_3 x_3 + \dots + w_n x_n + b$$

Using summation notation (a compact way to write "add up a bunch of terms"):

$$z = \sum_{i=1}^{n} w_i x_i + b$$

**Reading this notation aloud**: "$z$ equals the sum, as $i$ goes from 1 to $n$, of $w_i$ times $x_i$, plus $b$." 

The $\sum$ symbol (capital Greek sigma) just means "add up everything that follows, for each value of $i$ from 1 up to $n$." If $n=3$:

$$\sum_{i=1}^{3} w_i x_i = w_1 x_1 + w_2 x_2 + w_3 x_3$$

### 1.3.3 Vector (Dot Product) Notation

There's an even more compact way to write this, using the **dot product** of two vectors. If $\mathbf{w} = [w_1, w_2, \dots, w_n]$ and $\mathbf{x} = [x_1, x_2, \dots, x_n]$, their dot product is defined as:

$$\mathbf{w} \cdot \mathbf{x} = \sum_{i=1}^{n} w_i x_i$$

So we can write the neuron's computation as:

$$z = \mathbf{w} \cdot \mathbf{x} + b$$

**Why does this notation matter?** Because when we get to real neural networks with millions of neurons, writing out every single term with a $\sum$ symbol would be unreadable. Vector/matrix notation lets us describe an entire layer of thousands of neurons in one short line (we'll do exactly this in Step 3). Getting comfortable with dot products now saves enormous pain later.

### 1.3.4 What Happens After $z$?

In a real neuron, $z$ is not the final output. We pass $z$ through an **activation function**, denoted $f$, to get the neuron's actual output $a$ (short for "activation"):

$$a = f(z)$$

We are deliberately **not** explaining what $f$ is yet — that is the entire subject of Step 4, and it deserves its own full treatment. For Steps 1-3, wherever you see $f(z)$, you can mentally substitute the simplest possible activation function: the **step function**, which just checks "is $z$ positive or not":

$$f(z) = \begin{cases} 1 & \text{if } z \geq 0 \\ 0 & \text{if } z < 0 \end{cases}$$

## 1.4 Fully Worked Numerical Example

Let's return to the cricket-playing neuron and put in real numbers.

**Setup:**
- $x_1 = 1$ (it IS sunny today; we encode "yes" as 1, "no" as 0)
- $x_2 = 1$ (homework IS done)
- $x_3 = 0$ (friends are NOT free today)

**Weights** (how much you personally care about each factor — these would normally be learned, but let's say we already know them for this example):
- $w_1 = 0.5$ (you care a moderate amount about sun)
- $w_2 = 0.3$ (you care a little about homework being done)
- $w_3 = 0.6$ (you care the most about friends being free)

**Bias:**
- $b = -0.7$ (you have a mild general reluctance to go outside unless things line up)

**Step-by-step computation of $z$:**

$$z = w_1 x_1 + w_2 x_2 + w_3 x_3 + b$$

Substitute the numbers:

$$z = (0.5)(1) + (0.3)(1) + (0.6)(0) + (-0.7)$$

Compute each multiplication one at a time:

$$(0.5)(1) = 0.5$$
$$(0.3)(1) = 0.3$$
$$(0.6)(0) = 0$$

Now add them all up, including the bias:

$$z = 0.5 + 0.3 + 0 + (-0.7)$$
$$z = 0.8 - 0.7$$
$$z = 0.1$$

**Applying the step activation function:**

$$f(z) = f(0.1)$$

Since $0.1 \geq 0$:

$$a = f(0.1) = 1$$

**Interpretation**: The neuron outputs 1, meaning "yes, go play cricket." Notice that even though your friends aren't free (which mattered *most* to you, weight 0.6), the combination of sun + finished homework was *just barely* enough to tip you over the threshold (final score 0.1, just above the cutoff of 0). If your bias had been slightly more negative — say $b = -0.9$ — you'd have gotten $z = -0.1$, and the decision would flip to "stay home." 

**This sensitivity is the whole point of having weights and biases as *tunable numbers*** — small changes in these numbers can change the final decision, and training a network means *searching* for the specific weight and bias values that make the network's decisions match reality as closely as possible, across thousands or millions of examples.

## 1.5 A Second Worked Example (Different Domain — to Prove This Isn't Just About Cricket)

Let's do a **medical diagnosis toy example** (heavily simplified — this is NOT how real diagnosis is done, just to show the neuron's math applies universally).

Suppose a doctor's assistant tool scores "risk of flu" based on:
- $x_1 = $ body temperature above 100°F? (1 = yes, 0 = no) → currently $x_1 = 1$
- $x_2 = $ sore throat present? (1 = yes, 0 = no) → currently $x_2 = 1$
- $x_3 = $ recent flu vaccine? (1 = yes, 0 = no) → currently $x_3 = 1$ (patient WAS vaccinated)

Weights:
- $w_1 = 0.9$ (fever is a strong flu indicator)
- $w_2 = 0.4$ (sore throat is a weaker, more general indicator)
- $w_3 = -0.7$ (vaccination REDUCES flu likelihood — hence the negative weight!)

Bias: $b = -0.5$ (baseline: without other symptoms, assume low risk)

**Computing $z$:**

$$z = (0.9)(1) + (0.4)(1) + (-0.7)(1) + (-0.5)$$
$$z = 0.9 + 0.4 - 0.7 - 0.5$$

Let's add these left to right, carefully:

$$0.9 + 0.4 = 1.3$$
$$1.3 - 0.7 = 0.6$$
$$0.6 - 0.5 = 0.1$$

$$z = 0.1$$

Since $z \geq 0$: $a = f(0.1) = 1$ → "flag as possible flu risk despite vaccination, due to strong symptom presence."

**Key takeaway from this second example**: Notice how a **negative weight** ($w_3 = -0.7$) allows the neuron to model inputs that *decrease* the likelihood of the outcome. This is important — weights are not just "how much do I care," they also encode *direction* (does this input push the decision up or down?). This will matter enormously once we discuss learned weights in real networks — a network might learn a strongly negative weight connecting "this pixel is black" to "this image is a cat," if black pixels in that position are unusual for cats.

## 1.6 What a Single Neuron *Cannot* Do (Preview of Step 2's Problem)

A single neuron, no matter how you tune its weights and bias, can only separate its inputs using **one straight line** (or in higher dimensions, one "flat" hyperplane). Some patterns in data simply cannot be captured by a single straight-line cut — we will see this precisely and mathematically in Step 2, when we discuss the XOR problem. This limitation is *exactly* why real neural networks stack many neurons into layers (Step 3).

---

# Step 2: The Perceptron

### Main Question: *How can neurons make decisions?*

## 2.1 The Everyday Analogy

The perceptron, invented by Frank Rosenblatt in 1958, is the neuron from Step 1, but used specifically to make a **hard binary decision** — yes or no, 1 or 0, admit or reject.

Think of a **strict bouncer at a club entrance**. The bouncer doesn't say "you're 73% likely to be let in." The bouncer makes a hard call: **in, or not in.** He looks at your age, your outfit, whether you're on the guest list, weighs each factor by how strict the club is about it, and gives a final yes/no.

The historically important twist that Rosenblatt added: **the bouncer can learn from his mistakes.** If he turns away someone who should've been let in (a VIP he didn't recognize), he adjusts how he weighs the factors next time, so he's less likely to make that mistake again. This automatic self-correction is the **perceptron learning rule**, and it was one of the very first "machine learning" algorithms ever created.

## 2.2 The Tech Analogy

A perceptron is like a **learned if-else statement**.

A traditional programmer might hand-write:

```python
def allow_entry(age, has_id, on_guest_list):
    if age >= 21 and has_id and on_guest_list:
        return True
    else:
        return False
```

This is rigid — a human decided the exact rule. A perceptron instead **learns the equivalent decision boundary from labeled examples** of "people who were let in" vs. "people who were turned away," without a human ever writing the explicit rule. This is the fundamental shift from traditional programming to machine learning: **instead of writing the rules, you show examples, and the algorithm discovers the rules.**

## 2.3 The Full Mathematics — Step by Step

### 2.3.1 The Perceptron's Computation

The perceptron computes the exact same pre-activation as our Step 1 neuron:

$$z = \mathbf{w} \cdot \mathbf{x} + b = \sum_{i=1}^{n} w_i x_i + b$$

Then it applies the **step function** (also called the **Heaviside step function**) as its activation:

$$
\hat{y} = f(z) = \begin{cases} 
1 & \text{if } z \geq 0 \\
0 & \text{if } z < 0
\end{cases}
$$

We write $\hat{y}$ (pronounced "y-hat") to mean "the model's *predicted* output," as opposed to $y$, which we reserve for the *true, correct* answer from our training data. This distinction between $\hat{y}$ and $y$ will be used constantly for the rest of this entire 20-file series, so lock it in now:

- $y$ = the ground truth / correct label (given to us in the training data)
- $\hat{y}$ = what the model currently predicts (which may be wrong, especially early in training)

### 2.3.2 The Perceptron Learning Rule — Derived Step by Step

This is the historically crucial part: **how does the perceptron improve its own weights?**

For each training example, we have an input $\mathbf{x}$ and its true label $y$. The perceptron computes its current prediction $\hat{y}$ using its current weights. We then compute the **error**:

$$e = y - \hat{y}$$

Let's think through every possible value $e$ can take, since both $y$ and $\hat{y}$ are either 0 or 1:

| $y$ (true) | $\hat{y}$ (predicted) | $e = y - \hat{y}$ | Meaning |
|---|---|---|---|
| 1 | 1 | 0 | Correct — no update needed |
| 0 | 0 | 0 | Correct — no update needed |
| 1 | 0 | +1 | Model was too strict — under-predicted |
| 0 | 1 | -1 | Model was too lenient — over-predicted |

Now, the **update rule** for every weight $w_i$ is:

$$w_i \leftarrow w_i + \eta \cdot e \cdot x_i$$

and for the bias:

$$b \leftarrow b + \eta \cdot e$$

Where:
- $\leftarrow$ means "gets updated to" (the new value replaces the old value)
- $\eta$ (Greek letter "eta") is the **learning rate**, a small positive number (commonly something like 0.01, 0.1, or in our simplified examples, 1) that controls **how big a step** we take when correcting the weights. We'll dedicate significant space to learning rate in Step 6 (Gradient Descent) because getting this number right/wrong is one of the most common practical issues in training any neural network.

### 2.3.3 Why Does This Update Rule Make Sense? (The Intuition Behind the Formula)

Let's reason through *why* $w_i \leftarrow w_i + \eta \cdot e \cdot x_i$ is a sensible correction, rather than just accepting it as a magic formula.

**Case A: Model under-predicted ($e = +1$).** This means the true answer was 1, but the model said 0 — the model wasn't "excited enough" by this input to cross the threshold. To fix this, we want to **increase** $z$ next time a similar input appears, so the model is more likely to cross the threshold and output 1.

Look at the update: $w_i \leftarrow w_i + \eta \cdot (+1) \cdot x_i$. 

- If $x_i = 1$ (this feature was "on" / present in this example): the weight increases. This makes sense — this input contributed to $z$, and we want $z$ to be bigger next time, so we amplify how much this input counts.
- If $x_i = 0$ (this feature was "off"): the weight doesn't change at all, since $\eta \cdot 1 \cdot 0 = 0$. This also makes sense — if a feature wasn't even present, adjusting its weight wouldn't have changed anything about *this specific* example, so there's no information telling us to change it.

**Case B: Model over-predicted ($e = -1$).** True answer was 0, model said 1 — the model was "too excitable." We want to **decrease** $z$ next time. The update becomes $w_i \leftarrow w_i + \eta \cdot (-1) \cdot x_i$, which *decreases* weights for whichever inputs were "on" — exactly the opposite correction, for exactly the same reason.

**Case C: Correct prediction ($e = 0$).** No update at all — if it isn't broken, don't fix it.

This elegant self-correcting behavior, discovered in 1958, is a direct ancestor of the gradient descent algorithm we'll formalize mathematically in Step 6. In fact, you can show the perceptron rule is a special case of gradient descent on a particular loss function — but we're getting ahead of ourselves; that connection will make much more sense once you've read Steps 5 and 6.

## 2.4 Fully Worked Example: Teaching a Perceptron the AND Gate

Let's teach a perceptron to replicate the **AND logic gate** — a fundamental building block in every computer chip. AND outputs 1 only when *both* inputs are 1.

**Truth table (our training data):**

| $x_1$ | $x_2$ | $y$ (true AND output) |
|---|---|---|
| 0 | 0 | 0 |
| 0 | 1 | 0 |
| 1 | 0 | 0 |
| 1 | 1 | 1 |

**Initialization:** We start with all weights and bias at zero (a common, simple starting point): $w_1 = 0$, $w_2 = 0$, $b = 0$. Learning rate $\eta = 1$ (chosen large here just to make the numbers clean for hand computation; in practice $\eta$ is usually much smaller, like 0.01).

We will go through the training data **example by example**, updating weights whenever the prediction is wrong. This full pass through all training examples once is called one **epoch** — a term you'll see constantly in later files.

### Epoch 1

**Example 1: $x_1=0, x_2=0$, true $y=0$**

$$z = (0)(0) + (0)(0) + 0 = 0$$

Since $z \geq 0$: $\hat{y} = 1$

But true $y = 0$. Error: $e = 0 - 1 = -1$.

Update weights:
$$w_1 \leftarrow 0 + (1)(-1)(0) = 0 + 0 = 0$$
$$w_2 \leftarrow 0 + (1)(-1)(0) = 0 + 0 = 0$$
$$b \leftarrow 0 + (1)(-1) = -1$$

New state: $w_1 = 0, w_2 = 0, b = -1$

**Example 2: $x_1=0, x_2=1$, true $y=0$**

$$z = (0)(0) + (0)(1) + (-1) = -1$$

Since $z < 0$: $\hat{y} = 0$. Matches true $y=0$. Error $e=0$. **No update.**

**Example 3: $x_1=1, x_2=0$, true $y=0$**

$$z = (0)(1) + (0)(0) + (-1) = -1$$

$\hat{y} = 0$, matches truth. No update.

**Example 4: $x_1=1, x_2=1$, true $y=1$**

$$z = (0)(1) + (0)(1) + (-1) = -1$$

Since $z < 0$: $\hat{y} = 0$. But true $y=1$. Error $e = 1 - 0 = 1$.

Update:
$$w_1 \leftarrow 0 + (1)(1)(1) = 1$$
$$w_2 \leftarrow 0 + (1)(1)(1) = 1$$
$$b \leftarrow -1 + (1)(1) = 0$$

New state after Epoch 1: $w_1 = 1, w_2 = 1, b = 0$

### Epoch 2 (using updated weights $w_1=1, w_2=1, b=0$)

**Example 1: $x_1=0, x_2=0$, true $y=0$**

$$z = (1)(0)+(1)(0)+0 = 0$$

Since $z \geq 0$: $\hat{y}=1$. True $y=0$. Error $e=-1$.

Update:
$$w_1 \leftarrow 1 + (1)(-1)(0) = 1$$
$$w_2 \leftarrow 1 + (1)(-1)(0) = 1$$
$$b \leftarrow 0 + (1)(-1) = -1$$

New state: $w_1=1, w_2=1, b=-1$

**Example 2: $x_1=0, x_2=1$, true $y=0$**

$$z = (1)(0)+(1)(1)+(-1) = 0$$

Since $z \geq 0$: $\hat{y}=1$. True $y=0$. Error $e=-1$.

Update:
$$w_1 \leftarrow 1 + (1)(-1)(0) = 1$$
$$w_2 \leftarrow 1 + (1)(-1)(1) = 1 - 1 = 0$$
$$b \leftarrow -1 + (1)(-1) = -2$$

New state: $w_1=1, w_2=0, b=-2$

**Example 3: $x_1=1, x_2=0$, true $y=0$**

$$z = (1)(1)+(0)(0)+(-2) = 1-2 = -1$$

$\hat{y}=0$, matches truth. No update.

**Example 4: $x_1=1, x_2=1$, true $y=1$**

$$z = (1)(1)+(0)(1)+(-2) = 1+0-2 = -1$$

$\hat{y}=0$. True $y=1$. Error $e=1$.

Update:
$$w_1 \leftarrow 1 + (1)(1)(1) = 2$$
$$w_2 \leftarrow 0 + (1)(1)(1) = 1$$
$$b \leftarrow -2 + (1)(1) = -1$$

New state after Epoch 2: $w_1=2, w_2=1, b=-1$

### Epoch 3 (using $w_1=2, w_2=1, b=-1$) — Let's Check All Four Examples

**Example 1: $(0,0)$, true $y=0$**
$$z = 0+0-1 = -1 \implies \hat{y}=0 ✓$$

**Example 2: $(0,1)$, true $y=0$**
$$z = 0+1-1 = 0 \implies \hat{y}=1 ✗$$ (still wrong!)

Error $e = 0-1=-1$. Update:
$$w_1 \leftarrow 2+(1)(-1)(0) = 2$$
$$w_2 \leftarrow 1+(1)(-1)(1) = 0$$
$$b \leftarrow -1+(1)(-1) = -2$$

New state: $w_1=2, w_2=0, b=-2$

**Example 3: $(1,0)$, true $y=0$**
$$z = 2(1)+0(0)-2 = 0 \implies \hat{y}=1 ✗$$

Error $e=-1$. Update:
$$w_1 \leftarrow 2+(1)(-1)(1) = 1$$
$$w_2 \leftarrow 0+(1)(-1)(0) = 0$$
$$b \leftarrow -2+(1)(-1) = -3$$

New state: $w_1=1, w_2=0, b=-3$

**Example 4: $(1,1)$, true $y=1$**
$$z = 1(1)+0(1)-3 = -2 \implies \hat{y}=0 ✗$$

Error $e=1$. Update:
$$w_1 \leftarrow 1+(1)(1)(1)=2$$
$$w_2 \leftarrow 0+(1)(1)(1)=1$$
$$b \leftarrow -3+(1)(1) = -2$$

New state after Epoch 3: $w_1=2, w_2=1, b=-2$

### Epoch 4 — Checking Convergence

Let's check all four with $w_1=2, w_2=1, b=-2$:

- $(0,0)$: $z = 0+0-2=-2 \implies \hat{y}=0$ ✓ (true 0)
- $(0,1)$: $z = 0+1-2=-1 \implies \hat{y}=0$ ✓ (true 0)
- $(1,0)$: $z = 2+0-2=0 \implies \hat{y}=1$ ✗ (true 0!)

Still one error. The algorithm would continue — this is normal; perceptron learning doesn't always converge in a perfectly smooth or fast way, and different random initializations or example orderings lead to different numbers of updates before convergence. If you continued this process (which I encourage you to do by hand, or in code, as an exercise), it eventually settles on weights like $w_1=1, w_2=1, b=-1.5$ (or any similar combination), which correctly classifies all four:

- $(0,0)$: $z=-1.5 \implies 0$ ✓
- $(0,1)$: $z=-0.5 \implies 0$ ✓
- $(1,0)$: $z=-0.5 \implies 0$ ✓
- $(1,1)$: $z=0.5 \implies 1$ ✓

**The Perceptron Convergence Theorem** (a real, proven mathematical result from 1962, by Novikoff): *if* the training data is linearly separable (can be split by a straight line/hyperplane), the perceptron learning algorithm is **guaranteed** to find a correct set of weights in a finite number of steps. This was a landmark theoretical result — a proof that a simple, local, iterative update rule provably converges to a correct answer.

## 2.5 The XOR Problem — Why Perceptrons Hit a Wall

Now let's try to teach a perceptron the **XOR** (exclusive OR) gate — outputs 1 only when the inputs are *different* from each other.

| $x_1$ | $x_2$ | XOR |
|---|---|---|
| 0 | 0 | 0 |
| 0 | 1 | 1 |
| 1 | 0 | 1 |
| 1 | 1 | 0 |

### 2.5.1 Why This Is Impossible for a Single Perceptron (Geometric Proof)

A perceptron's decision boundary — the line where $z = 0$ exactly, separating "predict 1" from "predict 0" — is defined by:

$$w_1 x_1 + w_2 x_2 + b = 0$$

This is the equation of a **straight line** in the $(x_1, x_2)$ plane (you may recognize this as similar to $y = mx + c$ from your algebra class, just rearranged and with different variable names).

If you plot the four XOR points:
- $(0,0) \to 0$
- $(1,1) \to 0$
- $(0,1) \to 1$
- $(1,0) \to 1$

The two "0" points are at opposite corners (bottom-left and top-right), and the two "1" points are at the *other* opposite corners (top-left and bottom-right) — like a checkerboard pattern. **No single straight line can separate one diagonal pair from the other diagonal pair.** Try drawing it yourself on paper: any line you draw will either have both 0s on one side and both 1s split across sides, or vice versa.

This is not a limitation of *training* — it's not that we haven't found the right weights yet. It is a **fundamental mathematical impossibility** for this model architecture. No values of $w_1, w_2, b$ exist that solve it, no matter how long you train.

### 2.5.2 A Formal Proof (Optional, for Rigor)

Suppose, for contradiction, that weights $w_1, w_2, b$ exist such that the perceptron correctly computes XOR. Then we'd need:

From $(0,0) \to 0$: $\quad w_1(0) + w_2(0) + b < 0 \implies b < 0$ 

From $(1,1) \to 0$: $\quad w_1(1) + w_2(1) + b < 0 \implies w_1 + w_2 + b < 0$ 

From $(0,1) \to 1$: $\quad w_1(0) + w_2(1) + b \geq 0 \implies w_2 + b \geq 0 \implies w_2 \geq -b$

From $(1,0) \to 1$: $\quad w_1(1) + w_2(0) + b \geq 0 \implies w_1 + b \geq 0 \implies w_1 \geq -b$

Adding the last two inequalities:

$$w_1 + w_2 \geq -2b$$

But from the second constraint, $w_1 + w_2 < -b$. Combining:

$$-2b \leq w_1 + w_2 < -b$$

$$\implies -2b < -b$$

$$\implies -2b + 2b < -b + 2b$$

$$\implies 0 < b$$

But our very first constraint said $b < 0$. We've derived $b < 0$ AND $0 < b$ simultaneously — a direct contradiction. **Therefore, no such weights exist.** This is a clean, complete proof — this is exactly the kind of reasoning that led to the famous 1969 Minsky-Papert result that significantly slowed AI research funding for over a decade (the first "AI Winter").

### 2.5.3 The Resolution (Preview of Step 3)

The fix, as we'll see in complete mathematical detail in Step 3, is to **stack multiple perceptron-like units into layers**. A single straight line can't separate XOR, but *two* lines, combined appropriately, absolutely can. This single insight — that depth (stacking layers) grants representational power that a single layer fundamentally cannot have — is the entire founding principle of "deep" learning.

---

# Step 3: The Multi-Layer Perceptron (MLP)

### Main Question: *How do many neurons form a network?*

## 3.1 The Everyday Analogy

A single perceptron is one person voting on a decision. But consider a **hiring committee** at a company:

- Person A looks only at technical skills and gives a score.
- Person B looks only at communication skills and gives a score.
- Person C looks only at cultural fit and gives a score.
- Finally, the **hiring manager** takes all three of their scores and makes the final call, weighing each committee member's opinion according to how much she trusts their judgment.

Notice the two-stage structure: first, three independent "specialist" evaluations happen in parallel (this is a **hidden layer**), and then those results get combined into one final decision (the **output layer**). Crucially, the hiring manager isn't looking at the original candidate's resume directly for her final decision — she's looking at the *transformed* information (three expert opinions) that the first layer produced. **This is exactly how an MLP works: each layer transforms the data into a new, more useful representation for the next layer to use.**

## 3.2 The Tech Analogy

Think about an **image recognition pipeline**, like the kind used in old-school (pre-deep-learning-mania, but still illustrative) computer vision, or conceptually how the layers of a CNN work (which we'll cover in a future file):

- **Layer 1** might detect simple edges and colors in an image.
- **Layer 2** combines those edges into simple shapes (circles, corners).
- **Layer 3** combines shapes into parts (an eye, a wheel, a leaf).
- **Final layer** combines parts into a full object classification ("this is a cat", "this is a car").

Each layer's output becomes the next layer's input, and each layer's job gets progressively more abstract and semantically meaningful. An MLP formalizes this idea in the most general possible way, using fully-connected layers of artificial neurons — and remarkably, the network **discovers** what each layer should detect purely from data, without a human ever specifying "detect edges here."

## 3.3 The Structure, Precisely Defined

An MLP consists of:

1. **Input layer**: not actually made of neurons that "compute" anything — it's just where your raw feature values $x_1, \dots, x_n$ enter the network.
2. **One or more hidden layers**: layers of neurons that are not directly observed as "input" or "output" — they compute intermediate representations. This is why they're called "hidden."
3. **Output layer**: produces the network's final prediction.

The key structural rule: in a "fully connected" or "dense" MLP, **every neuron in layer $\ell$ receives input from every single neuron's output in layer $\ell - 1$.**

## 3.4 The Full Mathematics — Step by Step

### 3.4.1 Why We Need Matrices Now

In Step 1, one neuron had one weight vector $\mathbf{w}$. But now, a *layer* might have, say, 4 neurons, each with its own complete weight vector. Instead of writing 4 separate equations, we stack all 4 weight vectors into a **matrix**.

Let's say our input has $n=3$ features, and our hidden layer has $h=4$ neurons.

Each of the 4 hidden neurons needs its own set of 3 weights (one per input feature) plus its own bias. Let's define:

- $w^{(1)}_{j,i}$ = the weight connecting input feature $i$ to hidden neuron $j$, in layer 1.
- $b^{(1)}_j$ = the bias of hidden neuron $j$ in layer 1.

The pre-activation of hidden neuron $j$ is:

$$z^{(1)}_j = \sum_{i=1}^{3} w^{(1)}_{j,i} \, x_i + b^{(1)}_j$$

We have 4 such equations (one for $j=1,2,3,4$). Writing all 4 out:

$$z^{(1)}_1 = w^{(1)}_{1,1}x_1 + w^{(1)}_{1,2}x_2 + w^{(1)}_{1,3}x_3 + b^{(1)}_1$$
$$z^{(1)}_2 = w^{(1)}_{2,1}x_1 + w^{(1)}_{2,2}x_2 + w^{(1)}_{2,3}x_3 + b^{(1)}_2$$
$$z^{(1)}_3 = w^{(1)}_{3,1}x_1 + w^{(1)}_{3,2}x_2 + w^{(1)}_{3,3}x_3 + b^{(1)}_3$$
$$z^{(1)}_4 = w^{(1)}_{4,1}x_1 + w^{(1)}_{4,2}x_2 + w^{(1)}_{4,3}x_3 + b^{(1)}_4$$

This is tedious to write and would be *unbearable* for a real network with, say, 512 neurons per layer. So we package all these weights into a matrix $W^{(1)}$, where row $j$ contains all the weights feeding into hidden neuron $j$:

$$W^{(1)} = \begin{bmatrix} w^{(1)}_{1,1} & w^{(1)}_{1,2} & w^{(1)}_{1,3} \\ w^{(1)}_{2,1} & w^{(1)}_{2,2} & w^{(1)}_{2,3} \\ w^{(1)}_{3,1} & w^{(1)}_{3,2} & w^{(1)}_{3,3} \\ w^{(1)}_{4,1} & w^{(1)}_{4,2} & w^{(1)}_{4,3} \end{bmatrix} \quad \text{(shape: } 4 \times 3 \text{, i.e., 4 rows, 3 columns)}$$

And our input as a column vector:

$$\mathbf{x} = \begin{bmatrix} x_1 \\ x_2 \\ x_3 \end{bmatrix} \quad \text{(shape: } 3 \times 1\text{)}$$

And bias as a column vector:

$$\mathbf{b}^{(1)} = \begin{bmatrix} b^{(1)}_1 \\ b^{(1)}_2 \\ b^{(1)}_3 \\ b^{(1)}_4 \end{bmatrix} \quad \text{(shape: } 4 \times 1\text{)}$$

### 3.4.2 Matrix-Vector Multiplication, Explained From Scratch

If you haven't done matrix multiplication before (or need a refresher), here's the rule: to multiply a matrix $W$ (shape $4 \times 3$) by a vector $\mathbf{x}$ (shape $3 \times 1$), you take the **dot product of each row of $W$ with $\mathbf{x}$**, and each of these dot products becomes one entry in the resulting vector.

$$W^{(1)} \mathbf{x} = \begin{bmatrix} w_{1,1}x_1 + w_{1,2}x_2 + w_{1,3}x_3 \\ w_{2,1}x_1 + w_{2,2}x_2 + w_{2,3}x_3 \\ w_{3,1}x_1 + w_{3,2}x_2 + w_{3,3}x_3 \\ w_{4,1}x_1 + w_{4,2}x_2 + w_{4,3}x_3 \end{bmatrix} \quad \text{(shape: } 4 \times 1\text{)}$$

Notice this result is *exactly* the 4 equations we wrote out longhand above (minus the bias, which we add next). This is why matrix notation exists: it's not new math, it's a compact bookkeeping system for doing many dot products at once.

**Dimension rule to memorize**: if $W$ has shape $(\text{rows} \times \text{cols})$ and you multiply it by a vector of shape $(\text{cols} \times 1)$, the result has shape $(\text{rows} \times 1)$. The "inner" dimensions (cols of $W$, and the length of $\mathbf{x}$) must match — this is non-negotiable in matrix multiplication, and mismatched dimensions are the single most common bug when implementing neural networks in code.

### 3.4.3 The Full Layer Equation

Now we can write the entire hidden layer's pre-activation computation in one line:

$$\mathbf{z}^{(1)} = W^{(1)} \mathbf{x} + \mathbf{b}^{(1)}$$

Then we apply the activation function **element-wise** (meaning: apply $f$ separately to each of the 4 numbers in the vector, independently):

$$\mathbf{a}^{(1)} = f(\mathbf{z}^{(1)})$$

This $\mathbf{a}^{(1)}$ (a vector of 4 numbers) is now the **input to the next layer** — whether that's another hidden layer, or the final output layer.

### 3.4.4 The Output Layer

If our output layer has, say, 1 neuron (for a yes/no decision), then $W^{(2)}$ has shape $1 \times 4$ (1 output neuron, 4 inputs coming from the hidden layer), and:

$$z^{(2)} = W^{(2)} \mathbf{a}^{(1)} + b^{(2)}$$
$$\hat{y} = f(z^{(2)})$$

### 3.4.5 The General Pattern (Any Number of Layers)

For a network with $L$ layers total, the pattern repeats identically at every layer $\ell$:

$$\mathbf{z}^{(\ell)} = W^{(\ell)} \mathbf{a}^{(\ell-1)} + \mathbf{b}^{(\ell)}$$
$$\mathbf{a}^{(\ell)} = f(\mathbf{z}^{(\ell)})$$

where $\mathbf{a}^{(0)} := \mathbf{x}$ (the input layer's "activation" is just defined to be the raw input itself, so the pattern is consistent from the very first layer). This recursive, layer-by-layer structure — pass the previous layer's output as the next layer's input — is called **forward propagation**, and it is exactly how information flows through *any* feedforward neural network, no matter how deep, including the very deepest LLMs. Everything from here to GPT is this exact loop, just with more layers, different connectivity patterns, and vastly more neurons.

## 3.5 Fully Worked Numerical Example: Solving XOR With an MLP

We proved in Step 2 that no single perceptron can solve XOR. Now, let's build a tiny MLP — 2 inputs, 2 hidden neurons, 1 output — and prove it *can* solve XOR, with every number computed by hand.

### 3.5.1 The Design Strategy

Here's the key algebraic identity we'll exploit:

$$\text{XOR}(x_1, x_2) = \text{OR}(x_1, x_2) \text{ AND } \text{NAND}(x_1, x_2)$$

(NAND means "NOT AND" — it outputs 1 unless both inputs are 1.)

Let's verify this identity holds for all four input combinations before we build the network, so we trust the design:

| $x_1$ | $x_2$ | OR | NAND | OR AND NAND | XOR (expected) |
|---|---|---|---|---|---|
| 0 | 0 | 0 | 1 | 0 | 0 ✓ |
| 0 | 1 | 1 | 1 | 1 | 1 ✓ |
| 1 | 0 | 1 | 1 | 1 | 1 ✓ |
| 1 | 1 | 1 | 0 | 0 | 0 ✓ |

Great, the identity checks out for all 4 cases. Now we design our hidden neurons:

- **Hidden neuron $h_1$** will compute OR.
- **Hidden neuron $h_2$** will compute NAND.
- **Output neuron** will compute AND of $h_1$ and $h_2$.

### 3.5.2 Designing the OR Neuron ($h_1$)

We want $z_1 \geq 0$ (fires) whenever at least one of $x_1, x_2$ is 1, and $z_1 < 0$ only when both are 0.

Try $w_{1,1} = 1$, $w_{1,2} = 1$, $b_1 = -0.5$:

$$z_1 = (1)x_1 + (1)x_2 - 0.5$$

Check all 4 cases:
- $(0,0)$: $z_1 = 0+0-0.5 = -0.5 < 0 \implies h_1 = 0$ ✓ (OR should be 0)
- $(0,1)$: $z_1 = 0+1-0.5 = 0.5 \geq 0 \implies h_1 = 1$ ✓
- $(1,0)$: $z_1 = 1+0-0.5 = 0.5 \geq 0 \implies h_1 = 1$ ✓
- $(1,1)$: $z_1 = 1+1-0.5 = 1.5 \geq 0 \implies h_1 = 1$ ✓

Confirmed: $h_1$ correctly implements OR.

### 3.5.3 Designing the NAND Neuron ($h_2$)

We want $z_2 \geq 0$ (fires) for every case *except* when both inputs are 1.

Try $w_{2,1} = -1$, $w_{2,2} = -1$, $b_2 = 1.5$:

$$z_2 = (-1)x_1 + (-1)x_2 + 1.5$$

Check all 4 cases:
- $(0,0)$: $z_2 = 0+0+1.5 = 1.5 \geq 0 \implies h_2=1$ ✓ (NAND should be 1)
- $(0,1)$: $z_2 = 0-1+1.5 = 0.5 \geq 0 \implies h_2=1$ ✓
- $(1,0)$: $z_2 = -1+0+1.5 = 0.5 \geq 0 \implies h_2=1$ ✓
- $(1,1)$: $z_2 = -1-1+1.5 = -0.5 < 0 \implies h_2=0$ ✓

Confirmed: $h_2$ correctly implements NAND.

### 3.5.4 Designing the Output Neuron (AND of $h_1, h_2$)

We want the output to fire only when *both* $h_1=1$ and $h_2=1$.

Try $w_{o,1} = 1$, $w_{o,2} = 1$, $b_o = -1.5$ (this is the exact same structure as a standard AND gate on two binary inputs, just now operating on $h_1, h_2$ instead of $x_1, x_2$):

$$z_o = (1)h_1 + (1)h_2 - 1.5$$

### 3.5.5 Full Forward Pass, All Four Inputs, Every Number Shown

**Input $(x_1, x_2) = (0, 0)$:**

$$z_1 = (1)(0) + (1)(0) - 0.5 = -0.5 \implies h_1 = 0$$
$$z_2 = (-1)(0) + (-1)(0) + 1.5 = 1.5 \implies h_2 = 1$$
$$z_o = (1)(0) + (1)(1) - 1.5 = 1 - 1.5 = -0.5 \implies \hat{y} = 0$$

Expected XOR(0,0) = 0. **Match ✓**

**Input $(x_1, x_2) = (0, 1)$:**

$$z_1 = (1)(0) + (1)(1) - 0.5 = 0.5 \implies h_1 = 1$$
$$z_2 = (-1)(0) + (-1)(1) + 1.5 = 0.5 \implies h_2 = 1$$
$$z_o = (1)(1) + (1)(1) - 1.5 = 2 - 1.5 = 0.5 \implies \hat{y} = 1$$

Expected XOR(0,1) = 1. **Match ✓**

**Input $(x_1, x_2) = (1, 0)$:**

$$z_1 = (1)(1) + (1)(0) - 0.5 = 0.5 \implies h_1 = 1$$
$$z_2 = (-1)(1) + (-1)(0) + 1.5 = 0.5 \implies h_2 = 1$$
$$z_o = (1)(1) + (1)(1) - 1.5 = 0.5 \implies \hat{y} = 1$$

Expected XOR(1,0) = 1. **Match ✓**

**Input $(x_1, x_2) = (1, 1)$:**

$$z_1 = (1)(1) + (1)(1) - 0.5 = 1.5 \implies h_1 = 1$$
$$z_2 = (-1)(1) + (-1)(1) + 1.5 = -0.5 \implies h_2 = 0$$
$$z_o = (1)(1) + (1)(0) - 1.5 = 1 - 1.5 = -0.5 \implies \hat{y} = 0$$

Expected XOR(1,1) = 0. **Match ✓**

**All four cases correct.** We have just hand-built and hand-verified a neural network that solves a problem a single perceptron mathematically cannot solve. This is not a toy fact — this is the literal historical resolution to the AI Winter caused by the XOR limitation. The addition of a **hidden layer** is what restored confidence that neural networks could be powerful function approximators, eventually leading (decades later, with more compute and better training algorithms) to the deep learning revolution.

### 3.5.6 The Geometric Intuition Behind Why This Worked

Here's the deeper "aha": the hidden layer doesn't just add more numbers — it **reshapes the problem's geometry**. 

In the original $(x_1, x_2)$ space, the XOR points are NOT linearly separable (Step 2 proved this). But once we compute $h_1 = \text{OR}(x_1,x_2)$ and $h_2=\text{NAND}(x_1,x_2)$ and plot the four inputs in the *new* $(h_1, h_2)$ space:

- $(0,0) \to (h_1,h_2) = (0,1)$
- $(0,1) \to (h_1,h_2) = (1,1)$
- $(1,0) \to (h_1,h_2) = (1,1)$
- $(1,1) \to (h_1,h_2) = (1,0)$

Now look: **two different original inputs, $(0,1)$ and $(1,0)$, both map to the exact same point $(1,1)$ in hidden space** — and in this new space, the "1" outputs are both at $(1,1)$, while "0" outputs are at $(0,1)$ and $(1,0)$. This IS now linearly separable! (e.g., the line "$h_1 + h_2 = 1.5$" separates them perfectly, which is exactly the output neuron we designed above).

**This is the single most important conceptual takeaway from this entire file**: *each layer's job is to transform the data into a new coordinate space where the next layer's job becomes easier (ideally, linearly separable).* Every layer in every deep network ever built — from this tiny XOR solver to GPT-4 — is doing a version of this same fundamental operation: reshaping representations to make the next step's job tractable.

## 3.6 A Note on Learning These Weights Automatically

In the example above, I designed the weights by hand, using logical reasoning about OR/NAND/AND. In practice, **no one hand-designs weights for real problems** — real networks have millions or billions of weights, far too many for humans to reason about individually. Instead, we initialize weights **randomly**, and then use **gradient descent** (Step 6) guided by **backpropagation** (Step 7) to automatically search for weight values that make the network's outputs match the training data. The XOR weights we found by hand are, in fact, very close to what gradient descent would discover automatically if you trained a 2-2-1 MLP on the XOR dataset — I encourage you to verify this yourself once we reach the coding portions of this series.

---

# Step 4: Activation Functions

### Main Question: *Why do we need non-linearity?*

## 4.1 The Everyday Analogy

Think about a home thermostat. A **purely linear** thermostat would behave like this: "for every 1 degree below my target temperature, I will increase heating output by exactly 1 unit — forever, with no limit, no matter how extreme." That's absurd behavior in reality — the thermostat can't heat infinitely, and there's no reason for the response to be a perfectly straight-line relationship across all possible temperatures.

A **real** thermostat has thresholds and non-proportional behavior: "if temperature is below 15°C, blast the heater at full power. Between 15-25°C, make small adjustments. Above 25°C, turn on the AC instead." This is a **non-linear** response — the relationship between "how far off the temperature is" and "what action to take" bends, saturates, and switches behavior at certain points, rather than being one unbending straight line.

Neural networks need this same capacity for bending, thresholding, and saturating responses, because the real-world patterns they're trying to learn (is this a cat? what's the next word? is this transaction fraud?) are governed by exactly this kind of complex, non-proportional logic — not simple straight-line relationships.

## 4.2 The Tech Analogy

Think of activation functions like **conditional logic (`if` statements) inserted between function calls** in a program. 

If every "function" in your program was of the form `output = a * input + b` (a pure linear scaling), then chaining together 100 of these functions would be mathematically equivalent to just ONE such function (we'll prove this rigorously below) — you'd have written 100 lines of code to achieve what 1 line could do. All that extra code would be pure waste.

But if you insert something like `output = max(0, a*input + b)` (a conditional clip) between each function call, now each additional function call **genuinely changes what's computationally reachable** — because clipping/branching operations cannot be "flattened" into a single linear step. The activation function is precisely this non-flattenable, genuinely-adds-power ingredient.

## 4.3 The Absolutely Critical Mathematical Proof: Why Linear Layers Alone Are Useless

This is, without exaggeration, one of the most important derivations in this entire file. If you only remember one piece of math from Steps 1-4, remember this.

### 4.3.1 Setting Up the Claim

**Claim**: If you stack multiple layers, but use NO non-linear activation function between them (i.e., $f(z) = z$, called the **identity function** or "linear activation"), then no matter how many layers you stack, the entire network is mathematically equivalent to a single layer.

### 4.3.2 The Proof, Step by Step

Consider a 2-layer network with **no** activation function (identity activation everywhere). 

Layer 1:
$$\mathbf{z}^{(1)} = W^{(1)} \mathbf{x} + \mathbf{b}^{(1)}$$

Since there's no activation function, $\mathbf{a}^{(1)} = \mathbf{z}^{(1)}$ directly (identity function just returns its input unchanged).

Layer 2:
$$\mathbf{z}^{(2)} = W^{(2)} \mathbf{a}^{(1)} + \mathbf{b}^{(2)}$$

Substitute $\mathbf{a}^{(1)} = W^{(1)}\mathbf{x} + \mathbf{b}^{(1)}$ into this equation:

$$\mathbf{z}^{(2)} = W^{(2)} \left( W^{(1)} \mathbf{x} + \mathbf{b}^{(1)} \right) + \mathbf{b}^{(2)}$$

Now we distribute $W^{(2)}$ across the parentheses (this is valid — matrix multiplication distributes over addition, just like regular multiplication distributes over addition: $a(b+c) = ab+ac$):

$$\mathbf{z}^{(2)} = W^{(2)} W^{(1)} \mathbf{x} + W^{(2)} \mathbf{b}^{(1)} + \mathbf{b}^{(2)}$$

Now here's the key move: define two NEW variables:

$$W' := W^{(2)} W^{(1)} \quad \text{(a new matrix, formed by multiplying the two weight matrices together)}$$
$$\mathbf{b}' := W^{(2)} \mathbf{b}^{(1)} + \mathbf{b}^{(2)} \quad \text{(a new bias vector)}$$

Then our two-layer computation simplifies to:

$$\mathbf{z}^{(2)} = W' \mathbf{x} + \mathbf{b}'$$

**Look closely at this equation.** This has EXACTLY the same form as a single-layer computation from Step 1/3 — one weight matrix, multiplied by the input, plus one bias vector. There is no trace remaining of the fact that we "used" two layers. Any two-layer linear network can be replaced by an equivalent single-layer network with weights $W'$ and bias $\mathbf{b}'$, and it will produce **identical outputs for every possible input**, forever.

### 4.3.3 Generalizing to Any Number of Layers

This argument doesn't stop at 2 layers. By induction, if you have $L$ layers, all linear:

$$\mathbf{z}^{(L)} = W^{(L)} \left( W^{(L-1)} \left( \cdots \left( W^{(1)}\mathbf{x} + \mathbf{b}^{(1)} \right) \cdots \right) + \mathbf{b}^{(L-1)} \right) + \mathbf{b}^{(L)}$$

fully expands (through repeated distribution, exactly as shown above) into:

$$\mathbf{z}^{(L)} = \left( W^{(L)} W^{(L-1)} \cdots W^{(1)} \right) \mathbf{x} + \left( \text{some combination of all the biases} \right)$$

which again has the form $W'' \mathbf{x} + \mathbf{b}''$ — **a single effective linear layer**, regardless of whether $L = 2$ or $L = 1{,}000{,}000$.

### 4.3.4 The Devastating Practical Consequence

This means: **a 1000-layer neural network with no activation functions has exactly the same representational power as a single-layer network.** All that extra depth, all those extra parameters, all that extra computation — completely wasted, mathematically provably so. It could never solve XOR (Step 2's impossibility proof would apply equally to this "fake-deep" linear network, since it's secretly just one linear layer in disguise).

This is *precisely* why every practical neural network inserts a non-linear activation function between (almost) every layer. **The activation function is not a minor implementation detail — it is the single ingredient that makes "deep" mean anything at all.** Without it, depth is an illusion.

## 4.4 Common Activation Functions — Full Mathematical Treatment

### 4.4.1 Sigmoid

**Formula:**
$$\sigma(z) = \frac{1}{1 + e^{-z}}$$

Here $e \approx 2.71828$ is Euler's number, the base of the natural logarithm — you may already know it from compound interest formulas or exponential growth/decay problems in your math class.

**Range**: Output is always strictly between 0 and 1, never quite reaching either endpoint. This makes sigmoid natural for representing *probabilities*.

**Let's compute a few values by hand:**

At $z=0$:
$$\sigma(0) = \frac{1}{1+e^{0}} = \frac{1}{1+1} = \frac{1}{2} = 0.5$$

At $z = 2$:
$$\sigma(2) = \frac{1}{1+e^{-2}}$$

We need $e^{-2} \approx 0.1353$.

$$\sigma(2) = \frac{1}{1+0.1353} = \frac{1}{1.1353} \approx 0.881$$

At $z = -2$ (by symmetry, this should be $1 - 0.881 = 0.119$; let's verify):

$$\sigma(-2) = \frac{1}{1+e^{2}} = \frac{1}{1+7.389} = \frac{1}{8.389} \approx 0.1192$$

Confirmed (small rounding difference is just from decimal precision).

**The derivative of sigmoid** (we need this for backpropagation in Step 7, so let's derive it now while we're focused on this function):

$$\sigma'(z) = \sigma(z)\big(1-\sigma(z)\big)$$

*(Derivation, for the mathematically curious: using the quotient rule on $\frac{1}{1+e^{-z}}$, or more elegantly, rewriting and differentiating $(1+e^{-z})^{-1}$ using the chain rule:)*

$$\frac{d}{dz}\left[(1+e^{-z})^{-1}\right] = -1 \cdot (1+e^{-z})^{-2} \cdot \frac{d}{dz}(1+e^{-z})$$

$$= -1 \cdot (1+e^{-z})^{-2} \cdot (-e^{-z})$$

$$= \frac{e^{-z}}{(1+e^{-z})^2}$$

Now, a clever algebraic trick: rewrite $e^{-z} = (1+e^{-z}) - 1$:

$$= \frac{(1+e^{-z}) - 1}{(1+e^{-z})^2} = \frac{1+e^{-z}}{(1+e^{-z})^2} - \frac{1}{(1+e^{-z})^2} = \frac{1}{1+e^{-z}} - \left(\frac{1}{1+e^{-z}}\right)^2$$

$$= \sigma(z) - \sigma(z)^2 = \sigma(z)\big(1 - \sigma(z)\big)$$

This clean result — that the derivative can be written purely in terms of the function's own output — is *why* sigmoid was historically popular: during backpropagation, once you've computed $\sigma(z)$ in the forward pass, you get its derivative almost for free.

**The critical problem — vanishing gradients:** Let's compute $\sigma'(z)$ at a few points:

- At $z=0$: $\sigma'(0) = 0.5 \times (1-0.5) = 0.5 \times 0.5 = 0.25$ (the maximum possible value of $\sigma'$)
- At $z=2$: $\sigma'(2) = 0.881 \times (1-0.881) = 0.881 \times 0.119 \approx 0.105$
- At $z=5$: $\sigma(5) \approx 0.9933$, so $\sigma'(5) \approx 0.9933 \times 0.0067 \approx 0.00665$
- At $z=10$: $\sigma(10) \approx 0.99995$, so $\sigma'(10) \approx 0.99995 \times 0.00005 \approx 0.00005$

Notice the derivative shrinks toward zero rapidly as $|z|$ grows large. This matters enormously for training deep networks: in backpropagation (Step 7), gradients get **multiplied together** across layers via the chain rule. If every layer's gradient is at most 0.25, and you have, say, 10 layers, the total gradient reaching the earliest layers is at most $0.25^{10} \approx 0.00000095$ — an almost imperceptibly tiny number. This means **early layers in a deep sigmoid network learn extremely slowly, or effectively not at all.** This is the **vanishing gradient problem**, and it's a primary historical reason sigmoid fell out of favor for hidden layers in deep networks (it's still used at output layers for binary classification, where its probability interpretation is exactly what's wanted).

### 4.4.2 Tanh (Hyperbolic Tangent)

**Formula:**
$$\tanh(z) = \frac{e^z - e^{-z}}{e^z+e^{-z}}$$

**Range**: $(-1, 1)$ — this is the key difference from sigmoid: tanh is **zero-centered** (outputs can be negative), whereas sigmoid is always positive. This matters in practice because zero-centered activations tend to make gradient-based optimization (Step 6) converge faster, since the average output isn't systematically biased toward one sign.

**Relationship to sigmoid** (useful to know): 

$$\tanh(z) = 2\sigma(2z) - 1$$

Let's verify this identity at $z=0$: RHS $= 2\sigma(0)-1 = 2(0.5)-1=0$. And indeed $\tanh(0) = \frac{1-1}{1+1}=\frac{0}{2}=0$. ✓ Matches.

**Derivative:**
$$\tanh'(z) = 1-\tanh^2(z)$$

Maximum value of this derivative occurs at $z=0$: $\tanh(0)=0$, so $\tanh'(0) = 1-0=1$ — four times larger than sigmoid's max derivative of 0.25. This means tanh suffers from vanishing gradients less severely than sigmoid, but the problem doesn't disappear: for large $|z|$, $\tanh(z) \to \pm 1$, so $\tanh'(z) \to 1-1=0$ — same saturation problem at the extremes.

### 4.4.3 ReLU (Rectified Linear Unit)

**Formula:**
$$\text{ReLU}(z) = \max(0, z)$$

This says: if $z$ is positive, output it unchanged. If $z$ is zero or negative, output exactly 0.

**Let's compute a few values:**
- $\text{ReLU}(5) = \max(0,5) = 5$
- $\text{ReLU}(-3) = \max(0,-3) = 0$
- $\text{ReLU}(0) = \max(0,0) = 0$

**Derivative:**
$$\text{ReLU}'(z) = \begin{cases} 1 & z>0 \\ 0 & z<0 \\ \text{undefined} & z=0 \text{ (in practice, we just define it as 0 or 1 by convention)} \end{cases}$$

**Why ReLU became the default choice for deep networks:**

1. **No vanishing gradient for positive inputs**: unlike sigmoid/tanh, where the derivative shrinks toward 0 as $|z|$ grows, ReLU's derivative is *exactly* 1 for all positive $z$, no matter how large. A gradient signal passing through a ReLU with positive input isn't shrunk at all.

2. **Computationally trivial**: computing $\max(0,z)$ is vastly cheaper than computing $e^{-z}$ (an exponential), which matters enormously when you're doing this operation billions of times per second across a massive network.

3. **Sparsity**: because ReLU outputs exactly 0 for any negative input, many neurons in a ReLU network end up outputting 0 for any given input — creating a "sparse" activation pattern, which empirically tends to help generalization and interpretability, and mirrors (loosely) how biological neurons don't all fire for every stimulus.

**The problem — "Dying ReLU":** Suppose, through an unlucky combination of weight initialization and training updates, a neuron's weights end up such that $z<0$ for literally every input in the training set. Then $\text{ReLU}(z) = 0$ always, and $\text{ReLU}'(z)=0$ always. During backpropagation, this neuron will receive a gradient of exactly 0 forever (because of how the chain rule multiplies through this zero derivative — full mechanics in Step 7) — meaning its weights can **never update again**, no matter how much more training happens. The neuron is permanently "dead," contributing nothing to the network's function forever after. In large networks, it's common for a meaningful fraction of ReLU neurons to die during training.

### 4.4.4 Leaky ReLU

**Formula:**
$$\text{LeakyReLU}(z) = \begin{cases} z & z>0 \\ \alpha z & z \leq 0 \end{cases}$$

where $\alpha$ is a small constant, commonly $\alpha=0.01$.

**Let's compute:**
- $\text{LeakyReLU}(5) = 5$ (unchanged, since $z>0$)
- $\text{LeakyReLU}(-5) = (0.01)(-5) = -0.05$ (small negative value, instead of a hard 0)

**Derivative:**
$$\text{LeakyReLU}'(z) = \begin{cases} 1 & z>0 \\ \alpha & z \leq 0 \end{cases}$$

Notice the derivative is now $\alpha=0.01$ (small, but **not zero**) even for negative inputs. This tiny non-zero gradient means a "dying" neuron under Leaky ReLU can still receive a (small) gradient signal and potentially recover during training, unlike standard ReLU where a dead neuron's gradient is exactly, permanently, 0.

### 4.4.5 GELU (Gaussian Error Linear Unit) — Used in GPT, BERT, and Most Modern Transformers

**Formula:**
$$\text{GELU}(z) = z \cdot \Phi(z)$$

where $\Phi(z)$ is the **cumulative distribution function (CDF) of the standard normal distribution** — a function from statistics that tells you "what's the probability that a standard normal random variable is less than or equal to $z$?"

$$\Phi(z) = \frac{1}{2}\left[1+\text{erf}\left(\frac{z}{\sqrt{2}}\right)\right]$$

(The "erf" function — error function — is itself defined by an integral that doesn't have a simple closed form; in practice, deep learning libraries either use a precomputed numerical approximation, or the commonly used tanh-based approximation:)

$$\text{GELU}(z) \approx 0.5z\left(1+\tanh\left[\sqrt{2/\pi}\left(z+0.044715z^3\right)\right]\right)$$

**Intuitively, what is GELU doing?** Unlike ReLU's hard cutoff at exactly $z=0$, GELU **smoothly** transitions — it multiplies the input $z$ by a probability (between 0 and 1) that grows smoothly from near-0 (for very negative $z$) to near-1 (for very positive $z$). You can think of it as "ReLU, but the on/off switch is smoothed into a soft dial rather than a hard flip." This smoothness (having a continuous derivative everywhere, unlike ReLU's sharp corner exactly at $z=0$) has been found empirically to help optimization in very deep Transformer networks, which is why virtually every modern LLM (GPT-family, BERT, and most others) uses GELU or a close variant instead of plain ReLU.

**A few approximate values** (using the tanh approximation formula above), to build intuition:
- $\text{GELU}(-3) \approx -0.004$ (nearly 0 — strongly suppressed, similar to ReLU)
- $\text{GELU}(0) = 0$ (exactly 0, same as ReLU at this one point)
- $\text{GELU}(1) \approx 0.841$ (passes through mostly unchanged, similar to ReLU, but not identical — ReLU(1) would be exactly 1)
- $\text{GELU}(3) \approx 2.996$ (nearly unchanged, similar to ReLU)

Notice GELU closely tracks ReLU for very negative or very positive $z$, but differs meaningfully in the "middle zone" near $z=0$, where it's smooth rather than sharply bent.

### 4.4.6 Softmax — The Special Output-Layer Function for Multi-Class Classification

Softmax is different from all the functions above: it doesn't operate on a single number $z$ in isolation — it operates on an entire **vector** of numbers simultaneously, converting them into a valid probability distribution.

**Formula**, for a vector of $K$ raw scores (called **logits**) $z_1, z_2, \dots, z_K$:

$$\text{softmax}(z_i) = \frac{e^{z_i}}{\sum_{j=1}^{K} e^{z_j}}$$

**Why exponentiate?** Two reasons: (1) exponentials are always positive, so we're guaranteed every output is positive, which is required for something to be a valid probability; (2) exponentials amplify differences — a logit that's slightly larger than another becomes *proportionally much larger* after exponentiation, which tends to make the model's confident predictions even more confident (in a calibrated way, based on training).

**Why divide by the sum?** This is called **normalizing** — dividing every term by the total ensures all the outputs add up to exactly 1, which is required for a valid probability distribution (all probabilities across all possible outcomes must sum to 1).

**Full worked example** (already previewed briefly in our earlier conversation, now let's do it with complete rigor):

Suppose a language model's output layer produces these raw logits for 3 candidate next-words: "cat", "dog", "fish":

$$z_{\text{cat}} = 2.0, \quad z_{\text{dog}} = 1.0, \quad z_{\text{fish}} = 0.1$$

**Step 1 — exponentiate each logit.** We need $e^{2.0}$, $e^{1.0}$, $e^{0.1}$.

Recall $e \approx 2.71828$.

$$e^{2.0} = e \times e \approx 2.71828 \times 2.71828 \approx 7.3891$$

$$e^{1.0} = e \approx 2.71828$$

$$e^{0.1} \approx 1.10517 \quad \text{(from a Taylor series or lookup: } e^{0.1} \approx 1 + 0.1 + 0.005 + \dots \approx 1.105\text{)}$$

**Step 2 — sum all the exponentiated values:**

$$\text{sum} = 7.3891 + 2.71828 + 1.10517$$

Adding step by step:
$$7.3891 + 2.71828 = 10.10738$$
$$10.10738 + 1.10517 = 11.21255$$

$$\text{sum} \approx 11.2126$$

**Step 3 — divide each exponentiated value by the sum:**

$$P(\text{cat}) = \frac{7.3891}{11.2126} \approx 0.6590$$

$$P(\text{dog}) = \frac{2.71828}{11.2126} \approx 0.2424$$

$$P(\text{fish}) = \frac{1.10517}{11.2126} \approx 0.0986$$

**Verification — do these sum to 1?**

$$0.6590 + 0.2424 + 0.0986 = 1.0000 ✓$$

**Interpretation**: given the model's internal computation up to this point, it believes there's a 65.9% chance the next word is "cat," 24.2% chance it's "dog," and 9.9% chance it's "fish." This exact softmax mechanism sits at the very final layer of every autoregressive language model (GPT, Claude, Llama, etc.) — every single token you've ever seen a language model generate was chosen by exactly this kind of probability distribution, computed via softmax over the model's full vocabulary (which for real LLMs is not 3 words, but commonly 50,000-200,000+ possible tokens). We will return to this in exhaustive detail in Step 14 (GPT) and Step 15 (Pretraining), including how the model decides *which* word to actually pick from this probability distribution (a topic called "sampling strategies," which you've already studied — this file's job was to make sure the mathematical machinery producing those probabilities in the first place is airtight).

## 4.5 Summary Comparison Table

| Function | Formula | Range | Derivative | Main Use Case | Main Weakness |
|---|---|---|---|---|---|
| Sigmoid | $\frac{1}{1+e^{-z}}$ | $(0,1)$ | $\sigma(1-\sigma)$ | Binary classification output; gates in LSTM | Vanishing gradient |
| Tanh | $\frac{e^z-e^{-z}}{e^z+e^{-z}}$ | $(-1,1)$ | $1-\tanh^2$ | RNN/LSTM hidden states | Vanishing gradient (less severe than sigmoid) |
| ReLU | $\max(0,z)$ | $[0,\infty)$ | 1 if $z>0$, else 0 | Default for CNNs, general deep nets | Dying ReLU |
| Leaky ReLU | $z$ if $z>0$, else $\alpha z$ | $(-\infty,\infty)$ | 1 if $z>0$, else $\alpha$ | Fixing dying ReLU | Extra hyperparameter $\alpha$ |
| GELU | $z\Phi(z)$ | $(-\infty,\infty)$ approx | smooth, no closed corner | Transformers, GPT, BERT | More expensive to compute |
| Softmax | $\frac{e^{z_i}}{\sum_j e^{z_j}}$ | $(0,1)$, sums to 1 across vector | (matrix Jacobian — covered in Step 7) | Output layer, multi-class classification, next-token prediction | Only used at output, not hidden layers |

---

# Summary Cheat Sheet

**The core equation of forward propagation, memorize this cold:**

$$\mathbf{z}^{(\ell)} = W^{(\ell)} \mathbf{a}^{(\ell-1)} + \mathbf{b}^{(\ell)}, \qquad \mathbf{a}^{(\ell)} = f\left(\mathbf{z}^{(\ell)}\right)$$

- A **neuron** = weighted sum + bias, optionally passed through an activation.
- A **perceptron** = a neuron using the step function, trained with a simple error-correction rule; provably limited to linearly separable problems (XOR is the canonical counterexample).
- An **MLP** = multiple layers of neurons, each fully connected to the next; each layer reshapes data into a new representation, which is why depth adds real power (unlike stacking linear layers, which collapses to a single layer — proven above).
- **Activation functions** = the non-linear ingredient that makes depth meaningful; without them, any network of any depth is mathematically equivalent to one linear layer. Modern LLMs primarily use GELU in hidden layers and softmax at the final output layer for next-token probabilities.

---

# Self-Test Questions

Work through these without looking back at the material, then check yourself:

1. Write out, from memory, the equation for a single neuron's pre-activation $z$, both in summation notation and dot-product notation.
2. Why is a negative weight meaningful? Give an example different from the ones in this file.
3. Derive, from the definitions of $y$ and $\hat{y}$, all four possible values of the perceptron error $e$, and explain in your own words why the weight update rule makes sense in each case.
4. Without looking, reproduce the geometric argument for why XOR is not linearly separable.
5. Prove (you may look at the structure of the proof, but write it in your own words/numbers) that a 3-layer linear network (no activation functions) is equivalent to a single linear layer.
6. Compute $\sigma(1)$ and $\sigma'(1)$ by hand, showing every step.
7. Explain, in your own words, why ReLU largely solved the vanishing gradient problem for positive activations, but introduced a new failure mode.
8. Given logits $[3.0, 1.0, 0.0]$ for three classes, compute the full softmax probability distribution by hand, and verify your three probabilities sum to 1.
9. Why does GELU use a smooth curve near $z=0$ instead of ReLU's sharp corner, and why might that matter for training very deep networks like Transformers?
10. In your own words, explain the single most important conceptual insight from the XOR/MLP worked example (Section 3.5.6) about what each layer in a neural network is "trying to do."

---

*End of File 1. File 2 will cover: Loss Functions, Gradient Descent, Backpropagation, and Deep Networks (Steps 5-8) — where we finally answer the question left hanging throughout this file: how does a network actually *find* good weights automatically, rather than us hand-designing them as we did for the XOR example?*

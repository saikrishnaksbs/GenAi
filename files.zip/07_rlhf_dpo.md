# File 7 of 20: Learning From Preferences, Not Just Examples
## RLHF → DPO

> **Continuity note**: File 6 ended by identifying a gap: Supervised Fine-Tuning (SFT) can only teach a model to imitate specific written-out example responses. It has no way to express nuanced comparisons like "response A is better than response B, but both are acceptable" or to improve beyond the ceiling of whatever examples happened to be written. This file derives two techniques that learn directly from **preferences** (rankings between responses) rather than fixed target text: **RLHF** (Reinforcement Learning from Human Feedback), the original approach used to align GPT-3 into something like ChatGPT, and **DPO** (Direct Preference Optimization), a more recent, mathematically elegant simplification that achieves a similar effect without needing full reinforcement learning machinery.

---

# Table of Contents

1. [Step 17: RLHF/DPO](#step-17-rlhfdpo)
   - [17.1–17.2: Analogies](#171-the-everyday-analogy)
   - [17.3: Why SFT Alone Isn't Enough](#173-why-sft-alone-isnt-enough-formalized)
   - [17.4: The RLHF Pipeline Overview](#174-the-rlhf-pipeline-three-stages)
   - [17.5: Reward Modeling — Full Mathematics](#175-stage-2-reward-modeling---full-mathematics)
   - [17.6: Policy Optimization with PPO](#176-stage-3-reinforcement-learning-with-ppo)
   - [17.7: The KL Penalty — Why It's Needed](#177-the-kl-divergence-penalty---derived-in-detail)
   - [17.8: Direct Preference Optimization (DPO)](#178-direct-preference-optimization-dpo)
   - [17.9: RLHF vs DPO Comparison](#179-rlhf-vs-dpo--practical-comparison)
2. [Summary Cheat Sheet](#summary-cheat-sheet)
3. [Self-Test Questions](#self-test-questions)

---

# Step 17: RLHF/DPO

### Main Question: *How do we align its responses?*

## 17.1 The Everyday Analogy

Imagine teaching someone to cook, but instead of only ever giving them exact recipes to copy (SFT's approach — "here is the ideal dish, reproduce it exactly"), you also let them cook several different attempts at a dish, TASTE each one, and simply tell them **"this version is better than that version"** — without necessarily writing out a perfect, complete alternative recipe for every single mistake. Over many rounds of "this one's better than that one," the cook develops a refined, generalized SENSE of what makes a dish good — a sense that lets them handle entirely NEW dishes they were never explicitly shown a recipe for, because they've internalized the underlying PRINCIPLES of good cooking (balance, seasoning, texture), not just a fixed set of memorized recipes. **This comparative, preference-based feedback loop is exactly what RLHF and DPO formalize mathematically.**

## 17.2 The Tech Analogy

Think of SFT as training a spam filter using ONLY confirmed labels ("this exact email is spam," "this exact email is not spam") — useful, but limited to exactly the examples you've labeled. RLHF/DPO is more like an **A/B testing framework layered on top**: you show users two slightly different versions of something (two candidate email classifications, or in our case, two candidate model responses), collect which one they PREFER, and use that comparative signal to iteratively refine the underlying system — capturing subtler quality signals (tone, helpfulness, safety) that would be extremely hard to fully specify with a fixed set of "correct" labeled examples alone.

## 17.3 Why SFT Alone Isn't Enough, Formalized

Recall from File 6, Section 16.6: SFT trains the model to imitate specific example responses via cross-entropy loss (File 6, Section 16.3.3). This has a subtle but important **ceiling effect**: the model is being trained to match the DISTRIBUTION of whatever responses happen to be in the SFT dataset. If the best available human-written example for some tricky prompt is only "pretty good, but not great," the model has no direct training signal pushing it to become BETTER than that example — cross-entropy loss simply rewards matching the given target, wherever that target's quality ceiling happens to sit.

**RLHF and DPO instead directly optimize for a notion of QUALITY** (specifically, human-judged preference) rather than optimizing for exact reproduction of any single fixed reference text — in principle allowing the model to exceed the quality of any individual example it was shown, by learning the general PATTERN of "what makes response A preferred over response B" across thousands of such comparisons, and generalizing that pattern to new, unseen situations.

## 17.4 The RLHF Pipeline — Three Stages

Original RLHF (as used to create the first ChatGPT-style models) consists of three distinct stages, run in sequence:

**Stage 1 — SFT** (exactly File 6's process): produces an initial "reasonably good" assistant model, used as the STARTING POINT for the remaining stages.

**Stage 2 — Reward Modeling**: train a SEPARATE neural network (the "reward model") whose job is to look at a (prompt, response) pair and output a single scalar number representing "how good/preferred is this response" — learned from human preference comparisons.

**Stage 3 — Reinforcement Learning (typically via PPO)**: use the trained reward model from Stage 2 to further fine-tune the SFT model from Stage 1, using reinforcement learning, such that the model learns to generate responses that the reward model scores highly.

We'll now derive the complete mathematics of Stages 2 and 3.

## 17.5 Stage 2: Reward Modeling — Full Mathematics

### 17.5.1 The Data Collection Process

Humans (or, increasingly, carefully-prompted AI systems) are shown a prompt along with TWO (or more) candidate responses generated by the current model, and asked to indicate which response they PREFER. This produces data in the form: $(x, y_w, y_l)$ — a prompt $x$, a "winning" (preferred) response $y_w$, and a "losing" (non-preferred) response $y_l$.

### 17.5.2 The Bradley-Terry Model — Deriving the Preference Probability Formula

We need a mathematical model of HOW a preference relates to some underlying, unobserved "quality score." The standard choice is the **Bradley-Terry model**, a well-established statistical model (originally developed for ranking outcomes of paired comparisons, like sports matches) that we'll now derive.

**Setup**: suppose each response $y$ has some true, underlying scalar "quality" or "reward" value $r(x,y)$ — a real number, where higher means better, for prompt $x$. The Bradley-Terry model states that the PROBABILITY that $y_w$ is preferred over $y_l$, given their underlying reward values, is:

$$P(y_w \succ y_l | x) = \frac{e^{r(x,y_w)}}{e^{r(x,y_w)}+e^{r(x,y_l)}}$$

**Let's understand why this specific functional form makes sense.** Notice this is structurally identical to softmax (File 1, Section 4.4.6), applied to just TWO options. Let's verify the formula behaves sensibly at the extremes:

- If $r(x,y_w) \gg r(x,y_l)$ (winning response's reward is MUCH larger): the denominator's $e^{r(x,y_l)}$ term becomes negligible compared to $e^{r(x,y_w)}$, so $P(y_w\succ y_l|x) \to \frac{e^{r(x,y_w)}}{e^{r(x,y_w)}} = 1$ — near-certainty that $y_w$ is preferred, which makes sense given its much higher reward.
- If $r(x,y_w) = r(x,y_l)$ (equal rewards): $P(y_w\succ y_l|x) = \frac{e^r}{e^r+e^r}=\frac{e^r}{2e^r}=\frac{1}{2}$ — exactly 50/50, a coin flip, which is exactly right when two options are equally good.

**An algebraically equivalent, often more convenient form** (dividing numerator and denominator by $e^{r(x,y_w)}$):

$$P(y_w\succ y_l|x) = \frac{1}{1+e^{-(r(x,y_w)-r(x,y_l))}} = \sigma\left(r(x,y_w)-r(x,y_l)\right)$$

This is a beautiful result: **the preference probability is exactly the sigmoid function (File 1, Section 4.4.1) applied to the DIFFERENCE between the two rewards.** This makes complete intuitive sense — what matters for predicting a preference isn't the absolute reward values, but how much BETTER one response's reward is relative to the other's, squashed through sigmoid into a valid probability.

### 17.5.3 Training the Reward Model — The Loss Function, Derived

We build a neural network $r_\phi(x,y)$ (parameters $\phi$, typically initialized from the SFT model itself, with its final language-modeling head from File 5, Section 14.4.1 replaced by a new head that outputs a single scalar instead of vocabulary-sized logits) to APPROXIMATE this true, underlying reward function. We train it using **maximum likelihood** (exactly the same principle derived in File 6, Section 15.3.3) on the human preference data: we want to choose $\phi$ to maximize the probability the Bradley-Terry model assigns to the ACTUALLY OBSERVED human preferences.

Using the same log-likelihood and negation steps as File 6, Sections 15.3.4-15.3.5 (converting a maximization of likelihood into a minimization of negative log-likelihood, for numerical stability and compatibility with gradient descent), the reward model's loss for one preference pair is:

$$\mathcal{L}_{\text{reward}} = -\log\sigma\left(r_\phi(x,y_w)-r_\phi(x,y_l)\right)$$

Averaged across the full dataset of $N$ collected preference comparisons:

$$\mathcal{L}_{\text{reward}} = -\frac{1}{N}\sum_{i=1}^{N}\log\sigma\left(r_\phi(x_i,y_{w,i})-r_\phi(x_i,y_{l,i})\right)$$

**This loss function has an intuitive shape worth understanding precisely.** If the reward model currently scores $y_w$ HIGHER than $y_l$ (correctly matching the human preference), then $r_\phi(x,y_w)-r_\phi(x,y_l)$ is positive, so $\sigma(\cdot)$ of that positive number is greater than 0.5, so $-\log\sigma(\cdot)$ is a relatively SMALL positive loss (recall from File 2, Section 5.5.2's cross-entropy discussion: $-\log$ of a value close to 1 is small). If the reward model currently scores them in the WRONG order (contradicting the human preference), $\sigma(\cdot)$ of a negative number is less than 0.5, and $-\log\sigma(\cdot)$ becomes a LARGE loss, pushing gradient descent to correct this ordering.

### 17.5.4 Fully Worked Numerical Example — Reward Model Loss

Suppose for a given prompt $x$, our current reward model assigns:

$$r_\phi(x,y_w) = 2.5 \qquad r_\phi(x,y_l) = 1.0$$

(where $y_w$ is the response humans actually preferred)

**Step 1 — compute the reward difference:**

$$r_\phi(x,y_w)-r_\phi(x,y_l) = 2.5-1.0=1.5$$

**Step 2 — apply sigmoid** (recall File 1, Section 4.4.1's computation method):

$$\sigma(1.5) = \frac{1}{1+e^{-1.5}}$$

Using $e^{-1.5}\approx0.2231$:

$$\sigma(1.5) = \frac{1}{1.2231}\approx0.8176$$

**Step 3 — compute the loss:**

$$\mathcal{L} = -\log(0.8176)$$

Using $\ln(0.8176)\approx-0.2014$:

$$\mathcal{L} = -(-0.2014)=0.2014$$

**A relatively small loss (0.2014)**, since the reward model already correctly ranks $y_w$ above $y_l$ with reasonable confidence. **Let's contrast this with the WRONG ordering**, to see the loss react appropriately: suppose instead $r_\phi(x,y_w)=1.0$ and $r_\phi(x,y_l)=2.5$ (the model incorrectly thinks the LOSING response is better):

$$r_\phi(x,y_w)-r_\phi(x,y_l) = 1.0-2.5=-1.5$$

$$\sigma(-1.5) = \frac{1}{1+e^{1.5}}$$

Using $e^{1.5}\approx4.4817$:

$$\sigma(-1.5) = \frac{1}{5.4817}\approx0.1824$$

$$\mathcal{L} = -\log(0.1824) \approx -(-1.702) = 1.702$$

**A much larger loss (1.702 vs. 0.2014 — over 8 times larger)**, correctly and strongly penalizing the reward model for ranking the responses in the wrong order, exactly the behavior we derived and expected in Section 17.5.3.

## 17.6 Stage 3: Reinforcement Learning With PPO

### 17.6.1 Reframing Text Generation as a Reinforcement Learning Problem

To apply reinforcement learning, we need to recast our GPT model (File 5) using RL terminology:

- The **policy** $\pi_\theta$ is our GPT model itself (parameters $\theta$) — given a "state" (the prompt plus tokens generated so far), it outputs a probability distribution over the next action.
- An **action** is choosing the next token to generate (exactly the sampling step from File 5, Section 14.5, Step 7).
- The **reward** is provided by our trained reward model $r_\phi$ from Stage 2, typically computed ONCE the full response has been completely generated (evaluating the entire finished response's quality).

### 17.6.2 The RL Objective, Stated

We want to adjust $\theta$ (starting from the SFT model's weights) to maximize the EXPECTED reward of the responses it generates:

$$\max_\theta \mathbb{E}_{x\sim D, y\sim\pi_\theta(\cdot|x)}\left[r_\phi(x,y)\right]$$

(Read this as: "across prompts $x$ drawn from our dataset $D$, and responses $y$ sampled from our current policy $\pi_\theta$, maximize the average/expected reward score.")

### 17.6.3 Why We Can't Just Use Ordinary Backpropagation Here — A Crucial Conceptual Point

Here's a subtlety that's genuinely important to understand: unlike every loss function we've worked with since File 2 (MSE, cross-entropy), where the loss is a smooth, DIRECT, differentiable function of the model's OUTPUT probabilities, the reward $r_\phi(x,y)$ here comes from **sampling** a specific discrete response $y$ (recall the sampling step, File 5 Section 14.5, involves an element of randomness/discreteness — picking one specific token from a probability distribution, not a smooth, differentiable function of that distribution). We cannot directly backpropagate through the discrete SAMPLING operation itself the way we backpropagated through continuous operations like matrix multiplications and activation functions in File 2.

**This is precisely the problem that policy gradient methods in reinforcement learning are designed to solve.** The core mathematical tool is the **REINFORCE / policy gradient theorem**, which provides a way to estimate the gradient of an expectation over a SAMPLING process, without needing to differentiate through the sampling itself:

$$\nabla_\theta \mathbb{E}_{y\sim\pi_\theta}[r(y)] = \mathbb{E}_{y\sim\pi_\theta}\left[r(y)\cdot\nabla_\theta\log\pi_\theta(y)\right]$$

**Intuition for this formula** (a full rigorous derivation involves the "log-derivative trick" from calculus, which we'll sketch briefly): this says the gradient we want equals the expected value of (the reward received) TIMES (the gradient of the log-probability of the action that was actually taken). In practice, this means: sample some responses, see what reward each one got, and then **push up** the log-probability of responses that received HIGH reward (proportionally to how high), and **push down** the log-probability of responses that received LOW (or negative) reward — using the EXACT SAME $\nabla_\theta\log\pi_\theta(y)$ term, which, since $\pi_\theta$ is built from our familiar softmax-over-vocabulary output (File 5, Section 14.4.1), is something we CAN compute via ordinary backpropagation (File 2, Step 7) — the reward $r(y)$ itself just acts as a SCALING FACTOR multiplying this already-familiar gradient, rather than something we need to differentiate through directly.

### 17.6.4 PPO — Proximal Policy Optimization, Conceptually

**PPO** is the specific, popular reinforcement learning ALGORITHM used to actually perform this optimization in practice (rather than the more basic REINFORCE estimator sketched above, which tends to have high variance / instability in practice). A full derivation of PPO's clipped objective function is a substantial topic in its own right, going somewhat beyond what's needed for your current LLM-focused study — but the ESSENTIAL idea, which is important to understand conceptually, is:

PPO takes a gradient step in the direction suggested by the policy gradient formula above, but **restricts/"clips" how large a single update can be**, preventing the policy from changing too drastically in any single training step. This is directly analogous to a concern we've already encountered precisely: recall File 2, Section 6.3.5's demonstration of divergence from an overly large learning rate. PPO's clipping mechanism is a more sophisticated, RL-specific safeguard against a similar failure mode — since RL training can be considerably LESS stable than ordinary supervised gradient descent (because the data distribution itself, i.e., which responses get sampled, changes as the policy $\pi_\theta$ changes during training, unlike supervised learning's fixed dataset), extra guardrails against overly aggressive updates are especially important.

## 17.7 The KL Divergence Penalty — Derived in Detail

### 17.7.1 The Problem: Reward Hacking

If we NAIVELY optimize purely to maximize the reward model's score (Section 17.6.2's objective, unmodified), a serious practical problem emerges: the policy $\pi_\theta$ might discover ways to achieve a HIGH score from the reward model $r_\phi$ that DON'T actually correspond to genuinely better responses — e.g., exploiting some quirk or blind spot the reward model happens to have (since $r_\phi$ is itself just an imperfect, learned APPROXIMATION of true human preference, not a perfect oracle). This phenomenon is called **reward hacking**, and it's a serious, real practical concern in RLHF pipelines.

### 17.7.2 The Fix — Penalizing Divergence From the Original SFT Model

The fix: modify the RL objective to also penalize the policy for straying TOO FAR from the original SFT model's behavior (which we trust to be reasonably sensible, having been directly trained on curated human examples in File 6), using a mathematical measure of "how different are two probability distributions" called **KL divergence** (Kullback-Leibler divergence).

$$\text{KL}\left(\pi_\theta(\cdot|x) \,\|\, \pi_{\text{SFT}}(\cdot|x)\right) = \sum_{y} \pi_\theta(y|x)\log\frac{\pi_\theta(y|x)}{\pi_{\text{SFT}}(y|x)}$$

**Let's understand this formula's behavior.** If $\pi_\theta$ and $\pi_{\text{SFT}}$ assign IDENTICAL probabilities everywhere, then $\frac{\pi_\theta(y|x)}{\pi_{\text{SFT}}(y|x)}=1$ for every $y$, so $\log(1)=0$ for every term, and the entire KL divergence is exactly 0 — correctly indicating "no difference between these two distributions." As $\pi_\theta$ increasingly diverges from $\pi_{\text{SFT}}$ (assigning very different probabilities to the same responses), this sum grows larger, quantifying the MAGNITUDE of that divergence. Importantly, KL divergence is always $\geq0$ (a mathematical property we won't fully prove here, but which follows from a result called Jensen's inequality), making it a sensible, well-behaved "distance-like" penalty term (though technically not a true mathematical distance metric, since it's not symmetric: $\text{KL}(P\|Q) \neq \text{KL}(Q\|P)$ in general).

### 17.7.3 The Full, Complete RLHF Objective

$$\max_\theta \mathbb{E}_{x\sim D,y\sim\pi_\theta}\left[r_\phi(x,y)\right] - \beta \cdot \text{KL}\left(\pi_\theta(\cdot|x)\,\|\,\pi_{\text{SFT}}(\cdot|x)\right)$$

Here $\beta$ is a hyperparameter (a tunable constant chosen by the practitioner, similar in spirit to how we've treated learning rates $\eta$ throughout this series) controlling the TRADE-OFF between "maximize reward as much as possible" (favored by a smaller $\beta$) versus "stay close to the trusted, sensible SFT behavior" (favored by a larger $\beta$). This is a direct, explicit mechanism for preventing the reward-hacking problem described in Section 17.7.1: even if the policy COULD achieve a slightly higher raw reward score by drifting into some strange, reward-model-exploiting behavior, doing so would incur a KL penalty cost that may outweigh that reward gain, keeping the final trained policy's behavior reasonably close to (while still being meaningfully IMPROVED upon) the original SFT model.

## 17.8 Direct Preference Optimization (DPO)

### 17.8.1 The Motivation

The full RLHF pipeline derived above (Sections 17.5-17.7) is mathematically sound but practically CUMBERSOME: it requires training and maintaining an entire SEPARATE reward model (Stage 2), then running a genuinely complex, often unstable reinforcement learning procedure (Stage 3, PPO) — involving repeatedly SAMPLING responses from the currently-training policy, scoring them with the reward model, and carefully managing the policy-gradient/KL-penalty machinery derived above. **DPO, introduced in 2023, provides a mathematically elegant way to achieve a very similar end result WITHOUT needing a separate reward model or the full reinforcement learning apparatus at all** — collapsing the process into something that looks almost exactly like the ordinary supervised learning we've used throughout this series.

### 17.8.2 The Key Mathematical Insight — Deriving DPO From the RLHF Objective

This is a genuinely elegant piece of mathematics, and we'll derive it as completely as possible. Start from the KL-constrained RLHF objective (Section 17.7.3). It's a known result from constrained optimization theory (related to concepts you may encounter in more advanced calculus/optimization courses) that this exact objective has a closed-form OPTIMAL solution, expressible as:

$$\pi^*(y|x) = \frac{1}{Z(x)}\pi_{\text{SFT}}(y|x)\exp\left(\frac{1}{\beta}r_\phi(x,y)\right)$$

where $Z(x) = \sum_y \pi_{\text{SFT}}(y|x)\exp\left(\frac{1}{\beta}r_\phi(x,y)\right)$ is a normalizing constant (called the "partition function" in statistical physics-inspired terminology) ensuring $\pi^*(y|x)$ sums to 1 across all possible $y$, exactly as any valid probability distribution must.

**The crucial algebraic move**: let's REARRANGE this equation to solve for the reward $r_\phi(x,y)$ in terms of the optimal policy $\pi^*$ (which is precisely what DPO will end up training DIRECTLY, bypassing the need for an explicit $r_\phi$ altogether):

Starting from $\pi^*(y|x) = \frac{1}{Z(x)}\pi_{\text{SFT}}(y|x)\exp\left(\frac{1}{\beta}r_\phi(x,y)\right)$, multiply both sides by $Z(x)$:

$$\pi^*(y|x)Z(x) = \pi_{\text{SFT}}(y|x)\exp\left(\frac{1}{\beta}r_\phi(x,y)\right)$$

Divide both sides by $\pi_{\text{SFT}}(y|x)$:

$$\frac{\pi^*(y|x)Z(x)}{\pi_{\text{SFT}}(y|x)} = \exp\left(\frac{1}{\beta}r_\phi(x,y)\right)$$

Take the natural log of both sides:

$$\log\frac{\pi^*(y|x)}{\pi_{\text{SFT}}(y|x)} + \log Z(x) = \frac{1}{\beta}r_\phi(x,y)$$

Multiply both sides by $\beta$ and rearrange to isolate $r_\phi(x,y)$:

$$r_\phi(x,y) = \beta\log\frac{\pi^*(y|x)}{\pi_{\text{SFT}}(y|x)} + \beta\log Z(x)$$

**This equation is the heart of DPO**: it expresses the reward function ENTIRELY in terms of the policy $\pi^*$ itself (and the fixed reference SFT policy), rather than as some separately-trained neural network.

### 17.8.3 Substituting Back Into the Bradley-Terry Preference Model

Recall the Bradley-Terry preference probability from Section 17.5.2: $P(y_w\succ y_l|x) = \sigma(r(x,y_w)-r(x,y_l))$. Let's substitute our rearranged expression for $r_\phi$ into this:

$$r_\phi(x,y_w)-r_\phi(x,y_l) = \left[\beta\log\frac{\pi^*(y_w|x)}{\pi_{\text{SFT}}(y_w|x)}+\beta\log Z(x)\right] - \left[\beta\log\frac{\pi^*(y_l|x)}{\pi_{\text{SFT}}(y_l|x)}+\beta\log Z(x)\right]$$

**Notice the $\beta\log Z(x)$ terms are IDENTICAL in both brackets** (since $Z(x)$ depends only on $x$, not on the specific response $y$), so they cancel out perfectly when we subtract:

$$r_\phi(x,y_w)-r_\phi(x,y_l) = \beta\log\frac{\pi^*(y_w|x)}{\pi_{\text{SFT}}(y_w|x)} - \beta\log\frac{\pi^*(y_l|x)}{\pi_{\text{SFT}}(y_l|x)}$$

**This cancellation is the single most important algebraic trick in the entire DPO derivation** — it's precisely WHY we never need to know the value of the messy, hard-to-compute normalizing constant $Z(x)$ at all, despite it appearing in our original formula for $\pi^*$. This is what makes DPO tractable to implement directly.

### 17.8.4 The Final DPO Loss Function

Substituting this reward difference back into the Bradley-Terry sigmoid formula from Section 17.5.2, and then into the reward-model training loss structure from Section 17.5.3 (but now, crucially, treating $\pi_\theta$ ITSELF as the object we're directly training, rather than a separate reward model $r_\phi$):

$$\mathcal{L}_{\text{DPO}}(\theta) = -\mathbb{E}_{(x,y_w,y_l)}\left[\log\sigma\left(\beta\log\frac{\pi_\theta(y_w|x)}{\pi_{\text{SFT}}(y_w|x)} - \beta\log\frac{\pi_\theta(y_l|x)}{\pi_{\text{SFT}}(y_l|x)}\right)\right]$$

**This is the complete DPO loss function.** Notice what it requires to compute: just the log-probabilities the CURRENT policy $\pi_\theta$ and the FIXED reference SFT policy $\pi_{\text{SFT}}$ assign to the winning and losing responses — quantities we can compute via a completely ordinary forward pass through both models (exactly the same forward-pass mechanism from File 5, Section 14.5), with NO separate reward model, NO sampling-based policy gradient estimation, and NO PPO-style clipping machinery required. **DPO converts what was originally a complex, multi-stage reinforcement learning problem into something that can be optimized with completely ordinary gradient descent and backpropagation** (exactly File 2's machinery), directly on a dataset of preference pairs $(x,y_w,y_l)$ — a remarkable simplification, made possible entirely by the elegant algebraic cancellation derived in Section 17.8.3.

### 17.8.5 Fully Worked Numerical Example — DPO Loss Computation

Let's compute a complete DPO loss value by hand. Suppose for a given preference pair $(x,y_w,y_l)$, after running forward passes through both the current policy $\pi_\theta$ and the fixed reference $\pi_{\text{SFT}}$, we obtain the following (log-)probabilities (these would, in practice, be SUMS of per-token log-probabilities across the full response — recall the sum-over-tokens structure from File 6, Section 15.3.5 — but let's treat them as single already-computed aggregate values for this illustration):

$$\log\pi_\theta(y_w|x) = -2.0 \qquad \log\pi_\theta(y_l|x) = -3.5$$
$$\log\pi_{\text{SFT}}(y_w|x)=-2.2 \qquad \log\pi_{\text{SFT}}(y_l|x)=-2.5$$

Let's use $\beta=0.5$ (a common-order-of-magnitude choice for this hyperparameter).

**Step 1 — compute $\log\frac{\pi_\theta(y_w|x)}{\pi_{\text{SFT}}(y_w|x)}$**, which, using the log-quotient rule ($\log(a/b)=\log a-\log b$), equals:

$$\log\pi_\theta(y_w|x)-\log\pi_{\text{SFT}}(y_w|x) = -2.0-(-2.2) = 0.2$$

**Step 2 — compute $\log\frac{\pi_\theta(y_l|x)}{\pi_{\text{SFT}}(y_l|x)}$:**

$$\log\pi_\theta(y_l|x)-\log\pi_{\text{SFT}}(y_l|x) = -3.5-(-2.5) = -1.0$$

**Interpretation of these two intermediate results already**: the CURRENT policy $\pi_\theta$ has INCREASED its relative probability (compared to the reference model) for the WINNING response (a positive value, $+0.2$), and has DECREASED its relative probability for the LOSING response (a negative value, $-1.0$) — exactly the desired direction of adjustment, even before we finish the full loss computation.

**Step 3 — multiply each by $\beta=0.5$:**

$$\beta \times 0.2 = 0.1 \qquad \beta\times(-1.0)=-0.5$$

**Step 4 — compute the difference:**

$$0.1 - (-0.5) = 0.6$$

**Step 5 — apply sigmoid:**

$$\sigma(0.6) = \frac{1}{1+e^{-0.6}}$$

Using $e^{-0.6}\approx0.5488$:

$$\sigma(0.6) = \frac{1}{1.5488}\approx0.6457$$

**Step 6 — compute the final loss:**

$$\mathcal{L}_{\text{DPO}} = -\log(0.6457)$$

Using $\ln(0.6457)\approx-0.4374$:

$$\mathcal{L}_{\text{DPO}} = 0.4374$$

**Interpretation**: this is a moderate loss value, reflecting that the policy is ALREADY moving in a reasonable direction (favoring $y_w$ over $y_l$, relative to the reference model), but there's still room for improvement (the loss isn't near 0, which would require an even larger gap between the relative probabilities). Gradient descent, applied to this loss using ordinary backpropagation, will continue to push $\pi_\theta$ to further increase $\log\pi_\theta(y_w|x)$ and further decrease $\log\pi_\theta(y_l|x)$, relative to the fixed reference model — directly, without ever needing to construct or consult a separate reward model at all.

## 17.9 RLHF vs. DPO — Practical Comparison

| Aspect | RLHF (with PPO) | DPO |
|---|---|---|
| Requires separate reward model? | Yes (Stage 2) | No — reward is implicit in the policy itself |
| Requires online sampling during training? | Yes (must sample responses from the CURRENTLY training policy at each step) | No — trains directly on a FIXED, pre-collected dataset of preference pairs |
| Training stability | Can be unstable (classic RL challenges: variance, sensitivity to hyperparameters) | Generally much more stable (it's ordinary supervised-style gradient descent) |
| Implementation complexity | High (reward model + PPO infrastructure + careful KL tuning) | Comparatively low (a single, clearly-defined loss function) |
| Theoretical guarantee | Optimizes the KL-constrained RLHF objective, but via an approximate, iterative RL procedure | Provably converges to the SAME optimal policy $\pi^*$ as the RLHF objective, in the idealized case, but reaches it directly |

**Both methods target the exact same underlying mathematical objective** (the KL-constrained reward maximization from Section 17.7.3) — DPO simply reformulates the PATH to that objective, exploiting the elegant algebraic cancellation in Section 17.8.3 to avoid needing the more cumbersome, less stable machinery of an explicit reward model and full reinforcement learning. This is precisely why DPO has become an extremely popular, widely-adopted alignment technique since its introduction — it achieves conceptually similar alignment benefits with substantially reduced implementation complexity and improved training stability, using tools (ordinary supervised gradient descent, File 2's complete machinery) you have already mastered in full mathematical detail throughout this series.

---

# Summary Cheat Sheet

**Bradley-Terry preference model** — the foundation connecting rewards to observed preferences:

$$P(y_w\succ y_l|x) = \sigma\left(r(x,y_w)-r(x,y_l)\right)$$

**Reward model training loss** (Stage 2 of RLHF):

$$\mathcal{L}_{\text{reward}} = -\log\sigma\left(r_\phi(x,y_w)-r_\phi(x,y_l)\right)$$

**Full RLHF objective** (Stage 3, optimized via PPO):

$$\max_\theta \mathbb{E}\left[r_\phi(x,y)\right] - \beta\cdot\text{KL}(\pi_\theta\|\pi_{\text{SFT}})$$

**DPO loss** — the same objective, reached directly, with no separate reward model:

$$\mathcal{L}_{\text{DPO}} = -\log\sigma\left(\beta\log\frac{\pi_\theta(y_w|x)}{\pi_{\text{SFT}}(y_w|x)}-\beta\log\frac{\pi_\theta(y_l|x)}{\pi_{\text{SFT}}(y_l|x)}\right)$$

derived by algebraically substituting the closed-form optimal RLHF policy back into the Bradley-Terry model, causing the intractable normalizing constant $Z(x)$ to cancel out exactly.

---

# Self-Test Questions

1. Explain, using the cooking analogy, why comparative preference feedback can teach a model to exceed the quality ceiling of any single SFT example.
2. Verify algebraically that the two forms of the Bradley-Terry model given in Section 17.5.2 (the raw exponential-ratio form and the sigmoid-of-difference form) are equivalent, by dividing the first form's numerator and denominator by $e^{r(x,y_w)}$ yourself.
3. Redo the reward model loss worked example (Section 17.5.4) using $r_\phi(x,y_w)=1.8$ and $r_\phi(x,y_l)=1.2$, showing every step, and compare the resulting loss to the two cases already computed in this file.
4. Explain, in your own words, why we cannot directly backpropagate through the token-sampling step, and what problem the policy gradient theorem solves.
5. Explain reward hacking using an example scenario of your own invention (different from anything mentioned in this file), and explain how the KL penalty term helps mitigate it.
6. Starting from $\pi^*(y|x)=\frac{1}{Z(x)}\pi_{\text{SFT}}(y|x)\exp(\frac{1}{\beta}r_\phi(x,y))$, reproduce the full algebraic rearrangement to solve for $r_\phi(x,y)$, showing every intermediate step, without looking back at Section 17.8.2.
7. Explain precisely why the $\beta\log Z(x)$ terms cancel when computing $r_\phi(x,y_w)-r_\phi(x,y_l)$, and why this cancellation is described as "the single most important algebraic trick" in this file.
8. Redo the DPO loss worked example (Section 17.8.5) using $\beta=1.0$ instead of $0.5$, keeping all four log-probability values the same, and compare your resulting loss to the original — did increasing $\beta$ increase or decrease the loss, and does that match your intuition about what $\beta$ controls?
9. Fill in the RLHF vs. DPO comparison table from memory, in your own words, without looking back at Section 17.9.
10. Explain, in your own words, why DPO is described as turning an RL problem into something that "looks almost exactly like ordinary supervised learning," referencing specifically what DPO's loss function requires you to compute.

---

*End of File 7. File 8 will cover: Modern LLMs, Reasoning Models, and Agents (Steps 18-20) — surveying how today's production models (Llama, Qwen, Mistral, and others) vary on the architectural foundation built in this series, what specifically changes in models trained for extended reasoning, and how LLMs are composed into agentic systems that use tools and maintain memory across extended tasks.*
